// Cosmetic destruction only: no physics colliders, pickups or damage.
// One shared shard batch + one CC0 smoke-sprite batch, allocated lazily.
var breakageFx=null,breakageBurstFrame=-1,breakageBursts=0;
function equipmentBreakMaterial(p){if(p.type==='prop'){if(/crate|wood|box/i.test(p.id))return 'wood';if(/life-ring|buoy|float/i.test(p.id))return 'fabric'}return p.type==='window'?'glass':p.type==='door'||p.type==='ammo'||p.type==='plank'?'wood':p.type==='net'?'fabric':'metal'}
function createBreakageFx(){
 const capacity=tt?96:192,dustCapacity=tt?12:24,helper=new Ct();
 const colors={glass:new Ee('#c6f4f6'),wood:new Ee('#976334'),metal:new Ee('#9ea9a9'),fabric:new Ee('#a8b7a1')};
 const shards=new En(new bm.TetrahedronGeometry(1,0),new bm.MeshLambertMaterial({color:'#ffffff',flatShading:true}),capacity);
 const geometry=new jn(1,1),alpha=new bm.InstancedBufferAttribute(new Float32Array(dustCapacity),1);geometry.setAttribute('fxAlpha',alpha);
 const material=new bm.ShaderMaterial({uniforms:{map:{value:particleAssets.smoke_01}},transparent:true,depthWrite:false,side:hn,
 vertexShader:`attribute float fxAlpha;varying vec2 vUv;varying float vAlpha;varying vec3 vTint;
 void main(){vUv=uv;vAlpha=fxAlpha;vTint=vec3(1.0);
 #ifdef USE_INSTANCING_COLOR
 vTint=instanceColor;
 #endif
 gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(position,1.0);}`,
 fragmentShader:`uniform sampler2D map;varying vec2 vUv;varying float vAlpha;varying vec3 vTint;
 void main(){vec4 tex=texture2D(map,vUv);float a=tex.a*vAlpha;if(a<0.008)discard;gl_FragColor=vec4(tex.rgb*vTint,a);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 }`});
 const dust=new En(geometry,material,dustCapacity);dust.renderOrder=5;
 for(const [mesh,name]of [[shards,'Pooled breakage shards'],[dust,'Pooled breakage dust']]){mesh.name=name;mesh.count=0;mesh.visible=false;mesh.frustumCulled=false;mesh.userData.noBulletHit=mesh.userData.noLOSBlock=true;mesh.raycast=()=>{};mesh.instanceMatrix.setUsage(bm.DynamicDrawUsage);st.add(mesh)}
 return {shards,dust,alpha,helper,colors,slot:0,dustSlot:0,active:false,
  pieces:Array.from({length:capacity},()=>({life:0})),clouds:Array.from({length:dustCapacity},()=>({life:0}))};
}
function emitEquipmentBreak(p){
 p.root.updateWorldMatrix(true,true);
 const box=new bm.Box3().setFromObject(p.root),point=box.isEmpty()?p.root.getWorldPosition(new w()):box.getCenter(new w()),kind=equipmentBreakMaterial(p);
 if(Tn.active||point.distanceToSquared(oe.position)>72*72)return;
 It('break-'+kind,{position:point,volume:kind==='glass'?.62:kind==='fabric'?.32:.56,range:72,key:'break-'+kind,cooldown:45,maxAge:1000,category:'breakage'});
 // A mass explosion must not allocate a separate emitter for every component.
 if(breakageBurstFrame!==Mt){breakageBurstFrame=Mt;breakageBursts=0}if(breakageBursts++>=(tt?3:5))return;
 const fx=breakageFx||(breakageFx=createBreakageFx()),size=box.getSize(new w()),scale=p.boat.matrixWorld.getMaxScaleOnAxis(),floor=p.breakFloor??Math.min(point.y-.05,p.boat.localToWorld(new w(0,.43,0)).y);
 const count=tt?10:18,spread=Math.min(.65,Math.max(.12,size.length()*.12));
 for(let i=0;i<count;i++){
  const a=fx.pieces[fx.slot++%fx.pieces.length],angle=Math.random()*Math.PI*2,speed=.8+Math.random()*2.3;
  a.life=a.max=1.1+Math.random()*.9;a.x=point.x+(Math.random()-.5)*spread;a.y=point.y+(Math.random()-.5)*spread;a.z=point.z+(Math.random()-.5)*spread;
  a.vx=Math.cos(angle)*speed;a.vy=.8+Math.random()*2.6;a.vz=Math.sin(angle)*speed;a.rx=Math.random()*6;a.ry=Math.random()*6;a.rz=Math.random()*6;a.spin=(Math.random()-.5)*9;
  a.floor=kind==='metal'&&p.type==='gun'&&p.anchor.y>2?Math.max(floor,box.min.y):floor;a.bounced=false;
  const base=(.035+Math.random()*.05)*Math.min(1.5,scale);a.sx=base*(kind==='wood'?3.5:1.5);a.sy=base*(kind==='fabric'?.15:kind==='glass'?.12:.7);a.sz=base;a.color=fx.colors[kind];
 }
 // Glass uses a brief pale puff, wood/fabric a warmer dust cloud, metal grey grit.
 for(let i=0;i<(tt?2:3);i++){
  const a=fx.clouds[fx.dustSlot++%fx.clouds.length];a.life=a.max=.45+Math.random()*.35;a.x=point.x+(Math.random()-.5)*spread;a.y=point.y;a.z=point.z+(Math.random()-.5)*spread;
  a.size=.35+Math.random()*.3;a.spin=Math.random()*6;a.color=fx.colors[kind];a.opacity=kind==='glass'?.16:.32;
 }
 if(kind==='metal')for(let i=0;i<3;i++)Wo(point,new w((Math.random()-.5)*2,1+Math.random(),(Math.random()-.5)*2),'spark');
 fx.active=true;updateBreakageFx(0);
}
function updateBreakageFx(dt){
 const fx=breakageFx;if(!fx||!fx.active)return;dt=Math.min(.05,Math.max(0,dt));let count=0,dustCount=0;const h=fx.helper;
 for(const a of fx.pieces){if(a.life<=0)continue;a.life=Math.max(0,a.life-dt);if(!a.life)continue;
  a.vy-=9.8*dt;a.x+=a.vx*dt;a.y+=a.vy*dt;a.z+=a.vz*dt;
  if(a.y<a.floor+.025){a.y=a.floor+.025;if(!a.bounced){a.vy=Math.abs(a.vy)*.22;a.vx*=.35;a.vz*=.35;a.bounced=true}else{a.vy=0;a.vx*=Math.max(0,1-dt*9);a.vz*=Math.max(0,1-dt*9)}}
  a.rx+=a.spin*dt;a.ry+=a.spin*.7*dt;a.rz+=a.spin*.4*dt;const fade=Math.min(1,a.life/.3);
  h.position.set(a.x,a.y,a.z);h.rotation.set(a.rx,a.ry,a.rz);h.scale.set(a.sx*fade,a.sy*fade,a.sz*fade);h.updateMatrix();fx.shards.setMatrixAt(count,h.matrix);fx.shards.setColorAt(count++,a.color);
 }
 for(const a of fx.clouds){if(a.life<=0)continue;a.life=Math.max(0,a.life-dt);if(!a.life)continue;const t=1-a.life/a.max;a.y+=dt*.3;
  h.position.set(a.x,a.y,a.z);h.quaternion.copy(oe.quaternion);h.rotateZ(a.spin);h.scale.setScalar(a.size*(1+t*2));h.updateMatrix();fx.dust.setMatrixAt(dustCount,h.matrix);fx.dust.setColorAt(dustCount,a.color);fx.alpha.setX(dustCount++,a.opacity*(1-t)*(1-t));
 }
 for(const [mesh,n]of [[fx.shards,count],[fx.dust,dustCount]]){mesh.count=n;mesh.visible=n>0;if(n){mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true}}
 if(dustCount)fx.alpha.needsUpdate=true;fx.active=!!(count||dustCount);
}

function emitPlankBreak(root){const point=root.getWorldPosition(new w());emitEquipmentBreak({root,boat:st,type:'plank',anchor:point,breakFloor:gi(point.x,point.z)+.025})}
