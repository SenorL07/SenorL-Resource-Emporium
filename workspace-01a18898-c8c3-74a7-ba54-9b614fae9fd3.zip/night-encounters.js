// Bounded, local nighttime encounters. Spawn, navigation and retirement all obey
// the same protected-ground checks; this never borrows the dungeon's floor state.
export function createNightEncounterSystem(T,{scene,camera,actors,audio,ground,water,pointClear,protectedPoint,lineOfSight,isNight,isEnabled,level,damagePlayer,reward,sfx,lowPower=false,random=Math.random,fleetTargets=()=>[],waterEffect=()=>{},isRaining=()=>false,onVanish=()=>{},deckContains=(boat,x,z,pad)=>Math.abs(x)<=1.3+pad&&z>=-2.3-pad&&z<=2.3+pad,worldPointClear=null,hullDamage=()=>{}}){
 const root=new T.Group();root.name='Day and night roaming encounters';scene.add(root);
 const entries=[],byRoot=new WeakMap(),tracers=[],maxPopulation=lowPower?4:8;
 // Weighted roster: the baseline breed is common, the specialist breeds are a surprise.
 const spawnTable=[['fisher_fists',17],['fisher_club',13],['fisher_gunner',10],['fisher_veteran',6],['bat',6],['bat_swift',4],['bat_dire',2],['slime',6],['slime_spitter',4],['slime_brute',2],['skeleton',5],['skeleton_guard',3],['skeleton_captain',2],['goblin',5],['goblin_slinger',3],['goblin_brute',2]];
 const kinds=spawnTable.map(entry=>entry[0]),spawnTotal=spawnTable.reduce((sum,entry)=>sum+entry[1],0);
 const pickKind=()=>{let roll=random()*spawnTotal;for(const [kind,weight] of spawnTable){roll-=weight;if(roll<=0)return kind}return spawnTable[0][0]};
 const viewPoint=new T.Vector3(),viewDirection=new T.Vector3(),pointCache=new Map();let clock=0,spawnClock=0,spawnAt=6,wasNight=false,cacheAt=0,serial=0;
 const horizontal=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
 // Bats are fliers: they cross open water instead of treating it as a wall.
 const flies=e=>e?.data?.kind==='bat'||e?.data?.base==='bat'||e?.root?.userData?.baseKind==='bat';
 // Water depth at a spot: the surface minus the seabed under it.
 const waterDepth=(x,z)=>water(x,z)-ground(x,z);
 // How deep a breed can stand before it is out of its depth. Land mobs walk into water
 // after a target in or on it, but the water only has to reach their waist before they
 // are as helpless as a crew member thrown overboard. The line is drawn from the
 // breed's own bulk (a slime drowns in a puddle, a goblin brute can push out to over a
 // metre) rather than one global number. Fliers do not wade at all.
 const BODY_HEIGHT={fisher:1.95,slime:1,skeleton:2,goblin:2.4};
 function waistDepth(e){
  if(flies(e))return 0;
  if(e.waistDepth!=null)return e.waistDepth;
  const base=e.def?.base||'fisher',scale=Math.max(.6,Number(e.def?.scale)||1);
  const height=(BODY_HEIGHT[base]||1.9)*scale;
  return (e.waistDepth=Math.max(.16,Math.min(1.25,height*.42)));
 }
 // Weapon families. Gun and thrown/acid all attack at range; acid and rocks lob slowly.
 const weaponOf=e=>e?.def?.weapon||'fists';
 const isRanged=e=>{const w=weaponOf(e);return w==='gun'||w==='thrown'||w==='acid'};
 const meleeDamage=e=>{const w=weaponOf(e),base=w==='club'?13:w==='bones'?10:w==='claws'?8:w==='slime'?11:9;return base*(e.def.damage||1)};
 const shotDamage=e=>(6+Math.min(e.level,16)*.35)*(e.def.damage||1);
 const lobGlobs=[];
 const openWaterClear=(x,z)=>typeof worldPointClear==='function'?worldPointClear(x,z):!protectedPoint(x,z)&&Math.abs(x)<245&&Math.abs(z)<215;
 function inView(p,height=2.4){
  camera.updateWorldMatrix(true,false);camera.getWorldDirection(viewDirection);
  for(const y of [.15,height*.5,height]){viewPoint.set(p.x,p.y+y,p.z);if(viewPoint.clone().sub(camera.position).dot(viewDirection)<=0)continue;viewPoint.project(camera);if(viewPoint.z>=-1&&viewPoint.z<=1&&Math.abs(viewPoint.x)<1.22&&Math.abs(viewPoint.y)<1.22)return true}return false;
 }
 function clearPoint(x,z,r=.6,flyer=false,wade=0){
  if(Math.abs(x)>245||Math.abs(z)>215||protectedPoint(x,z))return false;
  if(flyer)return true;
  // Spawning, patrol destinations and goal cells stay on dry land (wade 0). A mob
  // chasing a target into the water passes its own waist depth here, which lets it step
  // out to (and a little past) the line where it starts to drown, and no further.
  const limit=wade>0?wade*1.15:0;
  const key=Math.round(x*5)+','+Math.round(z*5)+','+Math.round(r*10)+','+Math.round(limit*20);if(pointCache.has(key))return pointCache.get(key);
  const y=ground(x,z),depth=water(x,z)-y;let okay=Number.isFinite(y)&&(wade>0?depth<=limit:depth<-.42)&&pointClear(x,z,r);
  if(okay)for(const [dx,dz]of [[r,0],[-r,0],[0,r],[0,-r]]){const h=ground(x+dx,z+dz),d=water(x+dx,z+dz)-h,tooWet=wade>0?false:d>=-.30,climb=wade>0?h-y>.22+r*.9:Math.abs(h-y)>.22+r*.9;if(tooWet||climb||protectedPoint(x+dx,z+dz)){okay=false;break}}
  pointCache.set(key,okay);return okay;
 }
 function clearSegment(a,b,r=.6,flyer=false,wade=0){const d=horizontal(a,b),n=Math.max(1,Math.ceil(d/.48));let h=ground(a.x,a.z);for(let i=1;i<=n;i++){const x=a.x+(b.x-a.x)*i/n,z=a.z+(b.z-a.z)*i/n,y=ground(x,z);if(flyer){if(!openWaterClear(x,z))return false;continue}if(!clearPoint(x,z,r,false,wade))return false;const rise=wade>0?y-h:Math.abs(y-h);if(rise>.22+d/n*.95)return false;h=y}return true}
 function findPath(from,to,r=.6,wade=0){
  if(!clearPoint(to.x,to.z,r,false,wade))return [];if(clearSegment(from,to,r,false,wade))return [{x:to.x,z:to.z}];
  const cell=1.4,pad=8,minX=Math.min(from.x,to.x)-pad,minZ=Math.min(from.z,to.z)-pad,width=Math.ceil((Math.abs(from.x-to.x)+2*pad)/cell)+1,height=Math.ceil((Math.abs(from.z-to.z)+2*pad)/cell)+1;
  if(width*height>3600)return [];const coord=id=>({x:minX+(id%width)*cell,z:minZ+Math.floor(id/width)*cell}),idFor=p=>Math.round((p.z-minZ)/cell)*width+Math.round((p.x-minX)/cell),start=idFor(from),goal=idFor(to),open=[start],cost=new Map([[start,0]]),parent=new Map(),closed=new Set();let attempts=0;
  while(open.length&&attempts++<1000){let best=0;for(let i=1;i<open.length;i++)if(cost.get(open[i])+horizontal(coord(open[i]),to)<cost.get(open[best])+horizontal(coord(open[best]),to))best=i;const id=open.splice(best,1)[0];if(closed.has(id))continue;if(id===goal){const path=[{x:to.x,z:to.z}];for(let at=id;at!==start&&parent.has(at);at=parent.get(at))path.push(coord(at));path.reverse();if(path.length&&!clearSegment(from,path[0],r,false,wade))return [];return path}closed.add(id);const p=coord(id),ix=id%width,iz=Math.floor(id/width);
   for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const x=ix+dx,z=iz+dz,next=z*width+x;if(x<0||x>=width||z<0||z>=height||closed.has(next))continue;const q=coord(next);if(!clearSegment(p,q,r,false,wade))continue;const c=cost.get(id)+Math.hypot(dx,dz)*cell;if(c>=(cost.get(next)??Infinity))continue;cost.set(next,c);parent.set(next,id);open.push(next)}
  }return [];
 }
 function approachGoal(e,goal){
  // A goal the mob's body cannot legally occupy (player standing in the shallows, a ledge).
  // Walk as close as the terrain allows instead of freezing in place.
  if(flies(e))return null;
  const p=e.root.position,d=horizontal(p,goal);if(d<.3)return null;
  for(let t=.86;t>=.12;t-=.13){
   const x=p.x+(goal.x-p.x)*t,z=p.z+(goal.z-p.z)*t;
   if(clearPoint(x,z,e.radius)&&clearSegment(p,{x,z},e.radius))return {x,z};
  }
  return null;
 }
 function wadeGoal(e,goal){
  // Walk straight at a target standing in (or on) the water, as far out as this breed can
  // legally stand. On a real beach that last stand is already past its waist, which is
  // where it starts to drown, so it never reaches the target itself.
  const limit=waistDepth(e);if(!limit)return null;
  const p=e.root.position;
  if(waterDepth(goal.x,goal.z)<=limit)return goal;
  let best=null;
  for(let t=.06;t<=1.0001;t+=.06){
   const x=p.x+(goal.x-p.x)*t,z=p.z+(goal.z-p.z)*t;
   if(!clearPoint(x,z,e.radius,false,limit))break;
   best={x,z};
  }
  return best;
 }
 function chaseGoal(e,goal){
  if(flies(e)||clearPoint(goal.x,goal.z,e.radius))return goal;
  const waded=wadeGoal(e,goal);
  if(waded)return waded;
  const a=e.approach;
  // A cached approach point that the mob is already standing on is worse than useless: it
  // would keep "walking" to its own feet forever. Recompute unless it is still ahead.
  if(a&&Math.abs(a.gx-goal.x)<.4&&Math.abs(a.gz-goal.z)<.4&&clock<a.at+.9&&horizontal(a,e.root.position)>.55)return a;
  const g=approachGoal(e,goal);
  if(!g)return goal;
  e.approach={x:g.x,z:g.z,gx:goal.x,gz:goal.z,at:clock};
  return e.approach;
 }
 function moveTo(e,goal,dt,speed,wade=0){
  const p=e.root.position,r=e.radius,flyer=flies(e);let next=goal;
  if(!clearSegment(p,goal,r,flyer,wade)){
   if(!e.navGoal||horizontal(e.navGoal,goal)>2||clock>e.navAt){e.navGoal={x:goal.x,z:goal.z};e.path=findPath(p,goal,r,wade);e.navAt=clock+1.7+(e.root.id%5)*.1}
   while(e.path?.length&&horizontal(e.path[0],p)<.3)e.path.shift();if(!e.path?.length)return false;
   let far=0;for(let i=1;i<Math.min(e.path.length,6);i++){if(!clearSegment(p,e.path[i],r,flyer,wade))break;far=i}if(far)e.path.splice(0,far);next=e.path[0];
  }else e.path=null;
  const d=horizontal(p,next);if(d<.08)return false;const step=Math.min(d,dt*speed),np={x:p.x+(next.x-p.x)/d*step,z:p.z+(next.z-p.z)/d*step};
  if(!clearSegment(p,np,r,flyer,wade))return false;
  for(const other of entries)if(other!==e&&other.data.alive&&horizontal(other.root.position,np)<e.radius+other.radius+.12&&horizontal(other.root.position,np)<horizontal(other.root.position,p))return false;
  p.x=np.x;p.z=np.z;e.root.rotation.y=Math.atan2(next.x-p.x,next.z-p.z);return true;
 }
 // Boarding a boat: swim or fly to the hull, vault the rail, then fight on deck.
 function boatOf(fleet){return fleet?.boat||null}
 function startBoarding(e,fleet){
  const boat=boatOf(fleet);if(!boat||!boat.visible||e.board?.boat===boat)return;
  const local=boat.worldToLocal(e.root.position.clone());
  e.board={boat,stage:'approach',side:local.x<0?-1:1,timer:0,jump:null,lastHit:0};
 }
 function boardingDeckPoint(boat,side){
  const roof=boat.userData.fleetModel?.userData.roofLevels?.[0]??2.10;
  return new T.Vector3(side*.95,.38,0);
 }
 function updateBoarding(e,dt){
  const board=e.board,boat=board.boat;
  const alive=boat.visible&&boat.parent;
  if(!alive){leaveBoat(e,false);return false}
  board.timer+=dt;const root=e.root;
  if(board.stage==='approach'){
   const local=boat.worldToLocal(root.position.clone());
   const goal=boat.localToWorld(new T.Vector3(board.side*1.85,.2,Math.max(-2.1,Math.min(2.1,local.z))));
   const dx=goal.x-root.position.x,dz=goal.z-root.position.z,d=Math.hypot(dx,dz);
   if(d>.35){const step=Math.min(d,dt*e.moveSpeed*1.15);root.position.x+=dx/d*step;root.position.z+=dz/d*step;root.rotation.y=Math.atan2(dx,dz)}
   const surface=water(root.position.x,root.position.z);
   const floatY=flies(e)?Math.max(ground(root.position.x,root.position.z),surface)+1.15:surface-.18+Math.sin(clock*3+e.id)*.06;
   root.position.y+= (floatY-root.position.y)*Math.min(1,dt*3);
   if(board.timer>.3&&clock>=(board.splashAt||0)){board.splashAt=clock+.7;waterEffect('splash',root.position,e)}
   if(d<=.35||board.timer>14){board.stage='jump';board.elapsed=0;board.from=root.position.clone();board.to=boat.localToWorld(boardingDeckPoint(boat,board.side));board.duration=.62}
   return true;
  }
  if(board.stage==='jump'){
   board.elapsed=Math.min(board.duration,board.elapsed+dt);const t=board.elapsed/board.duration;
   board.to=boat.localToWorld(boardingDeckPoint(boat,board.side));
   root.position.lerpVectors(board.from,board.to,t);root.position.y+=Math.sin(Math.PI*t)*1.05*Math.max(.6,boat.scale.y*.7);
   root.rotation.y=Math.atan2(board.to.x-board.from.x,board.to.z-board.from.z);
   const limbs=root.userData.limbPivots||[];for(const limb of limbs){if(limb.role==='leg')limb.pivot.rotation.x=.55+Math.sin(t*Math.PI)*(limb.side<0?-.42:.4);else limb.pivot.rotation.x=-1.15}
   if(t>=1){boat.attach(root);root.position.copy(boat.worldToLocal(board.to.clone()));root.rotation.set(0,Math.PI,0);root.userData.surface=false;board.stage='deck';e.boardedBoat=boat;board.lastHit=0}
   return true;
  }
  // On deck: fight the crew (or the hull) in boat-local space.
  const target=e.target?.fleet?.alive?.()?e.target:null;
  const point=target?target.point:null;
  let localTarget=point?boat.worldToLocal(point.clone()):new T.Vector3(0,1,0);
  const pose=root.position;
  if(!deckContains(boat,localTarget.x,localTarget.z,.2))localTarget=new T.Vector3(Math.max(-1.05,Math.min(1.05,localTarget.x)),.38,Math.max(-1.9,Math.min(1.9,localTarget.z)));
  const dx=localTarget.x-pose.x,dz=localTarget.z-pose.z,d=Math.hypot(dx,dz);
  const ranged=isRanged(e),hold=ranged?2.6:.9;
  if(d>hold){const step=Math.min(d,dt*e.moveSpeed*.8);const nx=pose.x+dx/d*step,nz=pose.z+dz/d*step;
   if(deckContains(boat,nx,nz,-.15)){pose.x=nx;pose.z=nz}}
  pose.y=.38;
  root.rotation.y=Math.atan2(dx,dz);
  const deckYaw=Math.atan2(Math.sin(root.rotation.y-Math.PI),Math.cos(root.rotation.y-Math.PI));
  e.attackTimer-=dt;e.meleeTimer-=dt;root.userData.attackMotion=Math.max(0,(root.userData.attackMotion||0)-dt);
  if(clock>=(board.shotAt||0)){
   board.shotAt=clock+.55;
   const surfaceEye=root.localToWorld(new T.Vector3(0,1.1,0));
   if(target&&d<(ranged?12:1.7)&&lineOfSight(surfaceEye,target.point,root,target.actor)){
    root.userData.attackMotion=.34;
    if(ranged){addTracer(actors.worldMuzzle(e),target.point);target.fleet.damage(shotDamage(e))}
    else{target.fleet.damage(meleeDamage(e)*.7);sfx('cloth',{position:surfaceEye,volume:.2})}
   }else if(!target&&e.target?.fleet){e.target.fleet.damage(4*(e.def.damage||1))}
   else{
    // Nothing in reach on deck: hit the hull it is standing on.
    if(clock>=(board.lastHit||0)){board.lastHit=clock+2.5;hullDamage(boat,3*(e.def.damage||1),root)}
   }
  }
  for(const limb of root.userData.limbPivots||[]){if(limb.role==='leg')limb.pivot.rotation.x=d>hold?Math.sin(clock*10+(limb.side<0?Math.PI:0))*.45:0}
  return true;
 }
 function leaveBoat(e,drop=true){
  const board=e.board;if(!board)return;e.board=null;e.boardedBoat=null;
  if(e.root.parent&&e.root.parent!==root){scene.attach(e.root)}
  e.root.userData.surface=true;
  if(drop){e.patrolAt=clock+1;e.target=null;e.memory=null}
 }
 function spawnAtPoint(kind,p){
  if(!kinds.includes(kind)||!clearPoint(p.x,p.z,kind.startsWith('slime')?kind==='slime_brute'?1.05:.72:.6)||entries.length>=maxPopulation)return null;
  const e=actors.createWorldEnemy(kind,p,Math.max(1,Math.min(20,level())),root);e.id=++serial;e.home={x:p.x,z:p.z};e.age=0;e.lastRelevant=clock;e.senseAt=0;e.target=null;e.memory=null;e.memoryUntil=0;e.patrolAt=clock+random()*1.5;e.patrolGoal=null;e.navAt=0;e.deathAge=0;e.creditUntil=0;entries.push(e);byRoot.set(e.root,e);return e;
 }
 function trySpawn(){
  if(!isEnabled()||entries.length>=maxPopulation)return null;
  camera.getWorldDirection(viewDirection);const facing=Math.atan2(viewDirection.x,viewDirection.z);
  for(let attempt=0;attempt<64;attempt++){const angle=attempt<40?facing+(random()-.5)*Math.PI*1.3:random()*Math.PI*2,distance=38+random()*36,p=new T.Vector3(camera.position.x+Math.sin(angle)*distance,0,camera.position.z+Math.cos(angle)*distance);p.y=ground(p.x,p.z);
   if(!clearPoint(p.x,p.z)||horizontal(p,camera.position)<36||entries.some(e=>horizontal(p,e.root.position)<6))continue;
   return spawnAtPoint(pickKind(),p);
  }return null;
 }
 function worldEye(e){return e.root.getWorldPosition(new T.Vector3()).add(new T.Vector3(0,e.root.userData.eyeHeight||(flies(e)?2:1.8),0))}
 function targetActor(e){const t=e.target;return t?(t.player?camera:t.enemy?t.enemy.root:t.fleet?t.fleet.actor||null:null):null}
 function targetAlive(t){if(!t)return false;if(t.player)return true;if(t.enemy)return t.enemy.data.alive;if(t.fleet)return t.fleet.alive();return false}
 const leashOf=t=>t?.fleet?70:29;
 function commitTarget(e,c){
  if(e.target?.actor!==c.actor)e.targetSince=clock;
  e.target=c;e.lostAt=0;e.lastSeen={x:c.point.x,z:c.point.z};e.memory=null;e.memoryStuck=0;e.approach=null;
  if(c.fleet&&!e.board)startBoarding(e,c.fleet);
 }
 // Picking a fight is deliberately sticky. A mob keeps the body it already committed
 // to while that body is alive and in sight; it only switches when the old target is
 // dead, out of sight for a couple of seconds, or when something *else* is hurting it.
 function acquire(e){
  const p=e.root.position,from=worldEye(e),candidates=[],pd=horizontal(p,camera.position);
  if(pd<(clock<e.creditUntil?27:20))candidates.push({player:true,actor:camera,point:camera.position.clone(),d:pd});
  for(const other of entries)if(other!==e&&other.data.alive&&other.def.faction!==e.def.faction){const d=horizontal(p,other.root.position);if(d<13)candidates.push({player:false,enemy:other,actor:other.root,point:worldEye(other),d})}
  for(const fleet of fleetTargets()){if(!fleet.alive())continue;const point=fleet.position(),d=horizontal(p,point);if(d<34)candidates.push({fleet,actor:fleet.actor,point,d})}
  candidates.sort((a,b)=>a.d-b.d);
  // Boats are legitimate targets even inside the harbour's protected ground: a hull
  // is not a spawn cell, and the mob still has to swim or fly the whole way out.
  const seen=[];
  for(const c of candidates){
    // A mob that has already committed to a fight may follow it further from home than a
    // fresh one would, so backing off a few metres never looks like it loses interest.
    if(horizontal(c.point,e.home)>Math.max(leashOf(c),e.data.aggro?46:0))continue;
    if(!c.fleet&&protectedPoint(c.point.x,c.point.z))continue;
    if(!lineOfSight(from,c.point,e.root,c.actor))continue;
    c.nextSight=clock+.18;seen.push(c);
  }
  // 1. Whoever hurt us from outside the current fight becomes the new target.
  if(e.retaliate&&clock<e.retaliate.until){
    const hit=seen.find(c=>c.actor===e.retaliate.actor);
    if(hit){commitTarget(e,hit);e.retaliate=null;return}
  }
  if(e.retaliate&&clock>=e.retaliate.until)e.retaliate=null;
  // 2. Stay on the current target while it is alive and visible.
  const current=e.target;
  if(current&&targetAlive(current)){
    const match=seen.find(c=>c.actor===current.actor);
    if(match){commitTarget(e,match);return}
    if(current.point)e.lastSeen={x:current.point.x,z:current.point.z};
    if(!e.lostAt)e.lostAt=clock;
    // A moment of cover is not a reason to abandon the fight.
    if(clock-e.lostAt<2.5&&e.lastSeen&&horizontal(e.lastSeen,e.home)<leashOf(current)+10)return;
  }else if(current)e.target=null;
  // 3. Anything else we can actually see beats walking blind after a lost target.
  const previous=targetActor(e);
  const next=seen.find(c=>c.actor!==previous);
  if(next){commitTarget(e,next);return}
  // 4. Nothing else to engage: go to where the target was last seen.
  if(e.lastSeen&&horizontal(e.lastSeen,e.home)<leashOf(current)+10){e.memory={x:e.lastSeen.x,z:e.lastSeen.z};e.memoryUntil=clock+9;e.approach=null;e.memoryStuck=0}
  e.target=null;e.lostAt=0;
 }
 function addTracer(from,to){const geometry=new T.BufferGeometry().setFromPoints([from,to]),material=new T.LineBasicMaterial({color:'#ffce87',transparent:true,opacity:.9}),line=new T.Line(geometry,material);line.userData.noLOSBlock=true;line.userData.noBulletHit=true;scene.add(line);tracers.push({line,age:0})}
 // Acid globs and thrown rocks travel visibly, so a moving target can step out of the way.
 function lobProjectile(weapon,actor,from,target,damage){
  const acid=weapon==='acid',mesh=new T.Mesh(new T.SphereGeometry(acid?.115:.10,8,6),new T.MeshBasicMaterial({color:acid?'#c9f06a':'#9a8f7d'}));
  mesh.position.copy(from);mesh.userData.noBulletHit=mesh.userData.noLOSBlock=true;scene.add(mesh);
  lobGlobs.push({mesh,from:from.clone(),to:target.point.clone(),target:{player:!!target.player,enemy:target.enemy||null,fleet:target.fleet||null},attacker:actor,damage,age:0,duration:Math.max(.34,Math.min(.95,from.distanceTo(target.point)/14)),acid});
 }
 function updateLobs(dt){
  for(let i=lobGlobs.length-1;i>=0;i--){
   const lob=lobGlobs[i];lob.age+=dt;const t=Math.min(1,lob.age/lob.duration);
   lob.mesh.position.lerpVectors(lob.from,lob.to,t);
   lob.mesh.position.y+=Math.sin(Math.PI*t)*Math.min(2.4,lob.from.distanceTo(lob.to)*.30);
   if(t<1)continue;
   const dest=lob.to;
   if(water(dest.x,dest.z)>ground(dest.x,dest.z)-.05)waterEffect('splash',dest,lob.attacker);
   const live=lob.target.player?camera.position:lob.target.enemy?.root?.getWorldPosition(new T.Vector3())||null;
   if(!live||live.distanceTo(dest)<1.15){
    if(lob.target.player)damagePlayer(lob.damage,lob.attacker);
    else if(lob.target.fleet)lob.target.fleet.damage(lob.damage);
    else if(lob.target.enemy?.data.alive)damage(lob.target.enemy,lob.damage,lob.attacker,lob.attacker);
   }
   scene.remove(lob.mesh);lob.mesh.material.dispose();lob.mesh.geometry.dispose();lobGlobs.splice(i,1);
  }
 }
 function damage(e,amount,source='player',attacker=null){
  if(!e?.data.alive||!Number.isFinite(amount)||amount<=0)return false;e.data.hp=Math.max(0,e.data.hp-amount);e.data.aggro=true;e.senseAt=0;
  if(source==='player'){e.creditUntil=clock+25;e.lastRelevant=clock;e.memory={x:camera.position.x,z:camera.position.z};e.memoryUntil=clock+8}
  // Damage from a third party outranks the fight we are already in: a fisherman being
  // chewed on by a slime while he shoots at the player turns around and fights the slime.
  if(attacker&&attacker!==targetActor(e)&&e.data.hp>0){
    if(!e.threats)e.threats=new Map();
    const record=e.threats.get(attacker)||{total:0,at:0};
    if(clock-record.at>3.2)record.total=0;
    record.total+=amount;record.at=clock;e.threats.set(attacker,record);
    if(record.total>=Math.max(7,e.data.maxHp*.10)||amount>=e.data.maxHp*.16){
      e.retaliate={actor:attacker,until:clock+10};e.senseAt=0;e.lostAt=0;
    }
  }
  audio.npcVoice(e.root,'hurt',e.data.kind,clock);
  if(e.data.hp<=0){if(e.board)leaveBoat(e,false);e.data.alive=false;e.root.userData.defeated=true;e.root.userData.attackMotion=0;if(e.root.userData.flash)e.root.userData.flash.visible=false;audio.resetNpcAudio(e.root);e.startY=e.root.position.y;e.startRotation=e.root.rotation.clone();actors.updateWorldBar(e,false,lineOfSight);if(e.creditUntil>clock)reward(e);sfx('enemyDown',{position:e.root.position,volume:.45})}return true;
 }
 function remove(e,vanish=false){if(e.board)leaveBoat(e,false);if(vanish){try{onVanish(e.root.getWorldPosition(new T.Vector3()),e.data.kind)}catch{}}e.data.alive=false;e.root.visible=false;actors.removeWorldEnemy(e);audio.resetNpcAudio(e.root);byRoot.delete(e.root);const index=entries.indexOf(e);if(index>=0)entries.splice(index,1)}
 function update(dt){
  dt=Math.min(.5,Math.max(0,dt));clock+=dt;if(clock>=cacheAt){cacheAt=clock+1;pointCache.clear()}
  const enabled=isEnabled(),night=isNight();root.visible=enabled;
  if(enabled)spawnClock+=dt*(isRaining()?3:1);
  if(night&&!wasNight)spawnAt=Math.min(spawnAt,spawnClock+4);wasNight=night;
  if(enabled&&spawnClock>=spawnAt){const spawned=trySpawn();spawnAt=spawnClock+(spawned?(entries.length<2?5:night?9+random()*5:13+random()*9):1)}
  for(const e of [...entries]){
   e.age+=dt;const g=e.root,p=g.position,distance=p.distanceTo(camera.position);
   if(!e.data.alive){e.deathAge+=dt;const t=Math.min(1,e.deathAge/1.1),ease=t*t*(3-2*t);g.position.y=e.startY-ease*.34;g.rotation.x=e.startRotation.x+ease*1.42;g.rotation.z=e.startRotation.z+(e.id%2?1:-1)*ease*.48;actors.updateWorldBar(e,false,lineOfSight);if(e.deathAge>1.5)remove(e,true);continue}
   if(g.userData.hitStunUntil>performance.now())continue;
   if(e.board&&e.data.alive){
    const world=e.root.getWorldPosition(new T.Vector3());
    if(world.distanceTo(camera.position)<80)e.lastRelevant=clock;
    if(!enabled){leaveBoat(e);continue}
    g.visible=true;actors.updateWorldBar(e,true,lineOfSight);
    updateBoarding(e,dt);
    actors.animateWorldEnemy(e,dt,true);g.position.y=.38;
    audio.updateNpcState(g,clock);e.data.x=world.x;e.data.z=world.z;
    continue;
   }
   const visible=enabled&&distance<100&&inView(p,e.data.kind==='bat'?3.5:2.4);
   if(visible&&distance<65||distance<26)e.lastRelevant=clock;
   const abandoned=distance>68&&clock-e.lastRelevant>30,dayRetire=!night&&distance>48&&clock-e.lastRelevant>25;
   if((abandoned||dayRetire)&&(!visible||!enabled)){remove(e);continue}
   g.visible=enabled;actors.updateWorldBar(e,enabled,lineOfSight);if(!enabled)continue;
   // Walkers lose their footing the moment the water reaches their own waist; a flier is
   // only in trouble when it is actually dunked. Either way they flounder and drown
   // exactly like a crew member who went overboard.
   const surface=water(p.x,p.z),waist=waistDepth(e),under=flies(e)?ground(p.x,p.z)<surface-.8:surface-ground(p.x,p.z)>=waist*.9;
   if(e.drowning||under&&(!flies(e)||p.y<surface+.35)){
    if(!e.drowning){e.drowning={age:0,velocity:0,voice:0,splash:0,stage:'falling'};e.target=null;g.userData.sinking=true;g.userData.drowning=true;audio.resetNpcAudio(g)}
    const d=e.drowning;d.age+=dt;actors.updateWorldBar(e,false,lineOfSight);
    if(d.stage==='falling'){d.velocity-=10*dt;p.y+=d.velocity*dt;if(p.y<=surface-.75){d.stage='struggling';d.age=0;waterEffect('splash',p,e)}}
    else{const fatigue=T.MathUtils.clamp((d.age-2.5)/1.5,0,1),sink=Math.max(0,d.age-4);d.stage=sink?'drowning':fatigue?'exhausted':'struggling';p.y=surface-1.1-fatigue*.23-sink*1.15+Math.sin(clock*13)*.10*(1-fatigue);g.rotation.x=-.15+fatigue*.3;g.rotation.z=Math.sin(clock*13)*.1*(1-fatigue);for(const limb of g.userData.limbPivots||[]){limb.pivot.rotation.x=Math.sin(clock*13+(limb.side||0)*Math.PI)*(.8-.65*fatigue)-(limb.role==='arm'?1.3:0)}if(clock>d.splash){d.splash=clock+.35;waterEffect(sink?'bubble':'splash',p,e)}if(clock>d.voice&&!sink){d.voice=clock+1.5;audio.npcVoice(g,'hurt',e.data.kind,clock)}if(d.age>5.8){damage(e,e.data.maxHp+1,'drown');remove(e)}}
    continue;
   }
   // Walkers may hold wet ground while they are fighting or crossing it, and while they
   // are standing in it and have to walk out again. An idle patrol keeps to dry land.
   const budget=flies(e)?0:(e.target||e.memory||waterDepth(p.x,p.z)>-.42)?waistDepth(e):0;
   e.attackTimer-=dt;e.meleeTimer-=dt;g.userData.attackMotion=Math.max(0,(g.userData.attackMotion||0)-dt);
   if(clock>=e.senseAt){e.senseAt=clock+.3+(e.id%3)*.025;acquire(e)}
   let target=e.target;
   if(target&&!targetAlive(target)){if(e.board)leaveBoat(e,false);e.target=target=null}
   if(target){
    const live=target.player?camera.position.clone():target.fleet?target.fleet.position():worldEye(target.enemy);
    target.point=live;target.d=horizontal(p,live);
    if(horizontal(live,e.home)>leashOf(target)||(!target.fleet&&protectedPoint(live.x,live.z))){
      // It ran too far: drop it, but keep the spot in memory in case nothing else is around.
      e.lastSeen={x:live.x,z:live.z};e.target=target=null;e.lostAt=clock;
    }else{
      let clear=true;
      if(clock>=(target.nextSight||0)){target.nextSight=clock+.18;clear=lineOfSight(worldEye(e),live,g,target.actor)}
      // Walk towards where the target was last seen, never towards through-wall intel.
      if(clear){target.move={x:live.x,z:live.z};e.lastSeen={x:live.x,z:live.z};e.lostAt=0}
      target.nextSight=target.nextSight||clock+.18;
      e.memory={x:(target.move||live).x,z:(target.move||live).z};e.memoryUntil=clock+7;if(target.player)e.lastRelevant=clock;
    }
   }
   let moving=false;
   if(g.userData.burning){if(!e.burnGoal||clock>e.burnAt){e.burnAt=clock+.8;e.burnGoal={x:p.x+Math.sin(e.id+clock)*4,z:p.z+Math.cos(e.id+clock)*4}}moving=moveTo(e,e.burnGoal,dt,e.moveSpeed*1.15,budget);target=null}
   else if(horizontal(p,e.home)>(e.data.aggro?42:27)){e.target=null;e.memory=null;e.stall=0;moving=moveTo(e,e.home,dt,e.moveSpeed*.8,budget)}
   else if(target&&target.fleet&&!e.board&&e.root.parent===root&&horizontal(p,target.point)<34){
    // Chasing a boat: climb aboard instead of pacing along the shoreline.
    startBoarding(e,target.fleet);moving=true;
   }
   else if(target){
    const dx=target.point.x-p.x,dz=target.point.z-p.z;g.rotation.y=Math.atan2(dx,dz);g.userData.aimPitch=T.MathUtils.clamp(Math.atan2(target.point.y-worldEye(e).y,Math.max(.1,target.d)),-.5,.5);const weapon=weaponOf(e),ranged=isRanged(e),from=actors.worldMuzzle(e),hold=ranged?9:1.5;if(clock>=(e.muzzleAt||0)||e.muzzleTarget!==target.actor){e.muzzleAt=clock+.18;e.muzzleTarget=target.actor;e.muzzleClear=lineOfSight(from,target.point,g,target.actor)}const clear=e.muzzleClear;
    if(target.d>hold||!clear)moving=moveTo(e,chaseGoal(e,target.move||target.point),dt,e.moveSpeed*.86,budget);
    // A chase that cannot advance — a ledge, a hull, a shoreline the mob refuses to swim,
    // a route that keeps failing — must not freeze the mob while it still hates the player.
    // Count stalled time and re-route, then give up the chase and go back to hunting rather
    // than standing still radiating threat.
    if(moving||target.d<=hold&&clear)e.stall=0;
    else{
      e.stall=(e.stall||0)+dt;
      if(e.stall>.35&&e.stall<.95){e.navGoal=null;e.path=null;e.approach=null;e.navAt=0}
      if(e.stall>=4.5){e.lastSeen={x:target.point.x,z:target.point.z};e.target=null;e.targetSince=0;e.stall=0;e.approach=null;e.navGoal=null;e.path=null;e.memory={x:target.point.x,z:target.point.z};e.memoryUntil=clock+6;e.memoryStuck=0;e.patrolAt=clock+1.2}
    }
    if(clear&&target.d<(ranged?25:1.9)&&(ranged?e.attackTimer:e.meleeTimer)<=0){
     if(!lineOfSight(actors.worldMuzzle(e),target.point,g,target.actor)){e.muzzleAt=0;e.muzzleClear=false;if(ranged)e.attackTimer=.15;else e.meleeTimer=.15}
     else if(!ranged||weapon!=='gun'||audio.tryNpcShot(g,clock,{capacity:e.data.kind==='fisher_veteran'?8:6,reloadSeconds:2.7})){
      g.userData.attackMotion=.34;const amount=ranged?shotDamage(e):meleeDamage(e);
      if(ranged){
        // A gun cracks instantly; slime acid and thrown rocks visibly arc across the gap.
        if(weapon==='gun'){e.attackTimer=1.45+random()*.35;addTracer(actors.worldMuzzle(e),target.point)}
        else{e.attackTimer=(weapon==='acid'?2.15:1.95)+random()*.45;lobProjectile(weapon,g,from,target,amount)}
      }else e.meleeTimer=1.15;
      if(target.player)damagePlayer(amount,g);else if(target.fleet)target.fleet.damage(amount);else damage(target.enemy,amount,e,g);
     }else e.attackTimer=.15;
    }
   }else if(e.memory&&clock<e.memoryUntil&&horizontal(p,e.memory)>.7){
    // Walking to a remembered spot. If it is unreachable (last seen over water or up a
    // cliff) give up quickly instead of standing frozen until the memory expires.
    moving=moveTo(e,chaseGoal(e,e.memory),dt,e.moveSpeed*.75,budget);
    if(moving)e.memoryStuck=0;
    else if((e.memoryStuck=(e.memoryStuck||0)+dt)>1.2){e.memory=null;e.memoryStuck=0;e.patrolAt=clock}
   }
   else{
    e.memory=null;if(e.patrolGoal&&horizontal(p,e.patrolGoal)<.35){e.patrolGoal=null;e.patrolAt=clock+1.5+random()*2.5}
    if(!e.patrolGoal&&clock>=e.patrolAt){e.patrolAt=clock+2;for(let tries=0;tries<10;tries++){const angle=random()*Math.PI*2,r=2.5+random()*7.5,goal={x:e.home.x+Math.sin(angle)*r,z:e.home.z+Math.cos(angle)*r};if(!clearPoint(goal.x,goal.z,e.radius)||entries.some(other=>other!==e&&horizontal(goal,other.root.position)<1.6))continue;if(findPath(p,goal,e.radius).length){e.patrolGoal=goal;e.navGoal=null;break}}}
    if(e.patrolGoal)moving=moveTo(e,e.patrolGoal,dt,e.moveSpeed*.46,budget);
   }
   actors.animateWorldEnemy(e,dt,moving);
   // Wading is wet work: a splash when a walker first breaks the surface.
   if(!flies(e)){const wet=waterDepth(p.x,p.z);if(wet>.1){if(clock>=(e.wetAt||0)){e.wetAt=clock+.85;waterEffect('splash',p,e)}}else e.wetAt=0}
   // A flier over open water keeps altitude above the surface, never the seabed.
   if(flies(e))g.position.y=Math.max(ground(p.x,p.z),water(p.x,p.z))+1.15+Math.sin(clock*1.4+e.id)*.25;
   audio.npcEngagement(g,!!target,e.data.kind,clock);audio.updateNpcState(g,clock);e.data.x=p.x;e.data.z=p.z;
  }
  updateLobs(dt);
  for(let i=tracers.length-1;i>=0;i--){const t=tracers[i];t.age+=dt;t.line.material.opacity=Math.max(0,1-t.age/.14);if(t.age>=.14){scene.remove(t.line);t.line.geometry.dispose();t.line.material.dispose();tracers.splice(i,1)}}
 }
 function actorFor(object){for(let n=object;n;n=n.parent){const e=byRoot.get(n);if(e)return e}return null}
 return {update,entries,root,kinds,maxPopulation,trySpawn,spawnAtPoint,startBoarding,leaveBoat,boarded:()=>entries.filter(e=>e.board),clearPoint,clearSegment,findPath,inView,damage,remove,actorFor,damageObject:(object,amount)=>damage(actorFor(object),amount,'player'),getTargets:()=>isEnabled()?entries.filter(e=>e.data.alive&&e.root.visible).map(e=>{e.root.updateWorldMatrix(true,true);return e.root}):[],statusActors:()=>isEnabled()?entries.filter(e=>e.data.alive).map(e=>({actor:e.root,kind:e.def.faction==='fisher'?'human':'monster',human:e.def.faction==='fisher',radius:e.radius,height:e.data.kind==='bat'?3:2,waterHeight:.12,position:()=>e.root.getWorldPosition(new T.Vector3()),alive:()=>e.data.alive,damage:n=>damage(e,n,'status')})):[],clear:()=>{for(const e of [...entries])remove(e);for(const lob of lobGlobs){scene.remove(lob.mesh);lob.mesh.material.dispose();lob.mesh.geometry.dispose()}lobGlobs.length=0},clock:()=>clock};
}
