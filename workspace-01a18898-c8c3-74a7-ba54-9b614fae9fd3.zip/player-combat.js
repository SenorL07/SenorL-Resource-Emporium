// Embedded game-scoped player loadout, melee and damage presentation.
function playerFriendlyObject(object){
 if(!object||!U.gillTycoonHired)return false;
 // Hired hull and crew are protected; their breakable equipment is fair game.
 if(boatComponentFor(object))return false;
 for(let n=object;n;n=n.parent)if(n===ze||n===ei||n===hiredMechanic||Yi.includes(n)||J0.includes(n))return true;
 return false;
}
// The actual wavy surface only produces feedback; it is never a damage collider.
function waterAttackCrossing(origin,direction,range){
 if(Tn.active||range<=0)return null;let start=0,end=range;
 if(Math.abs(direction.y)<1e-7){if(Math.abs(origin.y)>.32)return null}
 else{const a=(-.32-origin.y)/direction.y,b=(.32-origin.y)/direction.y;start=Math.max(0,Math.min(a,b));end=Math.min(range,Math.max(a,b));if(start>end)return null}
 let previous=start,previousSide=origin.y+direction.y*start-gi(origin.x+direction.x*start,origin.z+direction.z*start);
 for(let t=start+.65;t<=end+.65;t+=.65){const at=Math.min(t,end),x=origin.x+direction.x*at,z=origin.z+direction.z*at,side=origin.y+direction.y*at-gi(x,z);
  if(previousSide*side<=0&&Math.abs(previousSide-side)>1e-8){let lo=previous,hi=at;for(let k=0;k<8;k++){const mid=(lo+hi)/2,diff=origin.y+direction.y*mid-gi(origin.x+direction.x*mid,origin.z+direction.z*mid);if((previousSide>=0)===(diff>=0))lo=mid;else hi=mid}const distance=(lo+hi)/2,point=origin.clone().addScaledVector(direction,distance);point.y=gi(point.x,point.z);if(combatGroundHeight(point.x,point.z)<point.y-.02)return {point,distance}}
  previous=at;previousSide=side;if(at===end)break;
 }return null;
}
var FISTS={id:'fists',name:'Bare Fists',mag:0,interval:13/35*1000,pellets:1,damage:14,spread:0,auto:true};
var playerCombat={magazines:new Map(),switchUntil:0,fistAt:0,punchUntil:0,punchSide:1,hurt:null,materials:[],lastGrunt:-Infinity,ui:null};
function capacityFor(id){const g=_r.find(g=>g.id===id);return g?.ammo?Math.floor(g.mag*(1+(U.upgrades.magazine||0)*.1)):0}
function roundsFor(id){const g=_r.find(g=>g.id===id);return g?.ammo?he.clamp(Math.floor(U.classicAmmo?.[g.ammo]??g.mag),0,capacityFor(id)):0}
function magazineFor(id){let m=playerCombat.magazines.get(id);if(!m){m={reloadUntil:0,shotAt:0};playerCombat.magazines.set(id,m)}return m}
function initLoadout(){
 U.classicAmmo=U.classicAmmo&&typeof U.classicAmmo==='object'?U.classicAmmo:{bullets:200,shells:50,rockets:0,cells:0};
 U.weapons=[...new Set(['sidearm',...(Array.isArray(U.weapons)?U.weapons:[])])].filter(id=>_r.some(g=>g.id===id));
 const old=Array.isArray(U.gunSlots)?U.gunSlots:[U.weapons.includes(U.weapon)?U.weapon:'sidearm',U.weapons.find(id=>id!==U.weapon)||null];
 const first=U.weapons.includes(old[0])?old[0]:'sidearm';U.gunSlots=[first,U.weapons.includes(old[1])&&old[1]!==first?old[1]:null];
 U.weaponAmmo=U.weaponAmmo&&typeof U.weaponAmmo==='object'&&!Array.isArray(U.weaponAmmo)?U.weaponAmmo:{};
 for(const id of U.weapons)U.weaponAmmo[id]=roundsFor(id);
 let slot=Number.isInteger(U.activeSlot)?U.activeSlot:U.weapon==='fists'?2:U.gunSlots.indexOf(U.weapon);if(slot<0||slot>2||slot<2&&!U.gunSlots[slot])slot=0;
 U.activeSlot=slot;U.weapon=slot===2?'fists':U.gunSlots[slot];zs=roundsFor(U.weapon);
}
function selectWeaponSlot(slot){
 if(!xi||playerDeath.active||slot<0||slot>2||slot<2&&!U.gunSlots[slot])return;
 if(U.weapon!=='fists')U.weaponAmmo[U.weapon]=zs;
 U.activeSlot=slot;U.weapon=slot===2?'fists':U.gunSlots[slot];zs=roundsFor(U.weapon);const m=magazineFor(U.weapon);a0=m.reloadUntil;o0=U.weapon==='fists'?playerCombat.fistAt:m.shotAt;
 Qc=false;Sc=0;Pc=O0=0;playerMuzzleUntil=0;U0.intensity=0;playerCombat.switchUntil=performance.now()+180*Math.max(.6,1-U.upgrades.trigger*.07);$_(U.weapon);mn();Mn();It('cloth',{volume:.2});
}
function equipGunSlot(id,slot){
 if(!U.weapons.includes(id)||!_r.some(g=>g.id===id))return;slot=slot===1?1:0;
 if(U.weapon!=='fists')U.weaponAmmo[U.weapon]=zs;
 const other=1-slot;if(U.gunSlots[other]===id){U.gunSlots[other]=U.gunSlots[slot]===id?null:U.gunSlots[slot]}
 U.gunSlots[slot]=id;selectWeaponSlot(slot);ao('loadout');
}
function refreshLoadoutHUD(){
 if(!playerCombat?.ui)return;playerCombat.ui.style.display=xi&&!xr?'flex':'none';playerCombat.ui.querySelectorAll('button').forEach((b,i)=>{const id=i===2?'fists':U.gunSlots?.[i],name=id==='fists'?'FISTS':_r.find(g=>g.id===id)?.name||'EMPTY';b.textContent=String(i+1);b.title=name;b.setAttribute('aria-label','Slot '+(i+1)+': '+name);b.disabled=!id;b.classList.toggle('selected',i===U.activeSlot);b.setAttribute('aria-pressed',String(i===U.activeSlot))});
 Ke('#ammo').textContent=!th().ammo?'MELEE':`${zs} ${th().ammo.toUpperCase()}`;
 const reload=Ke('#reloadBtn');if(reload){reload.disabled=true;reload.style.display="none"};const fire=Ke('#fireBtn');if(fire)fire.textContent=U.weapon==='fists'?'PUNCH':U.weapon==='chainsaw'?'SAW':'FIRE';
}
function playerHurt(amount,attacker=null){
 if(!xi||playerDeath.active||!(amount>0))return;let point=null;if(attacker?.getWorldPosition)point=attacker.getWorldPosition(new w());else if(attacker&&Number.isFinite(attacker.x)&&Number.isFinite(attacker.z))point=attacker;
 const delta=point?point.clone().sub(oe.position):new w(-Math.sin(ln),0,-Math.cos(ln));delta.y=0;if(delta.lengthSq()<1e-6)delta.set(-Math.sin(ln),0,-Math.cos(ln));delta.normalize();
 playerCombat.hurt={start:Mt,direction:delta,strength:he.clamp(.7+amount/40,.7,1.35)};
 if(Mt-playerCombat.lastGrunt>.14){playerCombat.lastGrunt=Mt;It('human-hurt',{volume:.6,category:'voice',key:'player-hurt',cooldown:130,maxAge:300,rate:.96+Math.random()*.12})}
}
function updatePlayerCombat(dt){
 if(playerCombat.ui)playerCombat.ui.style.display=xi&&!xr?'flex':'none';
 const now=performance.now();for(const [id,m]of [])if(m.reloadUntil&&now>=m.reloadUntil){m.reloadUntil=0;U.weaponAmmo[id]=capacityFor(id);if(U.weapon===id){zs=U.weaponAmmo[id];a0=0;mn()}Mn()}
 let flash=0;const hurt=playerCombat.hurt;if(hurt){const age=Mt-hurt.start;if(age>=.55)playerCombat.hurt=null;else{const envelope=Math.sin(Math.PI*Math.pow(he.clamp(age/.55,0,1),.6))*hurt.strength,side=hurt.direction.dot(new w(Math.cos(ln),0,-Math.sin(ln))),front=hurt.direction.dot(new w(-Math.sin(ln),0,-Math.cos(ln)));oe.rotateX(front*envelope*.055);oe.rotateZ(-side*envelope*.115);flash=Math.max(0,Math.sin(age/.55*Math.PI*3.5))*.82+.12}}
 for(const entry of playerCombat.materials){entry.material.color.copy(entry.color);if(flash)entry.material.color.lerp(new Ee('#ff2020'),Math.min(1,flash));}
 const punch=Math.max(0,(playerCombat.punchUntil-Mt)/.28),swing=Math.sin(punch*Math.PI);if(U.weapon==='fists'){ti.position.x=he.lerp(ti.position.x,0,Math.min(1,dt*14));const model=Y_.get('fists');model?.children.forEach((hand,i)=>hand.position.z=-.2-(i===playerCombat.punchSide?swing*.65:0))}
}
function initPlayerCombat(){
 initLoadout();
 const fists=new gt();fists.name='First person fists';for(const side of [-1,1]){const hand=new gt();hand.position.set(side*.5,-.08,-.2);Bt(hand,[.29,.27,.37],ht('#c79370'),[0,0,-.2]);Bt(hand,[.24,.55,.24],ht('#b47c5d'),[0,-.32,.04],[-.2,0,0]);fists.add(hand)}ti.add(fists);Y_.set('fists',fists);
 const gunHands=new gt();gunHands.name='First person gun hands';Bt(gunHands,[.21,.26,.24],ht('#c79370'),[.02,-.45,.16]);Bt(gunHands,[.21,.31,.24],ht('#c79370'),[-.19,-.21,-.35]);ti.add(gunHands);playerCombat.gunHands=gunHands;
 const seen=new Set();ti.traverse(mesh=>{if(!mesh.isMesh||!mesh.material)return;mesh.material=mesh.material.clone();if(mesh.material.color&&!seen.has(mesh.material)){seen.add(mesh.material);playerCombat.materials.push({material:mesh.material,color:mesh.material.color.clone()})}});
 const style=document.createElement('style');style.textContent='#loadoutbar{position:fixed;right:15px;bottom:160px;display:flex;gap:5px;z-index:9;max-width:96vw}#loadoutbar button{background:#152824df;color:#c8d5c8;border:1px solid #587066;border-radius:4px;padding:0;width:30px;height:30px;font:600 12px system-ui;cursor:pointer;touch-action:manipulation}#loadoutbar button.selected{border-color:#e9bb6f;background:#3a4931;color:#fff2cd}#loadoutbar button:disabled{opacity:.4}@media(pointer:coarse){#loadoutbar{bottom:160px;right:15px}#loadoutbar button{padding:0;width:32px;height:32px;font-size:12px}}';document.head.append(style);
 const ui=document.createElement('div');ui.id='loadoutbar';ui.setAttribute('aria-label','Weapon slots');for(let i=0;i<3;i++){const b=document.createElement('button');b.addEventListener('pointerdown',e=>e.stopPropagation());b.addEventListener('click',e=>{e.stopPropagation();if(!xr)selectWeaponSlot(i)});ui.append(b)}document.body.append(ui);playerCombat.ui=ui;
 Ki.addEventListener('wheel',event=>{if(!xi||xr)return;event.preventDefault();const direction=event.deltaY>0?1:-1;for(let step=1;step<=3;step++){const slot=(U.activeSlot+direction*step+6)%3;if(slot===2||U.gunSlots[slot]){selectWeaponSlot(slot);break}}},{passive:false});
 refreshLoadoutHUD();
}

function consumeClassicAmmo(g){if(g.ammo){U.classicAmmo[g.ammo]=Math.max(0,roundsFor(g.id)-(g.costAmmo||1));zs=roundsFor(g.id)}else zs=0}
function renderClassicLoadout(){let out='<p class="menu-intro">Choose two weapons from your owned collection. Slot 3 is always fists. Buy weapons and ammunition separately in SHOP.</p>';for(const g of _r.filter(g=>U.weapons.includes(g.id)))out+=`<article class="item"><h3>${g.name}</h3><p>${g.desc}</p><div class="meta">${g.ammo?roundsFor(g.id)+' '+g.ammo.toUpperCase():'NO AMMO NEEDED'}</div><button data-action="equip1:${g.id}">${U.gunSlots[0]===g.id?'SLOT 1 ✓':'EQUIP SLOT 1'}</button> <button data-action="equip2:${g.id}">${U.gunSlots[1]===g.id?'SLOT 2 ✓':'EQUIP SLOT 2'}</button></article>`;return out+'<article class="item"><h3>3 · Bare Fists</h3><p>Permanent melee slot. Hits knock NPCs back and stun them for 0.3 seconds.</p></article>'}
var meleeReactions=new Map(),classicProjectiles=[];
function meleeImpact(object,point,source='player'){
 if(source==='player'&&playerFriendlyObject(object))return;
 if(source==='player')notifyPlayerBoatHit(object);
 const entry=burnRoster().find(e=>e.actor!==oe&&e.kind!=='hull'&&e.kind!=='prop'&&(e.actor===object||e.actor.getObjectById(object.id)));
 if(!entry)return;const a=entry.actor,world=a.getWorldPosition(new w()),away=world.clone().sub(oe.position);away.y=0;if(away.lengthSq()<.001)away.set(0,0,-1);away.normalize();
 const end=world.clone().addScaledVector(away,.32),from=world.clone();from.y+=.8;const to=end.clone();to.y+=.8;
 const clear=Tn.active?Tn.statusLineOfSight(from,to,a,null):Jc(from,to,a,null);if(!clear)end.copy(world);
 let local=a.parent.worldToLocal(end.clone());if([ge,it,ze].includes(a.parent))local=crewHullMove(a.parent,a.position,local);const delta=local.sub(a.position);const prev=meleeReactions.get(a),rotation=prev?.rotation||a.rotation.clone();
 if([ge,it,ze].includes(a.parent)&&!a.userData.resting&&!a.userData.sleeping&&!a.userData.sleepAlert&&!a.userData.postRecovery&&!a.userData.boarding)a.userData.postRecovery={home:crewNavigationPost(bm,a.position),path:null};
 a.userData.hitStunUntil=performance.now()+300;a.userData.attackMotion=0;
 meleeReactions.set(a,{start:performance.now(),from:a.position.clone(),delta,rotation,parent:a.parent,poses:a.children.map(c=>[c,c.rotation.clone()])});
 for(let k=0;k<7;k++)Wo(point.clone(),away.clone().multiplyScalar(.6+Math.random()).add(new w((Math.random()-.5)*2,1+Math.random(),(Math.random()-.5)*2)),'spark');
}
function updateMeleeReactions(after){const now=performance.now();for(const [a,r]of meleeReactions){if(!a.parent||a.parent!==r.parent||a.userData.defeated||a.userData.alive===false){meleeReactions.delete(a);continue}const t=he.clamp((now-r.start)/300,0,1);if(after||t>=1){a.position.copy(r.from).addScaledVector(r.delta,1-Math.pow(1-t,3));a.rotation.copy(r.rotation);a.rotation.z+=Math.sin(t*Math.PI)*.16;for(const [child,rotation]of r.poses)child.rotation.copy(rotation)}if(t>=1){a.rotation.copy(r.rotation);meleeReactions.delete(a)}}}
function classicTargets(){return Qa.filter(a=>a.userData.alive&&a.visible).concat(I0,gillGangway,Vd,f0,p0,wd,[...Xc.values()],cn||[],Qt?to:[],$I(),KI(),hiredBulletTargets(),navalCombat?.bridges||[],nightEncounters.getTargets(),...[...boatEquipment.values()].flatMap(d=>d.parts.filter(p=>p.hp>0&&p.boat.visible).map(p=>p.root)))}
var combatRayCache={time:-1,meshes:[]},combatRaySphere=new bm.Sphere(),combatRayHits=[],combatInstanceCache=new WeakMap(),combatInstanceProxy=new Me();
function prepareCombatRays(){if(combatRayCache.time===Mt)return;combatRayCache.time=Mt;const meshes=[],seen=new Set();const visit=node=>{if(!node||!node.visible||node===Vd||node===Fc||node.userData.waterSurface||node.userData.noBulletHit)return;if(node.isMesh&&!seen.has(node)){seen.add(node);node.updateWorldMatrix(true,false);if(!node.geometry.boundingSphere)node.geometry.computeBoundingSphere();
 if(node.isInstancedMesh){let cache=combatInstanceCache.get(node);const signature=node.matrixWorld.elements.join(',')+':'+node.instanceMatrix.version+':'+node.count;if(!cache||cache.signature!==signature){const entries=[],matrix=new bm.Matrix4();for(let i=0;i<node.count;i++){node.getMatrixAt(i,matrix);const world=new bm.Matrix4().multiplyMatrices(node.matrixWorld,matrix);entries.push({mesh:node,instanceId:i,matrix:world,sphere:node.geometry.boundingSphere.clone().applyMatrix4(world)})}cache={signature,entries};combatInstanceCache.set(node,cache)}meshes.push(...cache.entries)}else meshes.push({mesh:node,sphere:node.geometry.boundingSphere.clone().applyMatrix4(node.matrixWorld)})}for(const child of node.children)visit(child)};for(const root of classicTargets())visit(root);combatRayCache.meshes=meshes}
function combatGroundHeight(x,z){const count=qc.parameters.widthSegments,size=600/count,gx=(x+300)/size,gz=(z-Vd.position.z+300)/size,ix=Math.floor(gx),iz=Math.floor(gz);if(ix<0||iz<0||ix>=count||iz>=count)return tE(x,z);const u=gx-ix,v=gz-iz,stride=count+1,i=iz*stride+ix,a=Ed.getY(i),b=Ed.getY(i+stride),c=Ed.getY(i+stride+1),d=Ed.getY(i+1);return u+v<=1?a+(d-a)*u+(b-a)*v:c+(b-c)*(1-u)+(d-c)*(1-v)}
function classicRay(origin,direction,range){const ray=new kr(origin,direction,0,range);if(Tn.active)return Tn.raycast(ray);prepareCombatRays();let best=null;
 for(const entry of combatRayCache.meshes){const mesh=entry.mesh;combatRaySphere.copy(entry.sphere);if(!ray.ray.intersectsSphere(combatRaySphere)||origin.distanceTo(combatRaySphere.center)-combatRaySphere.radius>ray.far)continue;combatRayHits.length=0;if(entry.instanceId!==undefined){combatInstanceProxy.geometry=mesh.geometry;combatInstanceProxy.material=mesh.material;combatInstanceProxy.matrixWorld.copy(entry.matrix);combatInstanceProxy.raycast(ray,combatRayHits);for(const hit of combatRayHits){hit.object=mesh;hit.instanceId=entry.instanceId}}else mesh.raycast(ray,combatRayHits);for(const h of combatRayHits)if(h.distance<=ray.far&&visibleBulletObject(h.object)){best=h;ray.far=h.distance}}
 // Water is a medium, not cover. Only the seabed/terrain can stop this ray.
 const limit=ray.far;let prev=0;for(let t=.02;t<=limit+1.25;t+=1.25){const d=Math.min(t,limit),q=origin.clone().addScaledVector(direction,d);if(q.y<=combatGroundHeight(q.x,q.z)){let lo=prev,hi=d;for(let k=0;k<7;k++){const mid=(lo+hi)/2,p=origin.clone().addScaledVector(direction,mid);if(p.y<=combatGroundHeight(p.x,p.z))hi=mid;else lo=mid}const point=origin.clone().addScaledVector(direction,hi);return {point,distance:hi,object:Vd,face:{normal:new w(0,1,0)}}}prev=d;if(d===limit)break}return best;
}
function classicDamage(object,damage){if(equipmentDamage(object,damage))return;if(playerFriendlyObject(object))return;if(object===Fc||object?.userData?.waterSurface)return;notifyPlayerBoatHit(object);if(Tn.active)return Tn.damageEnemyObject(object,damage);if(navalCombat?.isBridge(object))return navalCombat.damageBridge(damage,object);if(nightEncounters.actorFor(object))return nightEncounters.damageObject(object,damage);if(P0(object)||On&&it.getObjectById(object.id))return Db(object,damage);if(D0(object))return fD(object,damage);const hired=hiredCrewRoot(object);if(hired)return;if(Qt&&ge.getObjectById(object.id))return mD(damage)}
var projectileGeometry=new on(.10,8,6),projectileMaterials=new Map(),projectileFree=[],rocketPool=[],projectileSpritePools={burst:[],bfg:[]},projectileSpriteMats=new Map();
// Doom's plasma bolt and BFG shot are sprite projectiles; the rocket is a small missile with a smoke trail.
function projectileSpriteMaterial(kind){
 let material=projectileSpriteMats.get(kind);
 if(!material){
  material=new So({map:particleAssets.plasma_01,color:kind==='bfg'?'#9bff62':'#a9e9ff',transparent:true,opacity:.96,depthWrite:false,depthTest:true,blending:Jp,fog:false});
  material.userData.noBulletHit=true;projectileSpriteMats.set(kind,material);
 }
 return material;
}
function projectileSprite(kind){
 const pool=projectileSpritePools[kind];let sprite=pool.pop();
 if(!sprite){sprite=new fa(projectileSpriteMaterial(kind));sprite.userData.noBulletHit=true;sprite.userData.noLOSBlock=true;sprite.renderOrder=6}
 sprite.visible=true;sprite.scale.setScalar(kind==='bfg'?1.45:.62);
 return {object:sprite,kind};
}
function rocketProjectile(){
 let group=rocketPool.pop();
 if(!group){
  group=new gt();group.name='Rocket projectile';
  const body=new Me(new Xt(.05,.062,.40,6),ht('#c9cdc3'));body.rotation.x=Math.PI/2;group.add(body);
  const nose=new Me(new Jn(.062,.17,6),ht('#a5442f'));nose.rotation.x=-Math.PI/2;nose.position.z=-.27;group.add(nose);
  for(let i=0;i<4;i++){const fin=new Me(new Ot(.012,.10,.15),ht('#8d9188'));fin.position.set(Math.cos(i*Math.PI/2)*.068,Math.sin(i*Math.PI/2)*.068,.17);fin.rotation.z=i*Math.PI/2;group.add(fin)}
  const flame=new fa(new So({map:particleAssets.flame_01,color:'#ffb45a',transparent:true,depthWrite:false,blending:Jp,fog:false}));flame.scale.setScalar(.34);flame.position.z=.28;flame.userData.noBulletHit=true;group.add(flame);group.userData.flame=flame;
  group.traverse(o=>{o.userData.noBulletHit=true;o.userData.noLOSBlock=true});
 }
 group.visible=true;return {object:group,kind:'rocket'};
}
function launchClassicProjectile(g){
 const dir=new w();oe.getWorldDirection(dir);const origin=oe.position.clone().addScaledVector(dir,.22);
 const visual=g.id==='marksman'?rocketProjectile():projectileSprite(g.id==='bfg'?'bfg':'burst');
 const mesh=visual.object;
 mesh.position.copy(origin);mesh.rotation.set(Sn,ln,0,'YXZ');mesh.visible=g.id!=='bfg';mesh.userData.noBulletHit=true;mesh.userData.noLOSBlock=true;st.add(mesh);
 if(classicProjectiles.length>=64)disposeClassicProjectile(classicProjectiles[0]);
 // Speeds converted from Doom's map units per tic (rocket 700/s, plasma and BFG 875/s).
 classicProjectiles.push({mesh,visual,dir,gun:g,age:0,charge:g.id==='bfg'?30/35:0,speed:g.id==='marksman'?22:27,origin:oe.position.clone(),yaw:ln,dungeon:Tn.active,trail:0});
 if(g.id==='bfg')It('bfgCharge',{volume:.5,rate:1,key:'bfg-charge',cooldown:400});
 else It('shot',{weapon:g.id,volume:.6,rate:g.id==='burst'?1.5:1});
 Pc=Math.min(.14,Pc+.035);
}
function disposeClassicProjectile(p){
 st.remove(p.mesh);
 if(p.visual&&p.visual.kind==='rocket'){p.mesh.visible=false;if(rocketPool.length<12)rocketPool.push(p.mesh)}
 else if(p.visual){p.mesh.visible=false;const pool=projectileSpritePools[p.visual.kind];if(pool&&pool.length<16)pool.push(p.mesh)}
 else if(projectileFree.length<24)projectileFree.push(p.mesh);
 classicProjectiles.splice(classicProjectiles.indexOf(p),1);
}
var classicProjectileCursor=0;
function projectileSplash(point,p,radius,power){
 for(const e of burnRoster()){if(!e.alive()||playerFriendlyObject(e.actor))continue;const q=e.position();q.y+=(e.height||1)*.5;const d=q.distanceTo(point),from=point.clone().addScaledVector(p.dir,-.12);if(d<radius&&(Tn.active?Tn.statusLineOfSight(from,q,null,e.actor):Jc(from,q,null,e.actor)))e.damage(Math.round(power*(1-d/radius)))}
}
function updateClassicProjectiles(dt){for(const p of classicProjectiles){p.pending=(p.pending||0)+dt;p.age+=dt}const list=[...classicProjectiles],start=classicProjectileCursor%Math.max(1,list.length),until=performance.now()+2.5;let checked=0,impactBudget=2;
 for(let i=0;i<list.length;i++){if(i&&performance.now()>=until)break;const p=list[(start+i)%list.length];checked++;
 if(p.dungeon!==Tn.active){disposeClassicProjectile(p);continue}if(p.age<p.charge){p.pending=0;continue}const step=p.pending;p.pending=0;p.mesh.visible=true;const distance=p.speed*step,hit=classicRay(p.mesh.position,p.dir,distance);
 const groundHit=!Tn.active&&p.mesh.position.y<combatGroundHeight(p.mesh.position.x,p.mesh.position.z);
 const crossing=!Tn.active&&waterAttackCrossing(p.mesh.position,p.dir,hit?.distance??distance);if(crossing&&impactBudget>0){waterBulletImpact(crossing.point,p.gun.id==='marksman'?2:1);impactBudget--;}
 if(hit||groundHit){const point=hit?.point||p.mesh.position.clone();
  if(hit){classicDamage(hit.object,(p.gun.id==='marksman'?20:p.gun.id==='bfg'?100:5)*(1+Math.floor(Math.random()*8)));if(impactBudget>0&&p.gun.id!=='bfg')Mb(point,p.dir.clone().negate(),hit.object)}
  if(p.gun.id==='marksman'){
   deathEffects.blast(point,{style:'fire',size:1.1,grow:1.8,duration:.55,alpha:.95});
   deathEffects.puff(point,{count:12,size:.5,grow:2.1,life:1.35,rise:.62,alpha:.7,color:0xbdb6a8});
   It('explosion',{position:point,volume:.62,range:64,key:'rocket-blast',cooldown:40});
   for(let k=0;k<(impactBudget>0?12:5);k++)Wo(point.clone(),new w((Math.random()-.5)*5,Math.random()*4,(Math.random()-.5)*5),'spark');
   projectileSplash(point,p,4,128);
  }else if(p.gun.id==='bfg'){
   deathEffects.blast(point,{style:'green',size:1.5,grow:1.6,duration:.7,alpha:.8});
   deathEffects.puff(point,{count:13,size:.55,grow:2.2,life:1.45,rise:.7,alpha:.68,color:0xc9e8b4});
   It('bfgBlast',{position:point,volume:.8,range:82,key:'bfg-blast',cooldown:60});
   // A_BFGSpray: 40 tracers across ANG90 centred on the aim at detonation, 15-120 damage each.
   const fanOrigin=oe.position.clone(),fanYaw=p.yaw;
   for(let k=0;k<40;k++)combatShotJobs.push(()=>{const angle=fanYaw+(k/39-.5)*Math.PI/2,d=new w(-Math.sin(angle),0,-Math.cos(angle)),h=classicRay(fanOrigin,d,30);const water=waterAttackCrossing(fanOrigin,d,h?.distance??30);if(water)waterBulletImpact(water.point,1);if(h){deathEffects.blast(h.point,{style:'green',size:.42,grow:1.1,duration:.32,alpha:.85});classicDamage(h.object,Array.from({length:15},()=>1+Math.floor(Math.random()*8)).reduce((a,b)=>a+b,0))}});
  }else{
   deathEffects.blast(point,{style:'plasma',size:.7,grow:.5,duration:.32,alpha:.92});
   It('plasmaHit',{position:point,volume:.24,range:40,key:'plasma-hit',cooldown:45});
   for(let k=0;k<(impactBudget>0?5:2);k++)Wo(point.clone(),new w((Math.random()-.5)*3,Math.random()*2.6,(Math.random()-.5)*3),'spark');
  }
  if(!hit&&impactBudget>0)playMaterialImpact(Vd,point);impactBudget--;
  disposeClassicProjectile(p);continue;
 }
 p.mesh.position.addScaledVector(p.dir,distance);
 if(p.visual?.kind==='rocket'){p.trail-=dt;if(p.trail<=0){p.trail=.09;deathEffects.puff(p.mesh.position,{count:1,size:.08,grow:2.6,life:.32,rise:.16,alpha:.4,color:0xd9d4c8})}}
 else if(p.visual?.kind==='burst'){const frames=[particleAssets.plasma_01,particleAssets.plasma_02,particleAssets.plasma_03,particleAssets.plasma_04],material=projectileSpriteMaterial('burst');material.map=frames[(p.age*24|0)%frames.length];p.mesh.scale.setScalar(.58+Math.sin(p.age*40)*.05)}
 if(p.age>p.charge+90/p.speed)disposeClassicProjectile(p);
}classicProjectileCursor=start+checked;if(combatShotJobs.length)scheduleCombatShotQueue();}

// Shared physical ownership for crew: reaction/recovery -> hull collision -> support.
var crewMotionStart=new Map();
function beginCrewMotion(){crewMotionStart.clear();for(const a of [Wt,gr,Ut,...mr,...Za,...riverCrew(),ei,...(hiredMechanic?[hiredMechanic]:[]),...Yi,...J0]){if(!a)continue;if(a.userData.defeated||a.userData.overboard||a.userData.sinking){a.userData.postRecovery=null;a.userData.crewFallVelocity=0;continue}if(a.visible&&a.parent?.visible&&[ge,it,ze].includes(a.parent)&&(a.parent===ge?Qt:a.parent===it?On:U.gillTycoonHired)){if(!crewTaskAvailable(a))a.userData.taskRoute=null;crewMotionStart.set(a,a.position.clone())}}}
function crewHullMove(boat,from,to,ladderPass=false){const p=from.clone(),radius=.13,head=Math.min(from.y,to.y)+1.2,foot=Math.min(from.y,to.y),panels=[];
 for(const block of boat.userData.fleetBlocks||[])if(head>block.y0+.01&&foot<block.y1-.03)panels.push(block.rect);
 if(head>.43&&foot<1.88)panels.push([-.995,-.905,-1.49,.38],[.905,.995,-1.49,.38],[-.995,.995,.285,.385],[-.995,-.42,-1.575,-1.435],[.36,.995,-1.575,-1.435]);
 if(!ladderPass&&head>.55&&foot<1.08)panels.push([-1.415,-1.345,-2.3,2.16],[1.345,1.415,-2.3,2.16],[-1.38,1.38,2.085,2.155]);
 const door=ng(boat),angle=door?.userData.angle||0,c=Math.cos(angle),sn=Math.sin(angle),toDoor=p=>({x:(p.x+.42)*c-(p.z+1.535)*sn,z:(p.x+.42)*sn+(p.z+1.535)*c});
 const n=Math.max(1,Math.ceil(Math.hypot(to.x-from.x,to.z-from.z)/.035)),dx=(to.x-from.x)/n,dz=(to.z-from.z)/n;
 for(let i=0;i<n;i++){const old={x:p.x,z:p.z};p.x+=dx;p.z+=dz;for(let pass=0;pass<2;pass++){for(const rect of panels)cabinPanelPush(p,old,rect,radius);if(door&&equipmentIntact(boat,'door')&&head>.43&&foot<1.64){const q=toDoor(p),prev=toDoor(old);cabinPanelPush(q,prev,[0,.78,-.0375,.0375],radius);p.x=-.42+q.x*c+q.z*sn;p.z=-1.535-q.x*sn+q.z*c}}}p.y=to.y;return p;
}
function crewSupport(boat,p){let height=fleetDeckContains(boat.userData.deckOutline,p.x,p.z,0)?.38:null;const low=boat.userData.fleetModel?.userData.roofLevels?.[0]??2.10;
 if(Math.abs(p.x)<=1.065&&p.z>=-1.58&&p.z<=.42&&p.y>=low-.06)height=low;
 for(const b of boat.userData.fleetBlocks||[])if(p.x>=b.rect[0]&&p.x<=b.rect[1]&&p.z>=b.rect[2]&&p.z<=b.rect[3]&&p.y>=b.y1-.06)height=Math.max(height??-Infinity,b.y1);return height;
}
function finishCrewMotion(dt){for(const [a,start]of crewMotionStart){const u=a.userData,boat=a.parent;if(![ge,it,ze].includes(boat)||u.overboard||u.defeated||u.sinking||u.vaulting)continue;
 if(u.resting||u.sleeping||u.alertStand||u.alertTransit||u.sleepAlert||u.spawning)u.postRecovery=null;
 if(u.sleeping||u.resting&&u.restStage==='asleep'||u.restStage==='lying'||u.alertStand)continue;
 if(u.postRecovery&&!(u.hitStunUntil>performance.now())){a.position.copy(start);const r=u.postRecovery;if(!r.path){r.home=crewNavigationPost(bm,r.home);r.path=planBoatCrewRoute(bm,boat,start,r.home)}if(stepBoatCrewRoute(a,boat,r.path,dt)){u.postRecovery=null;u.mounted=false}}

 if(u.crewFallVelocity){a.position.x=start.x;a.position.z=start.z;a.position.y=start.y}
 const routeActive=u.deckTransit?.length||boardingDefense?.jobs.get(a)?.path?.length||extinguisherJobs?.get(a)?.path?.length||u.cabinRoute?.length||u.alertTransit?.length||u.restWaypoints?.length||u.burnEscapePath?.length||u.burnWalkRoute?.path?.length||u.postRecovery?.path?.length||u.usesMount||u.taskRoute?.path?.length||navalCombat?.boarding.get(a)?.path?.length||u.equipmentJob?.path?.length,atLadder=routeActive&&Math.abs(a.position.z+.95)<.19&&Math.abs(a.position.x)>=.65&&Math.abs(a.position.x)<=1.50;
 const intended=a.position.clone();a.position.copy(crewHullMove(boat,start,a.position,!!atLadder&&!(u.hitStunUntil>performance.now())));
 if(routeActive&&a.position.distanceToSquared(intended)>.000004&&Mt>=(u.routeReplanAt||0)&&!(u.hitStunUntil>performance.now())){u.routeReplanAt=Mt+.5;refreshCrewRoute(a,boat)}
 if(atLadder&&!u.crewFallVelocity){finishCrewGait(a,start,dt);continue;}
 const support=crewSupport(boat,a.position);if(support===null){u.postRecovery=null;u.crewFallVelocity=0;mountedWeaponSystem?.release(a);overboardSystem?.fall(a,boat);meleeReactions.delete(a);continue}
 if(a.position.y>support+.045){u.crewFallVelocity=(u.crewFallVelocity||0)+dt*9.8/Math.max(.5,boat.scale.y);a.position.y=Math.max(support,a.position.y-u.crewFallVelocity*dt)}else if(!u.resting&&!u.sleeping){a.position.y=support;u.crewFallVelocity=0}
 finishCrewGait(a,start,dt);
}}

// Complete every pellet, but never execute a whole shotgun fan in one input/frame task.
var combatShotJobs=[];
function updateCombatShotQueue(){const until=performance.now()+2;let count=0;while(combatShotJobs.length&&count++<6){combatShotJobs.shift()();if(count>=4&&performance.now()>=until)break}}
var combatShotPumpPending=false;
function scheduleCombatShotQueue(){if(combatShotPumpPending)return;combatShotPumpPending=true;setTimeout(function pump(){if(!combatShotJobs.length){combatShotPumpPending=false;return}if(xi&&!xr&&!document.hidden)updateCombatShotQueue();setTimeout(pump,xr||document.hidden?60:4)},0)}

// Controllers choose poses; only measured, collision-resolved displacement drives gait.
function finishCrewGait(actor,start,dt){
 const u=actor.userData;if(u.sleeping||['asleep','lying'].includes(u.restStage)||u.alertStand||u.defeated||u.overboard||u.mounted||u.hitStunUntil>performance.now()||meleeReactions.has(actor))return;
 const distance=actor.position.distanceTo(start);if(u.taskRoute?.attempted){u.taskRoute.blocked=distance<dt*.04?(u.taskRoute.blocked||0)+dt:0;u.taskRoute.attempted=false}const walking=distance>Math.max(.0006,dt*.025),climbing=Math.abs(actor.position.y-start.y)>Math.max(.001,dt*.08);u.actualCrewSpeed=distance/Math.max(dt,.001);u.crewGaitPhase=(u.crewGaitPhase||0)+distance*9;
 if(!walking&&u.repairing&&!u.taskRoute)return;const rig=sinkingCrewRig(actor);for(const [i,leg]of rig.legs.entries())leg.rotation.x=walking?Math.sin(u.crewGaitPhase+i*Math.PI)*.45:0;
 if(actor===Wt)for(const limb of Qe.legs){limb.pivot.rotation.x=walking?Math.sin(u.crewGaitPhase)*limb.side*.45:0;limb.elbow.rotation.x=0}
 if(walking&&!u.firefighting&&!u.repairing)for(const [i,arm]of rig.arms.entries())arm.rotation.x=climbing?-2.2+Math.sin(u.crewGaitPhase+i*Math.PI)*.3:-Math.sin(u.crewGaitPhase+i*Math.PI)*.3;
}

function refreshCrewRoute(actor,boat){
 const u=actor.userData,mount=mountedWeaponSystem?.assignments.get(actor),boarding=navalCombat?.boarding.get(actor),defense=boardingDefense?.jobs.get(actor),fire=extinguisherJobs?.get(actor);
 const path=[u.postRecovery?.path,u.cabinRoute,u.alertTransit,u.restWaypoints,u.deckTransit,u.burnEscapePath,u.burnWalkRoute?.path,u.equipmentJob?.path,mount?.path,boarding?.path,boarding?.escape,defense?.path,fire?.path,u.taskRoute?.path].find(p=>p?.length);
 if(!path?.length)return;const goal=path.at(-1).clone();path.splice(0,path.length,...planBoatCrewRoute(bm,boat,actor.position,goal));if(path===u.cabinRoute)u.spawnStep=0;if(path===mount?.path)mount.index=0;
}
