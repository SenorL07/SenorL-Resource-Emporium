// Crew-owned mounted weapons. No mount fires without a living operator at its seat.
export function createBoatWeaponSystem(T,{ready,time,route,rig,lineOfSight,tryShot,fire,stepSound,planRoute,door=()=>true,available=()=>true,canOperate=()=>true,normalizePost=p=>p,autoTarget=()=>null,autoSfx=null,canAutoFire=()=>true}){
 const boats=new WeakMap(),assignments=new Map();
 const angle=v=>Math.atan2(Math.sin(v),Math.cos(v));
 function release(actor){const s=assignments.get(actor);if(!s)return;if(s.mount.operator===actor)s.mount.operator=null;s.mount.burstLeft=0;for(const [n,v]of s.hidden)n.visible=n===actor.userData.flash||actor.userData.equipmentUnarmed?false:v;actor.userData.usesMount=false;actor.userData.mounted=false;actor.userData.mountId=null;assignments.delete(actor)}
 function resetBoat(boat){for(const [a,s]of assignments)if(s.boat===boat)release(a)}
 function register(boat){const model=boat.userData.fleetModel;if(boats.get(boat)?.model===model)return;resetBoat(boat);const mounts=[];for(const spec of model?.userData.mountSpecs||[]){const yaw=model.getObjectByName(spec.id+'-yaw'),pitch=model.getObjectByName(spec.id+'-pitch');if(!yaw||!pitch)continue;yaw.rotation.set(0,spec.baseYaw,0);pitch.rotation.set(0,0,0);mounts.push({...spec,yaw,pitch,muzzles:Array.from({length:spec.barrels},(_,i)=>model.getObjectByName(spec.id+'-muzzle-'+i)),flash:model.getObjectByName(spec.id+'-flash'),seat:normalizePost(new T.Vector3(...spec.seat)),operator:null,cooldown:0,lastShot:-100,recoil:0,burstLeft:0})}boats.set(boat,{model,mounts})}
 function aimSolution(boat,m,target){if(!target)return null;const p=boat.worldToLocal(target.position.clone()),dx=p.x-m.x,dz=p.z-m.z,dy=p.y-m.y-.30,yaw=angle(Math.atan2(dx,dz)-m.baseYaw),pitch=Math.atan2(dy,Math.hypot(dx,dz));return {yaw,pitch,inArc:Math.abs(yaw)<=m.yawLimit&&pitch>=m.pitchMin&&pitch<=m.pitchMax}}
 function assign(boat,actor,m){release(actor);const hidden=[];actor.traverse(n=>{if(n.name==='crew-rifle'||n.name==='crew-rifle-barrel'||n===actor.userData.gun||n===actor.userData.flash){hidden.push([n,n.visible]);n.visible=false}});const side=actor.position.x<0?-1:1;
  const path=planRoute?planRoute(boat,actor.position,m.seat):[m.seat.clone()];
  assignments.set(actor,{boat,mount:m,path,index:0,hidden,walkPhase:0,stepAt:0,assignedAt:time()});m.operator=actor;actor.userData.usesMount=true;actor.userData.mountId=m.id;
 }
 function update(dt,ships){
  const wanted=new Set();for(const ship of ships){register(ship.boat);const data=boats.get(ship.boat);for(const m of data.mounts){m.cooldown=Math.max(0,m.cooldown-dt);m.recoil=Math.max(0,m.recoil-dt*.7);m.pitch.position.z=-m.recoil;if(m.flash)m.flash.visible=available(ship.boat,m)&&time()-m.lastShot<.08}
   if(!ship.on||!ship.boat.visible)continue;
   for(const actor of ship.crew){if((actor.userData.hitStunUntil>performance.now()||actor.userData.postRecovery)&&actor.parent===ship.boat){if(assignments.has(actor))wanted.add(actor);continue}if(!ready(actor)||actor.parent!==ship.boat||actor.userData.firefighting)continue;const target=ship.target(actor);let s=assignments.get(actor);if(!canOperate(actor)){release(actor);continue}if(s&&!available(ship.boat,s.mount)){release(actor);s=null}
    // Keep a crew member at a useful station; don't teleport between guns as a target circles.
    if(s&&s.boat!==ship.boat){release(actor);s=null}
    if(s&&target&&time()-s.assignedAt>3&&!aimSolution(ship.boat,s.mount,target)?.inArc){const better=data.mounts.find(m=>!m.operator&&!m.auto&&available(ship.boat,m)&&aimSolution(ship.boat,m,target)?.inArc);if(better){assign(ship.boat,actor,better);s=assignments.get(actor)}}
    if(!s){const free=data.mounts.filter(m=>!m.operator&&!m.auto&&available(ship.boat,m));free.sort((a,b)=>(target?(aimSolution(ship.boat,a,target)?.inArc?0:100):0)+actor.position.distanceTo(a.seat)-(target?(aimSolution(ship.boat,b,target)?.inArc?0:100):0)-actor.position.distanceTo(b.seat));if(!free.length)continue;assign(ship.boat,actor,free[0]);s=assignments.get(actor)}
    wanted.add(actor);const m=s.mount;if(s.index>=s.path.length&&actor.position.distanceTo(m.seat)>.06){s.path=planRoute?planRoute(ship.boat,actor.position,m.seat):[m.seat.clone()];s.index=0;actor.userData.mounted=false}
    if(s.index<s.path.length){const goal=s.path[s.index],vertical=Math.abs(goal.y-actor.position.y)>.04;if(!door(ship.boat,actor,goal)){actor.userData.mounted=false;continue}const next=goal;const delta=next.clone().sub(actor.position),distance=delta.length(),speed=vertical?.70:1.05;if(distance<.035){actor.position.copy(goal);s.index++}else{actor.position.addScaledVector(delta,Math.min(distance,dt*speed)/distance);actor.rotation.y=Math.atan2(delta.x,delta.z);s.walkPhase+=dt*(vertical?6:9);const r=rig(actor);r.legs.forEach((l,i)=>l.rotation.x=Math.sin(s.walkPhase+i*Math.PI)*.48);r.arms.forEach((a,i)=>a.rotation.x=vertical?-2.3+Math.sin(s.walkPhase+i*Math.PI)*.5:-Math.sin(s.walkPhase+i*Math.PI)*.35);if(time()>s.stepAt){s.stepAt=time()+.42;stepSound?.(actor)}}actor.userData.mounted=false;continue}
    actor.userData.mounted=true;actor.position.copy(m.seat);const solution=aimSolution(ship.boat,m,target),wantedYaw=solution?Math.max(-m.yawLimit,Math.min(m.yawLimit,solution.yaw)):(m.roof?angle(time()*.16+actor.id):Math.sin(time()*.23+actor.id)*m.yawLimit*.55),wantedPitch=solution?Math.max(m.pitchMin,Math.min(m.pitchMax,solution.pitch)):0;
    let relative=angle(m.yaw.rotation.y-m.baseYaw);relative+=Math.max(-dt*1.5,Math.min(dt*1.5,angle(wantedYaw-relative)));if(m.yawLimit>=Math.PI)relative=angle(relative);m.yaw.rotation.set(0,m.baseYaw+Math.max(-m.yawLimit,Math.min(m.yawLimit,relative)),0);m.pitch.rotation.set(m.pitch.rotation.x+Math.max(-dt*.85,Math.min(dt*.85,-wantedPitch-m.pitch.rotation.x)),0,0);
    actor.rotation.set(0,m.yaw.rotation.y,0);const r=rig(actor);r.arms.forEach((a,i)=>a.rotation.set(actor.userData.reloading?-.60+Math.sin(time()*8+i)*.25:-1.1,0,i?.10:-.10));r.legs.forEach((l,i)=>l.rotation.set(i?.09:-.09,0,0));
    if(!target||!solution?.inArc||!ship.combat||m.cooldown>0||Math.abs(angle(relative-solution.yaw))>.045||Math.abs(-m.pitch.rotation.x-solution.pitch)>.05)continue;
    ship.boat.updateWorldMatrix(true,true);const muzzle=m.muzzles[0].getWorldPosition(new T.Vector3());if(muzzle.distanceTo(target.position)>72||!lineOfSight(muzzle,target.position,actor,target.actor))continue;
    if(!tryShot(actor,m)){m.cooldown=.12;continue}if(m.burstLeft<=0)m.burstLeft=m.heavy?2:3;m.burstLeft--;m.cooldown=m.burstLeft>0?(m.heavy?.24:.14):(m.heavy?1.65:1.05);m.lastShot=time();m.recoil=m.heavy?.10:.04;fire({boat:ship.boat,actor,mount:m,target,origins:m.muzzles.map(n=>n.getWorldPosition(new T.Vector3()))});
   }
  }for(const actor of [...assignments.keys()])if(!wanted.has(actor))release(actor);
  // Automated mounts need no operator: they track hostiles on their own and, with
  // nothing to shoot, sweep slowly across the arc they are allowed to cover.
  for(const ship of ships){
   if(!ship.on||!ship.boat.visible)continue;
   const data=boats.get(ship.boat);if(!data)continue;
   for(const m of data.mounts){
    if(!m.auto)continue;
    m.cooldown=Math.max(0,m.cooldown-dt);m.recoil=Math.max(0,m.recoil-dt*.7);m.pitch.position.z=-m.recoil;
    if(m.flash)m.flash.visible=available(ship.boat,m)&&time()-m.lastShot<.08;
    const usable=available(ship.boat,m)&&canAutoFire(ship.boat,m);
    const target=usable?autoTarget(ship.boat,m):null;
    const solution=target?aimSolution(ship.boat,m,target):null,tracking=!!(solution&&solution.inArc);
    let wantedYaw,wantedPitch;
    if(tracking){wantedYaw=Math.max(-m.yawLimit,Math.min(m.yawLimit,solution.yaw));wantedPitch=Math.max(m.pitchMin,Math.min(m.pitchMax,solution.pitch))}
    else{m.idlePhase=(m.idlePhase||0)+dt*.30;wantedYaw=Math.sin(m.idlePhase)*m.yawLimit*(m.roof?.55:.85);wantedPitch=-.05}
    let relative=angle(m.yaw.rotation.y-m.baseYaw);
    relative+=Math.max(-dt*1.9,Math.min(dt*1.9,angle(wantedYaw-relative)));
    if(m.yawLimit>=Math.PI)relative=angle(relative);
    relative=Math.max(-m.yawLimit,Math.min(m.yawLimit,relative));
    m.yaw.rotation.set(0,m.baseYaw+relative,0);
    m.pitch.rotation.set(m.pitch.rotation.x+Math.max(-dt*1.1,Math.min(dt*1.1,-wantedPitch-m.pitch.rotation.x)),0,0);
    if(!tracking||m.cooldown>0||Math.abs(angle(relative-solution.yaw))>.05||Math.abs(-m.pitch.rotation.x-solution.pitch)>.06)continue;
    ship.boat.updateWorldMatrix(true,true);
    const muzzle=m.muzzles[0].getWorldPosition(new T.Vector3());
    if(muzzle.distanceTo(target.position)>46||!lineOfSight(muzzle,target.position,ship.boat,target.actor))continue;
    if(m.burstLeft<=0)m.burstLeft=m.heavy?2:3;m.burstLeft--;
    m.cooldown=m.burstLeft>0?(m.heavy?.26:.15):(m.heavy?1.7:1.1);m.lastShot=time();m.recoil=m.heavy?.10:.04;
    autoSfx&&autoSfx(ship.boat,m,muzzle);
    fire({boat:ship.boat,actor:ship.boat,mount:m,target,origins:m.muzzles.map(n=>n.getWorldPosition(new T.Vector3())),auto:true});
   }
  }
 }
 return {register,update,release,resetActor:release,resetBoat,getMounts:boat=>boats.get(boat)?.mounts||[],assignments,aimSolution};
}
