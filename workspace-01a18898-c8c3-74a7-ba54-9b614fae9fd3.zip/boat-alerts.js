// Shared, independently testable sleep alarm state machine for both fleets.
export function createBoatSleepAlarmSystem({time,roster,awake,ready,wake,wakeStep,canReport,combatant,threat,escape,engage,maintain,announce,returnToSleep,valid=()=>true,random=Math.random}){
 const states=new Map();
 function living(a){const u=a.userData;return a.visible&&!u.defeated&&!u.overboard&&!u.sinking}
 function awaken(boat,state,actor){if(!living(actor)||state.witnesses.has(actor))return;state.witnesses.set(actor,{report:0});wake(boat,actor)}
 function hit(boat,actor=null){
  if(!valid(boat))return false;const crew=roster(boat).filter(living);let state=states.get(boat);if(state)state.lastHit=time();
  if(actor){if(!crew.includes(actor)||!actor.userData.sleeping&&!actor.userData.resting&&!state)return false}
  else{if(!crew.some(a=>a.userData.sleeping)||crew.some(a=>awake(a)))return false;const now=time();if(now<(boat.userData.nextSleepNoise||0))return false;boat.userData.nextSleepNoise=now+1;if(random()>=.22)return false;const sleepers=crew.filter(a=>a.userData.sleeping);actor=sleepers[Math.floor(random()*sleepers.length)]}
  if(!state){state={phase:'witness',witnesses:new Map(),lastHit:time(),safeSince:null};states.set(boat,state)}state.safeSince=null;awaken(boat,state,actor);return true;
 }
 function update(boat,dt){const state=states.get(boat);if(!state)return false;if(!valid(boat)){reset(boat);return false}const crew=roster(boat).filter(living);
  for(const [actor,record]of [...state.witnesses]){if(!crew.includes(actor)){state.witnesses.delete(actor);continue}if(state.phase==='alarm'&&actor.userData.spawning)wake(boat,actor);wakeStep(boat,actor,dt,state.phase);if(state.phase==='witness'){if(ready(actor)&&canReport(boat,actor,crew))record.report+=dt;else record.report=0;if(record.report>=(combatant(actor)?2.4:1.4)){state.phase='alarm';announce(boat,actor);for(const other of crew)awaken(boat,state,other)}}}
  if(state.phase==='alarm')for(const actor of crew)if(!state.witnesses.has(actor)||!actor.userData.sleepAlert){state.witnesses.delete(actor);awaken(boat,state,actor)};
  const danger=threat(boat,state);if(!danger.aboard&&!danger.seen&&!danger.unsafe&&danger.distance>48&&time()-state.lastHit>12){state.safeSince??=time();if(time()-state.safeSince>=6){states.delete(boat);returnToSleep(boat);return false}}else state.safeSince=null;
  const active=[...state.witnesses.keys()].filter(ready);for(const actor of active)if(combatant(actor))engage(boat,actor,state.phase);else if(state.phase==='alarm')maintain(boat,actor,dt);
  if(state.phase==='alarm')escape(boat,dt,danger);return true;
 }
 function reset(boat){states.delete(boat);boat.userData.nextSleepNoise=0;for(const a of roster(boat)){a.userData.sleepAlert=false;a.userData.alertStand=null;a.userData.alertTransit=null;a.userData.alertDeparted=false}}
 return {states,hit,update,reset};
}

// Game adapters. Ordinary post recovery must never own an actor during rest/alarm.
function boatAlertActive(boat){return !!sleepAlarms?.states.has(boat)}
function boatAlertMobilized(boat){return sleepAlarms?.states.get(boat)?.phase==='alarm'}
function boatAlertTarget(boat,actor){if(boat===ze&&U.gillTycoonHired)return null;return actor.userData.sleepAlert&&!actor.userData.alertStand&&!actor.userData.alertTransit&&boatAlertActive(boat)?weaponTargetPlayer():null}
function notifyPlayerBoatHit(object){
 // Breakable hired equipment is not an attack on the crew; never raise an alarm.
 if(U.gillTycoonHired&&(object===ze||i0(object,ze)))return;
 if(playerFriendlyObject(object))return;for(const boat of [ge,it,ze]){if(!boat.visible)continue;const actor=restRoster(boat).find(a=>a===object||a.getObjectById(object.id));if(actor){engageBoatHud(boat);sleepAlarms?.hit(boat,actor);return}if(object===boat||boat.getObjectById(object.id)){engageBoatHud(boat);sleepAlarms?.hit(boat);return}}}
function crewDoorPassage(actor,boat,goal){
 if(!equipmentIntact(boat,'door'))return true;if(actor.position.y>1.3&&goal.y>1.3)return true;
 const from=actor.position;if(from.z< -1.71&&goal.z<=-2.44&&goal.z<from.z&&Math.abs(from.x)<.6)return true;const near=Math.abs(from.x)<.72&&from.z> -2.6&&from.z<-.55&&(goal.z< -1.43||from.z< -1.43),cross=Math.min(from.z,goal.z)<-1.43&&Math.max(from.z,goal.z)>-1.58&&Math.min(Math.abs(from.x),Math.abs(goal.x))<.65;
 if(!near&&!cross){if(boat.userData.passageOwner===actor)boat.userData.passageOwner=null;return true}
 let owner=boat.userData.passageOwner;if(owner&&(Mt>(boat.userData.passageUntil||0)||owner.userData.sleeping||owner.userData.restStage==='lying'||owner.parent!==boat||owner.userData.defeated||owner.userData.overboard||Math.abs(owner.position.x)>.75||owner.position.z< -2.43||owner.position.z>-.55))boat.userData.passageOwner=owner=null;
 if(owner&&owner!==actor)return false;boat.userData.passageOwner=actor;boat.userData.passageUntil=Mt+.65;$D(boat,1.2);return (ng(boat)?.userData.angle||0)>1.23;
}
function stepBoatCrewRoute(actor,boat,path,dt,speed=1.15){
 while(path.length&&actor.position.distanceTo(path[0])<.03)actor.position.copy(path.shift());if(!path.length){if(boat.userData.passageOwner===actor)boat.userData.passageOwner=null;return true}
 const goal=path[0];if(!crewDoorPassage(actor,boat,goal))return false;const delta=goal.clone().sub(actor.position),d=delta.length();if(d){const climb=Math.abs(delta.y)>.05;actor.position.addScaledVector(delta,Math.min(d,dt*(climb?.75:speed))/d);actor.rotation.set(0,Math.atan2(delta.x,delta.z),0);const rig=sinkingCrewRig(actor);rig.legs.forEach((l,i)=>l.rotation.x=Math.sin(Mt*10+i*Math.PI)*.45);rig.arms.forEach((arm,i)=>arm.rotation.x=climb?-2.2+Math.sin(Mt*8+i*Math.PI)*.35:0)}return false;
}
function wakeBoatCrew(boat,actor){
 const u=actor.userData;u.sleepAlert=true;u.alertDeparted=false;u.postRecovery=null;u.deckTransit=null;u.target=null;u.patrolTarget=null;u.restWaypoints=null;u.cabinRoute=null;u.spawning=false;u.spawnBoat=null;u.sleeping=false;u.resting=true;u.restStage='alert-standing';u.alertTransit=null;u.alertStand={from:actor.position.clone(),roll:actor.rotation.z,t:0};mountedWeaponSystem?.release(actor);boardingDefense?.reset(actor);if(u.flash)u.flash.visible=false;
}
function stepAlertCrew(boat,actor,dt,phase){const u=actor.userData;if(u.hitStunUntil>performance.now()||u.burning)return;
 if(u.alertStand){const stand=u.alertStand;stand.t=Math.min(.6,stand.t+dt);const t=stand.t/.6,index=u.bunkIndex||0,x=[-.48,.10,.48][index%3]/(boat.userData.hullFactor||1),target=new w(x,.38,he.clamp(stand.from.z,-1.12,.08));actor.position.copy(stand.from).lerp(target,t);actor.rotation.set(0,0,stand.roll*(1-t));if(t<1)return;u.alertStand=null;u.resting=false;u.restStage=null}
 if(phase==='alarm'&&!u.alertDeparted){u.alertDeparted=true;const armed=actor===St||actor===Ut||mr.includes(actor)||J0.includes(actor)||['gunner','guard'].includes(u.crewRole),mechanic=actor===gr||u.crewRole==='mechanic',fire=mechanic&&[...burnSystem.states.values()].some(s=>s.entry.actor===boat||s.entry.actor.parent===boat);const driver=actor===Wt||actor===Fs||actor===ei;u.alertTransit=fire||!armed&&!mechanic&&!driver?null:planBoatCrewRoute(bm,boat,actor.position,armed?new w((actor.position.x<0?-1:1)*1.18,.38,-2.48):restPost(boat,actor))}
 if(u.alertTransit&&stepBoatCrewRoute(actor,boat,u.alertTransit,dt)){u.alertTransit=null;u.baseY=actor.position.y}
}
function playerAboardForAlarm(boat){if(Zt&&fn===boat)return true;boat.updateWorldMatrix(true,false);const p=boat.worldToLocal(oe.position.clone().add(new w(0,-1.66,0))),top=boat.userData.fleetModel?.userData.roofLevels?.at(-1)||2.1;return p.y>-.2&&p.y<top+1&&fleetDeckContains(boat.userData.deckOutline,p.x,p.z,0)}
function alarmDanger(boat,state){const distance=oe.position.distanceTo(boat.position),aboard=playerAboardForAlarm(boat);if(Mt>=(state.sightAt||0)){state.sightAt=Mt+.3;state.seen=distance<60&&[...state.witnesses.keys()].some(a=>crewReady(a)&&Jc(a.localToWorld(new w(0,1.05,0)),oe.position,a,oe))}return {distance,aboard,seen:!!state.seen,unsafe:boardingAlarm(boat)||[...burnSystem.states.values()].some(s=>s.entry.actor===boat||s.entry.actor.parent===boat)}}
function escapeSleepThreat(boat,dt,danger){const driver=boat===ge?Wt:boat===it?Fs:ei;if(danger.aboard||danger.distance>=38||!crewReady(driver)||driver.userData.resting||!nS(boat,driver)){Xi(boat);return}
 const away=boat.position.clone().sub(oe.position);away.y=0;if(away.lengthSq()<.01)away.set(1,0,0);away.normalize();const candidates=[away,new w(away.z,0,-away.x),new w(-away.z,0,away.x)];
 for(const dir of candidates){const old=boat.rotation.y,yaw=Math.atan2(dir.x,dir.z),turn=Math.atan2(Math.sin(yaw-old),Math.cos(yaw-old));boat.rotation.y+=he.clamp(turn,-dt*.7,dt*.7);if(!q3(boat)||!boatPairClear(boat)){boat.rotation.y=old;continue}const before=boat.position.clone();dr(boat,dir.x*dt*4.5,dir.z*dt*4.5);if(boat.position.distanceToSquared(before)>.000001)return;boat.rotation.y=old}Xi(boat);
}
function alertMaintenance(boat,actor,dt){if(actor.userData.firefighting||actor.userData.burning||actor.userData.equipmentJob)return;const mechanic=actor===gr||actor.userData.crewRole==='mechanic';if(!mechanic){if(actor!==Wt&&actor!==Fs&&actor!==ei)boardingDefense.civilian(actor,boat,true,dt,Math.max(0,restRoster(boat).indexOf(actor)));return;}if(boat===ge)us=Math.min(Yr,us+dt*1.2);else if(boat===it)fr=Math.min(c_,fr+dt*1.2);else Xa=Math.min(Dc,Xa+dt*1.2)}
function finishSleepAlert(boat){for(const a of restRoster(boat)){const u=a.userData;u.sleepAlert=false;u.alertStand=null;u.alertTransit=null;u.alertDeparted=false;u.postRecovery=null;boardingDefense?.reset(a);mountedWeaponSystem?.release(a)}if(boat===ge){jr=false;ge.userData.playerCombatUntil=0}else if(boat===it)Gc=false;
 if(worldIsEvening()){resetBoatRest(boat);boat.userData.nightTrip=true;beginCrewRest(boat)}else if(boat.userData.restState)updateCrewRest(boat,0,true);
}
// AI sight/fire uses the same closed panels and hinged leaf as crew collision.
// Decorative/merged fleet meshes must not accidentally turn a solid cabin transparent.
function boatCabinLineBlocked(boat,from,to){
 const margin=5*Math.max(.5,boat.scale.x);if(Math.min(from.x,to.x)>boat.position.x+margin||Math.max(from.x,to.x)<boat.position.x-margin||Math.min(from.z,to.z)>boat.position.z+margin||Math.max(from.z,to.z)<boat.position.z-margin)return false;
 boat.updateWorldMatrix(true,false);const a=boat.worldToLocal(from.clone()),b=boat.worldToLocal(to.clone());
 const hit=(p,q,x0,x1,y0,y1,z0,z1)=>{let lo=.005,hi=.995;for(const [v,d,min,max]of[[p.x,q.x-p.x,x0,x1],[p.y,q.y-p.y,y0,y1],[p.z,q.z-p.z,z0,z1]]){if(Math.abs(d)<1e-9){if(v<min||v>max)return false;continue}let t0=(min-v)/d,t1=(max-v)/d;if(t0>t1)[t0,t1]=[t1,t0];lo=Math.max(lo,t0);hi=Math.min(hi,t1);if(lo>hi)return false}return true};
 const walls=[[-.995,-.905,-1.49,.38],[.905,.995,-1.49,.38],[-.995,.995,.285,.385],[-.995,-.42,-1.575,-1.435],[.36,.995,-1.575,-1.435]];
 for(const [i,r]of walls.entries()){
  const broken=i<3&&!equipmentIntact(boat,['window-port','window-starboard','window-front'][i]);
  if(!broken){if(hit(a,b,r[0],r[1],.38,1.88,r[2],r[3]))return true;continue}
  const bottom=i===2?.965:.935,top=i===2?1.595:1.585;
  if(hit(a,b,r[0],r[1],.38,bottom,r[2],r[3])||hit(a,b,r[0],r[1],top,1.88,r[2],r[3]))return true;
  if(i===2){if(hit(a,b,-.995,-.74,bottom,top,r[2],r[3])||hit(a,b,.74,.995,bottom,top,r[2],r[3]))return true}
  else if(hit(a,b,r[0],r[1],bottom,top,-1.49,-.99)||hit(a,b,r[0],r[1],bottom,top,-.05,.38))return true;
 }

 if(hit(a,b,-1.08,1.08,1.88,2.02,-1.58,.42))return true;
 for(const block of boat.userData.fleetBlocks||[])if(hit(a,b,block.rect[0],block.rect[1],block.y0,block.y1,block.rect[2],block.rect[3]))return true;
 const door=ng(boat);if(door&&equipmentIntact(boat,'door')){const angle=door.userData.angle||0,c=Math.cos(angle),s=Math.sin(angle),local=p=>({x:(p.x+.42)*c-(p.z+1.535)*s,y:p.y,z:(p.x+.42)*s+(p.z+1.535)*c});if(hit(local(a),local(b),0,.78,.43,1.61,-.0375,.0375))return true}return false;
}

// Ordinary work is lower priority than every explicit transit/combat/rest owner.
function crewTaskAvailable(actor){const u=actor.userData;return crewReady(actor)&&!u.resting&&!u.sleeping&&!u.sleepAlert&&!u.closeDefense&&!u.takingCover&&!u.firefighting&&!u.usesMount&&!u.equipmentJob&&!u.postRecovery&&!u.deckTransit&&!u.boarding&&!(u.hitStunUntil>performance.now())}
function moveCrewTo(actor,destination,dt,speed=1.05){
 const u=actor.userData,boat=actor.parent,to=crewNavigationPost(bm,destination);if(actor.position.distanceTo(to)<.045){if(boat.userData.passageOwner===actor)boat.userData.passageOwner=null;u.taskRoute=null;return true}
 let job=u.taskRoute;if(!job||job.boat!==boat||job.goal.distanceTo(to)>.025||job.blocked>1.2){job=u.taskRoute={boat,goal:to,path:planBoatCrewRoute(bm,boat,actor.position,to),blocked:0}}
 job.attempted=false;if(!job.path.length){u.taskRoute=null;return false}const previous=actor.position.clone();stepBoatCrewRoute(actor,boat,job.path,dt,speed);job.attempted=actor.position.distanceToSquared(previous)>1e-9;return false;
}
