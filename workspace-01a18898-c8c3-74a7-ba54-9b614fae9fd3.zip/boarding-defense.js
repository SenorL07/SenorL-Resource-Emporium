// Close boarding defense owns movement until the immediate assault is repelled.
export function createBoardingDefenseSystem(T,{time,ready,route,planRoute,rig,release,lineOfSight,door,shoot,canStep=()=>true,meleeOnly=()=>false}){
 const jobs=new Map(),doorOwners=new WeakMap();
 function clear(actor){const job=jobs.get(actor);if(job?.boat&&doorOwners.get(job.boat)===actor)doorOwners.delete(job.boat);if(job?.cover&&actor.parent===job.boat&&ready(actor)&&!actor.userData.firefighting&&!actor.userData.resting&&!actor.userData.sleeping){const side=job.home.x<0?-1:1;const inside=Math.abs(actor.position.x)<.85&&actor.position.z> -1.44&&actor.position.z<.28&&actor.position.y<1.3;actor.userData.deckTransit=planRoute(job.boat,actor.position,job.home)}jobs.delete(actor);actor.userData.closeDefense=false;actor.userData.takingCover=false}
 function walk(actor,job,dt,boat){
  while(job.path?.length&&actor.position.distanceTo(job.path[0])<.045){actor.position.copy(job.path.shift())}
  if(!job.path?.length){if(boat.userData.passageOwner===actor)boat.userData.passageOwner=null;if(doorOwners.get(boat)===actor)doorOwners.delete(boat);return true;}
  const goal=job.path[0];if(job.cover&&Math.abs(goal.x)<.01){const owner=doorOwners.get(boat);if(owner&&owner!==actor&&jobs.has(owner)&&ready(owner))return false;doorOwners.set(boat,actor)}const inside=goal.z> -1.7&&Math.abs(goal.x)<.85&&goal.y<1.3;
  if(!door(boat,actor,goal))return false;
  const point=goal,d=point.clone().sub(actor.position),n=d.length(),climb=Math.abs(d.y)>.05;
  if(n>.01){const next=actor.position.clone().addScaledVector(d,Math.min(n,dt*(climb?.8:1.35))/n);if(job.cover&&!canStep(actor,next,boat))return false;actor.position.copy(next);if(!climb)actor.rotation.y=Math.atan2(d.x,d.z)}
  const r=rig(actor);r.legs.forEach((l,i)=>l.rotation.x=Math.sin(time()*11+i*Math.PI)*.5);r.arms.forEach((a,i)=>a.rotation.x=climb?-2.2+Math.sin(time()*9+i*Math.PI)*.35:job.cover?-.7:0);return false;
 }
 function guard(actor,boat,target,enabled,dt,index=0){
  if(!enabled||!ready(actor)||actor.userData.burning||actor.userData.firefighting||actor.userData.equipmentJob||actor.userData.resting||actor.userData.sleeping){if(jobs.has(actor))clear(actor);return}
  const u=actor.userData;u.closeDefense=true;u.deckTransit=null;release(actor);
  let job=jobs.get(actor);if(!job||job.cover){job={cover:false,repath:0,path:null};jobs.set(actor,job)}
  if(!target)return;
  const unarmed=meleeOnly(actor);const from=actor.localToWorld(new T.Vector3(.1,1.08,.65)),clearShot=lineOfSight(actor.localToWorld(new T.Vector3(0,1.08,0)),from,actor,target.actor)&&lineOfSight(from,target.position,actor,target.actor),local=boat.worldToLocal(target.position.clone());
  if(time()>job.repath&&(!clearShot||actor.position.y>1.3||from.distanceTo(target.position)>(unarmed?1.9:18))){
   job.repath=time()+1.2;
   const posts=[];if(unarmed){const roofY=boat.userData.fleetModel?.userData.roofLevels?.at(-1)||2.1,inside=Math.abs(local.x)<.78&&local.z> -1.3&&local.z<.14;posts.push(new T.Vector3(inside?Math.max(-.65,Math.min(.65,local.x)):Math.abs(local.x)>.85?Math.sign(local.x)*1.18:local.x,local.y>roofY+.3?roofY:.38,Math.max(-2.4,Math.min(1.9,local.z))))}for(const side of [-1,1])for(const z of [-2.04,-.95,.85,1.7])posts.push(new T.Vector3(side*1.18,.38,z));posts.push(new T.Vector3(0,.38,1.65));
   if(local.y<1.5&&Math.abs(local.x)<.85&&local.z> -1.43&&local.z<.28)posts.push(new T.Vector3(.10,.38,-1.10),new T.Vector3(.48,.38,-.55),new T.Vector3(-.48,.38,-.55));
   const roof=boat.userData.fleetModel?.userData.roofLevels?.at(-1)||2.1,obstruction=Math.max(0,...(boat.userData.fleetBlocks||[]).map(b=>b.y1));if(local.y>roof-.4&&roof>=obstruction-.05)for(const x of[-.45,.45])for(const z of[-.95,-.40])posts.push(new T.Vector3(x,roof,z));
   posts.sort((a,b)=>{const score=p=>{const offset=new T.Vector3(.1,1.08,.65).multiply(actor.scale).applyAxisAngle(new T.Vector3(0,1,0),Math.atan2(local.x-p.x,local.z-p.z)),muzzle=boat.localToWorld(p.clone().add(offset)),body=boat.localToWorld(p.clone().add(new T.Vector3(0,1.08*actor.scale.y,0)));return (unarmed?p.distanceTo(local)*5:0)+(lineOfSight(body,muzzle,actor,target.actor)&&lineOfSight(muzzle,target.position,actor,target.actor)?0:60)+p.distanceTo(actor.position)*.6+p.distanceTo(local)*.4+Math.abs(p.z-(index%2?.85:1.7))*.1};return score(a)-score(b)});
   if(!job.goal||job.goal.distanceTo(posts[0])>.3||!job.path?.length){job.goal=posts[0];job.path=planRoute(boat,actor.position,job.goal)}
  }
  const climbing=job.path?.length&&Math.abs(job.path[0].y-actor.position.y)>.05;walk(actor,job,dt,boat);
  if(!climbing){actor.rotation.y=Math.atan2(local.x-actor.position.x,local.z-actor.position.z);shoot(actor,target)}
 }
 function civilian(actor,boat,enabled,dt,index=0){
  if(!enabled||!ready(actor)||actor.userData.firefighting||actor.userData.equipmentJob||actor.parent!==boat||actor.userData.burning||actor.userData.overboard||actor.userData.resting||actor.userData.sleeping){if(jobs.has(actor))clear(actor);return}
  const u=actor.userData;u.takingCover=true;u.deckTransit=null;release(actor);let job=jobs.get(actor);
  if(!job||!job.cover){const side=actor.position.x<0?-1:1,spot=new T.Vector3(index%2? .53:-.53,.38,-1.12+Math.floor(index/2)*.45),inside=Math.abs(actor.position.x)<.8&&actor.position.z> -1.44&&actor.position.z<.2&&actor.position.y<1.3;
   job={cover:true,boat,home:actor.position.clone(),path:planRoute(boat,actor.position,spot)};jobs.set(actor,job)}
  if(walk(actor,job,dt,boat)){actor.rotation.y=Math.PI;const r=rig(actor);r.legs.forEach(l=>l.rotation.x=0);r.arms.forEach(a=>a.rotation.x=-.65)}
 }
 function reset(actor){const job=jobs.get(actor);if(job?.boat&&doorOwners.get(job.boat)===actor)doorOwners.delete(job.boat);jobs.delete(actor);actor.userData.closeDefense=false;actor.userData.takingCover=false}
 return {guard,civilian,clear,reset,jobs};
}
