import * as THREE from 'three';
import * as AudioRuntime from './sound.js';

// Procedural, indefinitely deep dungeon subsystem. Only the current floor is
// rendered; visited-floor state is kept as compact data and regenerated on return.
export function createDungeonSystem({scene,camera,save,persist,notify,awardXP,refreshHud,setPlayerHealth=()=>{},onPlayerDeath=()=>{},isPlayerDead=()=>false,isInvincible=()=>false,onPlayerHurt=()=>{},onEnemyVanish=()=>{},sfx,getView,setView,getWeapons,getGround,ensureAsset=()=>Promise.resolve(null),cloneAsset=()=>null,getAssetAnimations=()=>[],lowPower:deviceLowPower=false,entrancePosition={x:-48,z:44}}){
  const shared={
    stone:new THREE.MeshStandardMaterial({color:'#45434d',roughness:.95}),
    stoneAlt:new THREE.MeshStandardMaterial({color:'#59535b',roughness:.92}),
    trim:new THREE.MeshStandardMaterial({color:'#292831',roughness:.85}),
    bone:new THREE.MeshStandardMaterial({color:'#d5c9a4',roughness:.8}),
    metal:new THREE.MeshStandardMaterial({color:'#665a50',metalness:.35,roughness:.7}),
    dark:new THREE.MeshStandardMaterial({color:'#13121b',roughness:1}),
    wood:new THREE.MeshStandardMaterial({color:'#62452e',roughness:.86}),
    seam:new THREE.MeshBasicMaterial({color:'#77727b',transparent:true,opacity:.34}),
    crystalA:new THREE.MeshStandardMaterial({color:'#62d6d0',emissive:'#238b87',emissiveIntensity:1.1,roughness:.25}),
    crystalB:new THREE.MeshStandardMaterial({color:'#c29aff',emissive:'#7849a8',emissiveIntensity:1.2,roughness:.25}),
    glow:new THREE.MeshBasicMaterial({color:'#91e5db',transparent:true,opacity:.8,side:THREE.DoubleSide}),
    flame:new THREE.MeshBasicMaterial({color:'#ff9a48'}),
    boxGeo:new THREE.BoxGeometry(1,1,1),
    sphereGeo:new THREE.IcosahedronGeometry(1,1),
    smoothGeo:new THREE.SphereGeometry(1,10,7),
    cylinderGeo:new THREE.CylinderGeometry(.5,.5,1,8),
    coneGeo:new THREE.ConeGeometry(.5,1,7),
    planeGeo:new THREE.PlaneGeometry(1,1)
  };
  const themes=[
    {name:'SALTCRYPT',wall:'#605864',floor:'#4a4852',light:'#9bd8cc',fog:'#11151e'},
    {name:'SMUGGLER MINE',wall:'#69564a',floor:'#54463d',light:'#ffb46d',fog:'#1b130f'},
    {name:'ROOT MAZE',wall:'#51634f',floor:'#3f4c40',light:'#c0df79',fog:'#101812'},
    {name:'DROWNED VAULT',wall:'#496474',floor:'#3d5360',light:'#7fe2e5',fog:'#0d1820'},
    {name:'BONE GALLERY',wall:'#6b6053',floor:'#4e4842',light:'#f0c98c',fog:'#191411'}
  ];
  const themeMaterials=themes.map(t=>({wall:new THREE.MeshStandardMaterial({color:t.wall,roughness:.94}),floor:new THREE.MeshStandardMaterial({color:t.floor,roughness:.98}),ceiling:new THREE.MeshStandardMaterial({color:'#34313b',roughness:.98})}));
  const root=new THREE.Group();root.visible=false;root.name='Endless Fishermen Dungeon';scene.add(root);
  const floorCache=new Map(),runtimeEnemies=[],runtimeChests=[],obstacles=[],tracers=[],wallSegments=[],defeatedEnemies=[],enemyMixers=[];let targetMap=new WeakMap(),floorLayout=null;
  const enemySightRaycaster=new THREE.Raycaster(),enemySightHits=[];
  let active=false,floorNumber=0,floorY=-70,floorRoot=null,currentTheme=themes[0],returnView=null,health=100,actionLabel='',updateClock=0,portalPulse=0,moveVel=new THREE.Vector3(),jumpVelocity=0,jumpOffset=0;
  const ROOM=54,HALF=ROOM/2-2.5,ENTRANCE_X=entrancePosition.x,ENTRANCE_Z=entrancePosition.z,ENTRY_RANGE=3.6,cashFmt=n=>'$'+Math.floor(n).toLocaleString();function roomHeightAt(x,z){if(Math.abs(x-16)<2.1&&z>=10&&z<=20.5)return -Math.min(4.65,Math.max(0,(z-11)*.55));if(Math.abs(x+18)<2.1&&z<=-14.5&&z>=-23.5)return Math.min(4.65,Math.max(0,(-z-15)*.55));if(!floorLayout)return 0;for(const room of floorLayout.rooms)if(x>=room.x0&&x<=room.x1&&z>=room.z0&&z<=room.z1)return room.height;return 0}
  const envOriginal={background:scene.background?.clone?.()||scene.background,fog:scene.fog?.clone?.()||scene.fog};
  const prompt=document.querySelector('#dungeonPrompt'),hud=document.querySelector('#dungeonHUD'),floorText=document.querySelector('#dungeonFloor'),enemyText=document.querySelector('#dungeonEnemies'),actionButton=document.querySelector('#dungeonAction'),ropeButton=document.querySelector('#dungeonRope');

  function rngFrom(seed){let s=seed>>>0;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
  function randInt(rng,a,b){return a+Math.floor(rng()*(b-a+1))}
  function mesh(parent,geo,material,pos,scale,rot){const m=new THREE.Mesh(geo,material);m.position.set(...pos);m.scale.set(...scale);if(rot)m.rotation.set(...rot);m.castShadow=!deviceLowPower;m.receiveShadow=m.castShadow;parent.add(m);return m}
  function box(parent,pos,size,material=shared.stone){return mesh(parent,shared.boxGeo,material,pos,size)}
  function pointAtFloor(x,z,y=floorY){return new THREE.Vector3(x,y+0.03,z)}
  function makeEntrance(){
    const g=new THREE.Group(),y=getGround(ENTRANCE_X,ENTRANCE_Z);g.position.set(ENTRANCE_X,y,ENTRANCE_Z);g.name='Dungeon entrance';scene.add(g);
    const pillarGeo=new THREE.CylinderGeometry(.34,.48,4.2,7),capGeo=new THREE.BoxGeometry(5.15,.65,.9),ringGeo=new THREE.TorusGeometry(1.28,.13,7,18);
    const pillarMat=new THREE.MeshStandardMaterial({color:'#4c4b52',roughness:.9}),trimMat=new THREE.MeshStandardMaterial({color:'#77716a',roughness:.8});
    for(const x of [-2,2]){const p=new THREE.Mesh(pillarGeo,pillarMat);p.position.set(x,2.1,0);p.castShadow=true;g.add(p);const band=new THREE.Mesh(new THREE.CylinderGeometry(.45,.45,.24,7),trimMat);band.position.set(x,3.45,0);g.add(band)}
    const cap=new THREE.Mesh(capGeo,trimMat);cap.position.set(0,4.15,0);cap.castShadow=true;g.add(cap);
    const portal=new THREE.Mesh(new THREE.PlaneGeometry(3.1,3.25),new THREE.MeshBasicMaterial({color:'#15212a',side:THREE.DoubleSide}));portal.position.set(0,1.9,.08);g.add(portal);
    const glow=new THREE.Mesh(ringGeo,shared.glow);glow.position.set(0,1.93,.16);g.add(glow);
    const beads=[];for(let i=0;i<3;i++){const bead=new THREE.Mesh(shared.sphereGeo,new THREE.MeshBasicMaterial({color:['#9df4df','#ba9bff','#83d5ff'][i],transparent:true,opacity:.78}));bead.scale.set(.09,.09,.09);bead.position.set(Math.sin(i*2.1)*.7,1.85+Math.cos(i*2.1)*.8,.25);g.add(bead);beads.push(bead)}
    const light=new THREE.PointLight(0x72d8d4,5,14,2);light.position.set(0,2.1,1.1);g.add(light);
    const board=new THREE.Mesh(new THREE.BoxGeometry(4.5,.76,.18),trimMat);board.position.set(0,4.9,.15);g.add(board);
    const c=document.createElement('canvas');c.width=768;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#202329';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#e4d6ab';ctx.font='bold 56px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('THE SINKING STAIRS',384,66);const tex=new THREE.CanvasTexture(c);const label=new THREE.Mesh(new THREE.PlaneGeometry(4.15,.66),new THREE.MeshBasicMaterial({map:tex,transparent:true}));label.position.set(0,4.9,.255);g.add(label);
    return {group:g,glow,light,beads,y};
  }
  const entrance=makeEntrance();
  function randomFloorData(n){
    const seed=(Math.random()*0xffffffff)>>>0,rng=rngFrom(seed),themeIndex=randInt(rng,0,themes.length-1),theme=themes[themeIndex];
    const enemies=[],chests=[],props=[];const xCuts=[-27,randInt(rng,-11,-7),randInt(rng,7,11),27],zCuts=[-27,randInt(rng,-11,-7),randInt(rng,7,11),27],rooms=[];for(let row=0;row<3;row++)for(let col=0;col<3;col++){let height=randInt(rng,0,2)*.48;if((row===0&&col===0)||(row===1&&col===0)||(row===2&&col===2))height=0;rooms.push({row,col,x0:xCuts[col],x1:xCuts[col+1],z0:zCuts[row],z1:zCuts[row+1],height})}const vDoors=[],hDoors=[];for(let line=1;line<3;line++)for(let row=0;row<3;row++)vDoors.push({x:xCuts[line],z0:zCuts[row],z1:zCuts[row+1],center:(zCuts[row]+zCuts[row+1])/2+randInt(rng,-2,2)});for(let line=1;line<3;line++)for(let col=0;col<3;col++)hDoors.push({z:zCuts[line],x0:xCuts[col],x1:xCuts[col+1],center:(xCuts[col]+xCuts[col+1])/2+randInt(rng,-2,2)});const layout={xCuts,zCuts,rooms,vDoors,hDoors};
    const kinds=['fisher_fists','fisher_club','fisher_gunner','fisher_veteran','bat','bat_swift','bat_dire','slime','slime_spitter','slime_brute','skeleton','skeleton_guard','skeleton_captain','goblin','goblin_slinger','goblin_brute'];
    const count=Math.min(5+Math.floor((n-1)*.55),18);
    // Every crypt family spawns in three breeds; the specialists are rarer than the baseline.
    const chooseKind=()=>{const r=rng();
      if(r<.24)return 'fisher_fists';if(r<.42)return 'fisher_club';if(r<.57)return 'fisher_gunner';if(r<.65)return 'fisher_veteran';
      if(r<.705)return 'bat';if(r<.735)return 'bat_swift';if(r<.76)return 'bat_dire';
      if(r<.815)return 'slime';if(r<.845)return 'slime_spitter';if(r<.87)return 'slime_brute';
      if(r<.915)return 'skeleton';if(r<.945)return 'skeleton_guard';if(r<.965)return 'skeleton_captain';
      if(r<.985)return 'goblin';if(r<.995)return 'goblin_slinger';return 'goblin_brute'};
    for(let i=0;i<count;i++){
      const kind=chooseKind();let x=0,z=0,tries=0;
      do{if(i<3){x=randInt(rng,-16,-6);z=randInt(rng,-16,-7)}else{x=randInt(rng,-17,17);z=randInt(rng,-17,17)}tries++}while(tries<35&&(Math.hypot(x+18,z)<10||Math.hypot(x-16,z-18)<6||enemies.some(e=>Math.hypot(e.x-x,e.z-z)<3)));
      const vstats=mobStats(kind),baseHp=vstats.base==='bat'?25:vstats.base==='slime'?58:vstats.base==='skeleton'?43:kind.startsWith('fisher')?48:50;
      const hp=Math.round((baseHp+n*(kind==='fisher_veteran'?9:vstats.base==='slime'?11:7))*vstats.hp);
      enemies.push({id:`${n}-e${i}`,kind,x,z,hp,maxHp:hp,alive:true,aggro:false,cooldown:rng()*1.4,attackPhase:rng()*6.28});
    }
    const chestCount=randInt(rng,1,4);
    for(let i=0;i<chestCount;i++){
      let x=0,z=0,tries=0;do{x=randInt(rng,-17,17);z=randInt(rng,-17,17);tries++}while(tries<45&&(Math.hypot(x+18,z)<8||Math.hypot(x-16,z-18)<5||chests.some(c=>Math.hypot(c.x-x,c.z-z)<4)||enemies.some(e=>Math.hypot(e.x-x,e.z-z)<2.2)));
      const boost=Math.min(48,(n-1)*1.05),roll=rng()*100+boost;const quality=roll<34?0:roll<62?1:roll<82?2:roll<95?3:4;
      const qty=randInt(rng,1,2)+(quality>=3?1:0)+Math.min(2,Math.floor((n-1)/8));
      const lootTypes=quality>=4?['cash','rope','charm','weapon','health']:quality>=3?['cash','rope','crate','charm','health']:quality>=2?['cash','rope','crate','health']:['cash','cash','health','rope'];
      const lootType=lootTypes[randInt(rng,0,lootTypes.length-1)];
      chests.push({id:`${n}-c${i}`,x,z,quality,qty,lootType,opened:false});
    }
    const propCount=randInt(rng,7,13);
    for(let i=0;i<propCount;i++){const x=randInt(rng,-22,22),z=randInt(rng,-22,22);if(Math.hypot(x+18,z)<7||Math.hypot(x-16,z-18)<6||(x>-18&&x<-6&&z<0)||chests.some(c=>Math.hypot(c.x-x,c.z-z)<3.2))continue;props.push({x,z,type:rng()<.58?'pillar':'rubble',s:.7+rng()*1.2})}
    return {floor:n,seed,themeIndex,theme,enemies,chests,props,layout};
  }
  function clearFloor(){
    for(const e of runtimeEnemies){renderRecords.delete(e);e.root.visible=false;AudioRuntime.resetNpcAudio(e.root);removeHealthBar(e);e.root.userData.ownedFlashMaterial?.dispose()}
    if(floorRoot){floorRoot.traverse(o=>{if(o.userData.ownedMaterial&&o.material){o.material.map?.dispose();o.material.dispose()}});root.remove(floorRoot);floorRoot=null}
    runtimeEnemies.length=0;runtimeChests.length=0;obstacles.length=0;wallSegments.length=0;defeatedEnemies.length=0;enemyMixers.length=0;targetMap=new WeakMap();floorLayout=null;navGrid=null;sightMeshes.length=0;
    for(const line of tracers){root.remove(line.obj);line.obj.geometry.dispose();line.obj.material.dispose()}tracers.length=0;
  }
  function makeTorch(parent,x,z,y,theme){
    const flame=mesh(parent,shared.sphereGeo,shared.flame,[x,y,z],[.12,.22,.12]);
    const light=new THREE.PointLight(theme.light,3.5,27,2);light.position.set(x,y+.25,z);parent.add(light);return {flame,light,phase:Math.random()*8,power:3.5};
  }
  function replaceDungeonShell(structure){
    const parent=floorRoot;
    Promise.all([ensureAsset('dungeonModuleWall'),ensureAsset('dungeonModuleFloor')]).then(([wallReady,floorReady])=>{
      if(!wallReady||!floorReady||floorRoot!==parent)return;
      const floors=structure.filter(s=>s.kind==='floor'),walls=structure.filter(s=>s.kind==='wall');
      const floorTemplate=cloneAsset('dungeonModuleFloor',1);let floorTransforms=[];
      if(floorTemplate){let baseMesh=null;floorTemplate.updateMatrixWorld(true);floorTemplate.traverse(o=>{if(o.isMesh&&!baseMesh)baseMesh=o});if(baseMesh){const geometry=baseMesh.geometry.clone();geometry.applyMatrix4(baseMesh.matrixWorld);for(const item of floors){const {pos,size,mesh:old}=item;old.visible=false;const startX=pos[0]-size[0]/2,startZ=pos[2]-size[2]/2,top=pos[1]+size[1]/2+.012;for(let x=startX;x<pos[0]+size[0]/2-.001;){const span=Math.min(4,pos[0]+size[0]/2-x);for(let z=startZ;z<pos[2]+size[2]/2-.001;){const depth=Math.min(4,pos[2]+size[2]/2-z),dummy=new THREE.Object3D();dummy.position.set(x+span/2,top,z+depth/2);dummy.scale.set(span/4,1,depth/4);dummy.updateMatrix();floorTransforms.push(dummy.matrix.clone());z+=depth}x+=span}}
          if(floorTransforms.length){const inst=new THREE.InstancedMesh(geometry,baseMesh.material,floorTransforms.length);inst.name='Kenney CC0 modular dungeon floor';for(let i=0;i<floorTransforms.length;i++)inst.setMatrixAt(i,floorTransforms[i]);inst.instanceMatrix.needsUpdate=true;inst.castShadow=false;inst.receiveShadow=true;parent.add(inst)}
        }}
      for(const item of walls){const {pos,size,mesh:old}=item;old.visible=false;const alongX=size[0]>=size[2],length=alongX?size[0]:size[2],thickness=alongX?size[2]:size[0],start=alongX?pos[0]-size[0]/2:pos[2]-size[2]/2,bottom=pos[1]-size[1]/2;for(let d=0;d<length-.001;){const span=Math.min(4,length-d);for(let y=0;y<size[1]-.001;){const height=Math.min(4.15,size[1]-y),model=cloneAsset('dungeonModuleWall',4.15);if(model){model.position.set(alongX?start+d+span/2:pos[0],bottom+y,alongX?pos[2]:start+d+span/2);model.rotation.y=alongX?0:Math.PI/2;model.scale.x*=span/4;model.scale.y*=height/4.15;model.scale.z*=thickness/1.99;model.name='Kenney CC0 modular dungeon wall';parent.add(model)}y+=height}d+=span}}
    }).catch(error=>console.warn('[dungeon shell assets]',error));
  }
  function buildRoom(data){
    floorY=-70-(data.floor-1)*22;currentTheme=themes[data.themeIndex];floorLayout=data.layout;scene.background=new THREE.Color(currentTheme.fog);scene.fog=new THREE.FogExp2(currentTheme.fog,.0075);floorRoot=new THREE.Group();floorRoot.position.y=floorY;floorRoot.name=`Dungeon floor ${data.floor} · ${data.layout.rooms.length} rooms`;root.add(floorRoot);
    const mats=themeMaterials[data.themeIndex],wallMat=mats.wall,floorMat=mats.floor,ceilingMat=mats.ceiling;const structure=[],shellBox=(pos,size,material,kind)=>{const m=box(floorRoot,pos,size,material);structure.push({mesh:m,pos,size,kind});return m};const shaft={x0:13.5,x1:18.5,z0:9.5,z1:20.5};shellBox([-6.75,-.36,0],[40.5,.72,ROOM],floorMat,'floor');shellBox([22.75,-.36,0],[8.5,.72,ROOM],floorMat,'floor');shellBox([16,-.36,-9.25],[5,.72,36.5],floorMat,'floor');shellBox([16,-.36,23.75],[5,.72,6.5],floorMat,'floor');for(const room of data.layout.rooms)if(room.height>.05){const w=room.x1-room.x0,d=room.z1-room.z0;shellBox([(room.x0+room.x1)/2,room.height-.16,(room.z0+room.z1)/2],[w-.12,.32,d-.12],floorMat,'floor')}
    shellBox([0,4.2,-ROOM/2],[ROOM,8.4,.8],wallMat,'wall');shellBox([0,4.2,ROOM/2],[ROOM,8.4,.8],wallMat,'wall');
    shellBox([ROOM/2,4.2,0],[.8,8.4,ROOM],wallMat,'wall');
    const addPartition=(axis,pos,start,end)=>{if(end-start<.4)return;if(axis==='x'){shellBox([pos,3.25,(start+end)/2],[.72,6.5,end-start],wallMat,'wall');wallSegments.push({axis,coord:pos,min:start,max:end})}else{shellBox([(start+end)/2,3.25,pos],[end-start,6.5,.72],wallMat,'wall');wallSegments.push({axis,coord:pos,min:start,max:end})}};for(const door of data.layout.vDoors){const gap=2.15;addPartition('x',door.x,door.z0,Math.max(door.z0,door.center-gap));addPartition('x',door.x,Math.min(door.z1,door.center+gap),door.z1)}for(const door of data.layout.hDoors){const gap=2.15;addPartition('z',door.z,door.x0,Math.max(door.x0,door.center-gap));addPartition('z',door.z,Math.min(door.x1,door.center+gap),door.x1)}
    // Leave a doorway in the west wall, replacing it with an exit portal on floor one.
    shellBox([-ROOM/2,4.2,-13.4],[.8,8.4,27.2],wallMat,'wall');shellBox([-ROOM/2,4.2,13.4],[.8,8.4,27.2],wallMat,'wall');
    replaceDungeonShell(structure);box(floorRoot,[0,8.45,0],[ROOM,.55,ROOM],ceilingMat);
    // A few cracked floor seams give scale without an expensive texture dependency.
    const lineMat=shared.seam;
    for(let i=-4;i<=4;i++){
      const l=new THREE.Mesh(new THREE.BoxGeometry(.025,.008,ROOM-.8),lineMat);l.position.set(i*5.8,.008,0);floorRoot.add(l);
      const l2=new THREE.Mesh(new THREE.BoxGeometry(ROOM-.8,.008,.025),lineMat);l2.position.set(0,.008,i*5.8);floorRoot.add(l2);
    }
    for(let i=0;i<4;i++){
      const x=i%2?-24:24,z=i<2?-23:23,pillar=box(floorRoot,[x,4,z],[1.2,8,1.2],shared.trim),cap=box(floorRoot,[x,7.6,z],[1.65,.65,1.65],shared.stoneAlt),pillarParent=floorRoot;
      ensureAsset('dungeonPillar').then(result=>{if(!result||floorRoot!==pillarParent)return;const a=cloneAsset('dungeonPillar',4.05);if(!a)return;pillar.visible=false;a.position.set(x,0,z);a.name='Kenney CC0 dungeon stone pier';const b=cloneAsset('dungeonPillar',4.05);if(b){b.position.set(x,4.02,z);b.name='Kenney CC0 dungeon stone pier cap';pillarParent.add(b)}pillarParent.add(a);const top=cloneAsset('dungeonWallTop',.65);if(top){top.position.set(x,7.28,z);top.name='Kenney CC0 dungeon pillar capital';pillarParent.add(top);cap.visible=false}});
    }
    const deco=rngFrom(data.seed^0x9e3779b9);for(let i=0;i<18;i++){const x=randInt(deco,-23,23),z=randInt(deco,-23,23);if(Math.hypot(x+18,z)<5||Math.hypot(x-16,z-18)<5)continue;const h=.65+deco()*1.65;mesh(floorRoot,shared.coneGeo,shared.stoneAlt,[x,h*.5,z],[.36+deco()*.32,h,.36+deco()*.32],[deco()*.12,0,deco()*.12]);if(i%2===0)mesh(floorRoot,shared.coneGeo,shared.stoneAlt,[x,8-h*.5,z],[.33,h,.33],[Math.PI,0,0]);if(i%3===0){const crystal=mesh(floorRoot,shared.coneGeo,i%2?shared.crystalA:shared.crystalB,[x+.6,.7,z+.2],[.22,.95,.22],[0,deco()*6,0]),propParent=floorRoot;ensureAsset('dungeonPotion').then(result=>{if(!result||floorRoot!==propParent)return;const potion=cloneAsset('dungeonPotion',.85);if(!potion)return;crystal.visible=false;potion.position.set(x+.6,.02,z+.2);potion.name='Kenney CC0 dungeon potion prop';propParent.add(potion)});obstacles.push({x:x+.6,z:z+.2,r:.5})}}
    for(let i=0;i<5;i++){const x=randInt(deco,-20,20),z=randInt(deco,-18,18);const puddle=new THREE.Mesh(new THREE.CircleGeometry(1.2+deco(),10),new THREE.MeshBasicMaterial({color:'#1b4f58',transparent:true,opacity:.22,depthWrite:false,side:THREE.DoubleSide}));puddle.rotation.x=-Math.PI/2;puddle.position.set(x,.016,z);puddle.userData.ownedMaterial=true;floorRoot.add(puddle)}
    const torches=[],torchSpots=deviceLowPower?[[-21,-21],[21,-21],[-21,21],[21,21]]:[[-22,-21],[22,-21],[-22,21],[22,21],[-2,-23],[-5,0],[7,0],[0,-10],[0,13]];for(const [x,z] of torchSpots)torches.push(makeTorch(floorRoot,x,z,3.8,currentTheme));const coreLight=new THREE.PointLight(currentTheme.light,5.2,34,2);coreLight.position.set(0,4,0);floorRoot.add(coreLight);torches.push({light:coreLight,flame:null,phase:Math.random()*8,power:5.2});
    if(data.floor===1){
      box(floorRoot,[-26,1.8,-2.7],[.45,3.6,1.1],shared.trim);box(floorRoot,[-26,1.8,2.7],[.45,3.6,1.1],shared.trim);box(floorRoot,[-26,3.85,0],[.45,.42,5.7],shared.trim);
      const portal=new THREE.Mesh(new THREE.PlaneGeometry(4.2,5.7),new THREE.MeshBasicMaterial({color:'#65b9b5',transparent:true,opacity:.3,side:THREE.DoubleSide}));portal.rotation.y=Math.PI/2;portal.position.set(-25.72,2.85,0);floorRoot.add(portal);
      const pl=new THREE.PointLight(0x78dad1,3.3,13,2);pl.position.set(-22.6,2.8,0);floorRoot.add(pl);
    }else buildStair(floorRoot,-18,-15,1,currentTheme.light,true);
    buildStair(floorRoot,16,11,1,currentTheme.light,false);
    // Randomized room dressings, pillars and rubble become solid cover for both factions.
    for(const p of data.props){
      if(p.type==='pillar'){
        const h=2.2+p.s*1.4;const m=mesh(floorRoot,shared.cylinderGeo,shared.stoneAlt,[p.x,h/2,p.z],[.95*p.s,h,.95*p.s]);const parent=floorRoot;ensureAsset('dungeonPropStones').then(result=>{if(!result||m.parent!==parent||m.userData.assetReplaced)return;const asset=cloneAsset('dungeonPropStones',h);if(!asset)return;m.visible=false;asset.position.set(p.x,0,p.z);asset.name='Kenney CC0 dungeon stone cluster';parent.add(asset);m.userData.assetReplaced=true});
        obstacles.push({x:p.x,z:p.z,r:.72*p.s});
      }else{
        const m=mesh(floorRoot,shared.sphereGeo,shared.stone,[p.x,.42*p.s,p.z],[1.3*p.s,.75*p.s,.9*p.s],[Math.random()*.4,Math.random()*6,Math.random()*.4]);const parent=floorRoot;ensureAsset('dungeonPropRocks').then(result=>{if(!result||m.parent!==parent||m.userData.assetReplaced)return;const asset=cloneAsset('dungeonPropRocks',Math.max(.8,1.1*p.s));if(!asset)return;m.visible=false;asset.position.set(p.x,0,p.z);asset.rotation.y=Math.random()*6.28;asset.name='Kenney CC0 dungeon rubble';parent.add(asset);m.userData.assetReplaced=true});
        obstacles.push({x:p.x,z:p.z,r:.9*p.s});
      }
    }
    for(const e of data.enemies)if(e.alive)spawnEnemy(e,data.floor);
    for(const c of data.chests)if(!c.opened)spawnChest(c);
    prepareFloorNavigation();
    // Procedural spawn points must not start embedded in partitions or props.
    for(const enemy of runtimeEnemies)if(!walkPointClear(enemy.root.position.x,enemy.root.position.z,enemy.radius)){
      const id=nearestNavNode(enemy.root.position);if(id>=0){enemy.root.position.x=NAV_MIN+id%NAV_SIZE;enemy.root.position.z=NAV_MIN+Math.floor(id/NAV_SIZE);enemy.data.x=enemy.root.position.x;enemy.data.z=enemy.root.position.z}
    }
    return torches;
  }
  function buildStair(parent,x,z,stepX,color,up){
    const lightMat=new THREE.MeshBasicMaterial({color,transparent:true,opacity:.45}),stepMeshes=[];
    for(let i=0;i<9;i++){
      const yy=up?i*.58+.26:-i*.58-.12,zz=z+(up?-i:i)*1.03;
      stepMeshes.push(box(parent,[x,yy,zz],[4,.5,1.15],i%2?shared.stoneAlt:shared.stone));
      stepMeshes.push(mesh(parent,shared.boxGeo,lightMat,[x,yy+.26,zz-.47],[3.6,.045,.07]));
    }
    const stairParent=floorRoot;ensureAsset('dungeonStairs').then(result=>{if(!result||floorRoot!==stairParent)return;const model=cloneAsset('dungeonStairs',4.9);if(!model)return;for(const m of stepMeshes)m.visible=false;model.position.set(x,up?0:0,z);model.scale.y*=up?1:-1;model.name='Kenney CC0 modular dungeon stairs';parent.add(model)});
    box(parent,[x,up?4.9:-4.62,z+(up?-9:9)],[5,.25,4],shared.trim);
    const sign=mesh(parent,shared.boxGeo,shared.flame,[x,2.5,z-1.2],[.4,.4,.4]);
    return {x:x,z:z+(up?-8:8)};
  }
  function putNameplate(parent,name,y,color){
    if(deviceLowPower)return null;
    const c=document.createElement('canvas');c.width=256;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='rgba(12,12,16,.8)';ctx.fillRect(0,0,256,64);ctx.fillStyle=color;ctx.font='bold 24px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(name.toUpperCase(),128,32);const tex=new THREE.CanvasTexture(c);const spr=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false}));spr.userData.ownedMaterial=true;spr.scale.set(2.2,.55,1);spr.position.y=y;parent.add(spr);return spr;
  }
  // Every crypt family has three breeds with their own silhouette, bulk and attack:
  // `base` picks the model, `scale`/`hp`/`speed`/`damage` differ, and `weapon` decides
  // whether it closes to maul or attacks at range (gun, thrown rock, acid glob).
  const enemyPalette={
    fisher_fists:{name:'Unlicensed Deckhand',faction:'fisher',shirt:'#66715a',skin:'#b98968',weapon:'fists'},
    fisher_club:{name:'Dockside Bruiser',faction:'fisher',shirt:'#86553b',skin:'#b77c5d',weapon:'club'},
    fisher_gunner:{name:'Contraband Gunner',faction:'fisher',shirt:'#455a67',skin:'#b98868',weapon:'gun'},
    fisher_veteran:{name:'Gill Tycoon Enforcer',faction:'fisher',shirt:'#5c3945',skin:'#c29a74',weapon:'gun'},
    bat:{name:'Cave Bat',faction:'crypt',shirt:'#252333',skin:'#48405d',weapon:'claws',base:'bat'},
    bat_swift:{name:'Squall Bat',faction:'crypt',shirt:'#2d3450',skin:'#5d6b8c',weapon:'claws',base:'bat',scale:.84,hp:.7,speed:1.38,damage:.8},
    bat_dire:{name:'Harbour Vampire',faction:'crypt',shirt:'#3b1f2c',skin:'#7a3a49',weapon:'claws',base:'bat',scale:1.34,hp:1.85,speed:.94,damage:1.45},
    slime:{name:'Sump Slime',faction:'crypt',shirt:'#64ba94',skin:'#87e0b1',weapon:'slime',base:'slime'},
    slime_spitter:{name:'Acid Spitter',faction:'crypt',shirt:'#8dbe4e',skin:'#b6e07a',weapon:'acid',base:'slime',scale:1.02,hp:.8,speed:1.04,damage:.72},
    slime_brute:{name:'Bulwark Slime',faction:'crypt',shirt:'#3d8f74',skin:'#5fb892',weapon:'slime',base:'slime',scale:1.46,hp:2.15,speed:.76,damage:1.6},
    skeleton:{name:'Salt Skeleton',faction:'crypt',shirt:'#d7c89f',skin:'#ddd1af',weapon:'bones',base:'skeleton'},
    skeleton_guard:{name:'Tidewreck Guard',faction:'crypt',shirt:'#b9a877',skin:'#cfc09a',weapon:'club',base:'skeleton',scale:1.10,hp:1.55,speed:.86,damage:1.25},
    skeleton_captain:{name:'Drowned Captain',faction:'crypt',shirt:'#a3925f',skin:'#c9ba93',weapon:'bones',base:'skeleton',scale:1.22,hp:2.05,speed:.96,damage:1.5},
    goblin:{name:'Cave Goblin',faction:'crypt',shirt:'#547d42',skin:'#71964e',weapon:'club',base:'goblin'},
    goblin_slinger:{name:'Rockslinger',faction:'crypt',shirt:'#6c8a3e',skin:'#8aa85a',weapon:'thrown',base:'goblin',scale:.95,hp:.85,speed:1.12,damage:.8},
    goblin_brute:{name:'Goblin Brute',faction:'crypt',shirt:'#42633a',skin:'#5f8046',weapon:'club',base:'goblin',scale:1.30,hp:1.9,speed:.82,damage:1.5}
  };
  const CRYPT_VARIANTS={bat:['bat','bat_swift','bat_dire'],slime:['slime','slime_spitter','slime_brute'],skeleton:['skeleton','skeleton_guard','skeleton_captain'],goblin:['goblin','goblin_slinger','goblin_brute']};
  const mobBase=kind=>enemyPalette[kind]?.base||kind;
  const mobStats=kind=>{const d=enemyPalette[kind]||{};return {base:d.base||kind,scale:d.scale||1,hp:d.hp||1,speed:d.speed||1,damage:d.damage||1,weapon:d.weapon||'fists'}};
  const enemyMaterials=new Map();function emat(color){if(!enemyMaterials.has(color))enemyMaterials.set(color,new THREE.MeshStandardMaterial({color,roughness:.82}));return enemyMaterials.get(color)}
  // As with the boat crew, keep the original animated meshes as precise hit/LOS
  // targets, but submit shared geometry in a handful of colored instance draws.
  const renderRecords=new Set(),enemyBatches=new Map(),hiddenEnemyMaterials=new WeakMap(),enemyRenderFrustum=new THREE.Frustum(),enemyRenderMatrix=new THREE.Matrix4(),enemyRenderSphere=new THREE.Sphere(new THREE.Vector3(),3.2);
  function registerEnemyRendering(e){
    const parts=[];e.root.traverse(m=>{if(!m.isMesh||m.isInstancedMesh||!m.material?.isMeshStandardMaterial||m.material.transparent)return;
      const original=m.material,key=m.geometry.uuid;let bucket=enemyBatches.get(key);
      if(!bucket){const material=original.clone();material.color.set('#ffffff');const batch=new THREE.InstancedMesh(m.geometry,material,1024);batch.name='Batched articulated enemy bodies';batch.userData.noBulletHit=true;batch.userData.noLOSBlock=true;batch.frustumCulled=false;batch.castShadow=!deviceLowPower;batch.receiveShadow=true;batch.count=0;batch.visible=false;scene.add(batch);bucket={batch,parts:[],count:0};enemyBatches.set(key,bucket)}
      let hidden=hiddenEnemyMaterials.get(original);if(!hidden){hidden=original.clone();hidden.visible=false;hiddenEnemyMaterials.set(original,hidden)}m.material=hidden;parts.push({mesh:m,bucket});
    });e.renderParts=parts;renderRecords.add(e);
  }
  function updateEnemyRendering(){
    for(const b of enemyBatches.values())b.count=0;
    if(renderRecords.size){camera.updateWorldMatrix(true,false);enemyRenderMatrix.multiplyMatrices(camera.projectionMatrix,camera.matrixWorldInverse);enemyRenderFrustum.setFromProjectionMatrix(enemyRenderMatrix)}
    for(const e of renderRecords){let visible=true;for(let p=e.root;p;p=p.parent)if(!p.visible){visible=false;break}if(!visible)continue;
      e.root.getWorldPosition(enemyRenderSphere.center);enemyRenderSphere.center.y+=1.2;if(!enemyRenderFrustum.intersectsSphere(enemyRenderSphere))continue;e.root.updateWorldMatrix(true,true);
      for(const part of e.renderParts){const m=part.mesh;let shown=true;for(let p=m;p&&p!==e.root;p=p.parent)if(!p.visible){shown=false;break}if(!shown)continue;const b=part.bucket;if(b.count>=1024)continue;b.batch.setMatrixAt(b.count,m.matrixWorld);b.batch.setColorAt(b.count,m.material.color);b.count++}
    }
    for(const b of enemyBatches.values()){b.batch.count=b.count;b.batch.visible=b.count>0;if(b.count){b.batch.instanceMatrix.needsUpdate=true;if(b.batch.instanceColor)b.batch.instanceColor.needsUpdate=true}}
  }

  // Flat screen-space overlays: never ray targets, never a 3-D box in the room.
  const barLayer=document.createElement('div');barLayer.id='enemy-health-layer';barLayer.setAttribute('aria-label','Injured enemies');barLayer.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:7;overflow:hidden';document.body.append(barLayer);
  const barPoint=new THREE.Vector3(),barScale=new THREE.Vector3();
  function makeHealthBar(g,data,def){
    const element=document.createElement('div'),fill=document.createElement('div');element.className='enemy-health-bar';element.setAttribute('role','progressbar');element.setAttribute('aria-label',def.name+' health');element.style.cssText='position:absolute;display:none;width:46px;height:5px;border:1px solid #191f21;background:#20272ddd;box-shadow:0 1px 3px #0009;transform:translate(-50%,-100%);border-radius:1px';fill.style.cssText='height:100%;width:100%;background:#ed7560;transform-origin:left;';element.append(fill);barLayer.append(element);return {element,fill,sightAt:0,clear:true};
  }
  function hideHealthBar(e){if(e.bar)e.bar.element.style.display='none'}
  function removeHealthBar(e){e.bar?.element.remove();e.bar=null}
  function updateHealthBar(e,enabled=true,sight=hasDungeonLineOfSight){
    if(!e.bar)return;const {element,fill}=e.bar,d=e.data,g=e.root,ratio=THREE.MathUtils.clamp(d.hp/d.maxHp,0,1);
    if(!enabled||!d.alive||ratio>=.99999||ratio<=0||!g.visible){hideHealthBar(e);return}
    g.getWorldPosition(barPoint);g.getWorldScale(barScale);barPoint.y+=(g.userData.barHeight||2.35)*barScale.y;
    const distance=barPoint.distanceTo(camera.position);if(distance>58){hideHealthBar(e);return}
    const world=barPoint.clone();camera.updateWorldMatrix(true,false);barPoint.project(camera);
    if(barPoint.z< -1||barPoint.z>1||Math.abs(barPoint.x)>1.05||Math.abs(barPoint.y)>1.05){hideHealthBar(e);return}
    if(portalPulse>=e.bar.sightAt){e.bar.sightAt=portalPulse+.15;e.bar.clear=sight(camera.position,world,null,g)}
    if(!e.bar.clear){hideHealthBar(e);return}
    const bounds=document.querySelector('#world')?.getBoundingClientRect(),width=bounds?.width||innerWidth,height=bounds?.height||innerHeight;
    element.style.display='block';element.style.left=((bounds?.left||0)+(barPoint.x*.5+.5)*width)+'px';element.style.top=((bounds?.top||0)+(-barPoint.y*.5+.5)*height)+'px';fill.style.transform='scaleX('+ratio+')';element.setAttribute('aria-valuemin','0');element.setAttribute('aria-valuemax',String(d.maxHp));element.setAttribute('aria-valuenow',String(Math.ceil(d.hp)));
  }
  function buildCrewFisher(g,data,def){
    const model=new THREE.Group();model.name='Boat-style articulated fisherman';model.scale.setScalar(1.08);g.add(model);g.userData.crewRig=model;g.userData.limbPivots=[];
    const shirt=emat(def.shirt),skin=emat(def.skin),trousers=emat('#263f46'),boots=emat('#252d2c'),vest=emat(data.kind==='fisher_veteran'?'#c49b4e':data.kind==='fisher_club'?'#c17043':'#df9b45'),trim=emat('#e3c67b'),metal=emat('#263338');
    g.userData.torso=mesh(model,shared.cylinderGeo,shirt,[0,1.22,0],[.49,.56,.39]);
    mesh(model,shared.boxGeo,vest,[-.15,1.25,.035],[.23,.46,.37]);mesh(model,shared.boxGeo,vest,[.15,1.25,.035],[.23,.46,.37]);mesh(model,shared.boxGeo,trim,[0,1.29,.232],[.045,.38,.025]);
    for(const side of [-1,1]){mesh(model,shared.boxGeo,trim,[side*.15,1.29,.235],[.21,.055,.025]);mesh(model,shared.boxGeo,boots,[side*.15,1.10,.235],[.16,.035,.025])}
    mesh(model,shared.cylinderGeo,skin,[0,1.52,0],[.25,.16,.25]);const head=new THREE.Group();head.name='deckhandHead';head.position.set(0,1.71,.015);model.add(head);g.userData.head=head;
    mesh(head,shared.smoothGeo,skin,[0,0,0],[.205,.22,.205]);mesh(head,shared.cylinderGeo,emat('#d25c40'),[0,.15,0],[.47,.085,.47]);mesh(head,shared.coneGeo,emat('#d25c40'),[0,.22,-.025],[.40,.17,.36]);mesh(head,shared.boxGeo,emat('#d25c40'),[0,.145,.16],[.38,.045,.23]);
    for(const side of [-1,1]){mesh(head,shared.smoothGeo,skin,[side*.20,-.005,0],[.055,.075,.05]);mesh(head,shared.boxGeo,boots,[side*.075,.015,.196],[.043,.04,.018])}
    mesh(head,shared.smoothGeo,skin,[0,-.025,.205],[.055,.065,.07]);
    for(const side of [-1,1])for(const role of ['arm','leg']){
      const arm=role==='arm',pivot=new THREE.Group();pivot.name='deckhand-'+role+'-'+side;pivot.position.set(side*(arm?.29:.135),arm?1.43:.91,0);model.add(pivot);
      const upper=arm?.36:.44,lower=arm?.33:.36,r=arm?.095:.12;
      mesh(pivot,shared.cylinderGeo,arm?shirt:trousers,[0,-upper/2,0],[r*1.75,upper,r*1.9]);
      const elbow=new THREE.Group();elbow.name='deckhand-elbow-'+role+'-'+side;elbow.position.y=-upper;pivot.add(elbow);
      mesh(elbow,shared.smoothGeo,arm?trim:trousers,[0,0,0],[r,r,r]);mesh(elbow,shared.cylinderGeo,arm?shirt:trousers,[0,-lower/2,0],[r*1.5,lower,r*1.65]);
      if(arm)mesh(elbow,shared.smoothGeo,skin,[0,-lower,0],[.095,.10,.10]);else mesh(elbow,shared.boxGeo,boots,[0,-lower-.045,.065],[.235,.13,.34]);
      g.userData.limbPivots.push({pivot,elbow,role,side});if(arm&&side===1)g.userData.arm=pivot;
      if(arm&&side===1&&def.weapon==='club'){const club=new THREE.Group();club.position.set(.05,-lower,.08);elbow.add(club);mesh(club,shared.cylinderGeo,emat('#674831'),[0,.25,0],[.095,.75,.095]);mesh(club,shared.sphereGeo,emat('#88765a'),[0,.58,0],[.16,.20,.16]);g.userData.club=club}
    }
    if(def.weapon==='gun'){
      const gun=new THREE.Group();gun.name='crew-rifle';gun.position.set(.15,1.10,.30);model.add(gun);mesh(gun,shared.boxGeo,metal,[0,0,.18],[.10,.13,.58]);mesh(gun,shared.cylinderGeo,metal,[0,0,.64],[.055,.43,.055],[Math.PI/2,0,0]);mesh(gun,shared.boxGeo,emat('#725239'),[0,-.02,-.15],[.11,.14,.21]);mesh(gun,shared.boxGeo,metal,[0,-.12,.14],[.08,.18,.10]);
      const muzzle=new THREE.Object3D();muzzle.name='Fisher rifle muzzle';muzzle.position.z=.87;gun.add(muzzle);g.userData.muzzle=muzzle;g.userData.gun=gun;
      const flash=new THREE.Mesh(shared.sphereGeo,new THREE.MeshBasicMaterial({color:'#ffdb83',transparent:true,opacity:.85}));flash.scale.set(.10,.10,.16);flash.position.z=.89;flash.visible=false;flash.userData.noBulletHit=true;flash.userData.noLOSBlock=true;gun.add(flash);g.userData.flash=flash;g.userData.ownedFlashMaterial=flash.material;
    }
    if(data.kind==='fisher_veteran'){mesh(model,shared.boxGeo,metal,[0,1.29,.26],[.36,.20,.055]);for(const side of [-1,1])mesh(model,shared.boxGeo,trim,[side*.29,1.48,0],[.17,.075,.24])}
    g.userData.barHeight=2.22;g.userData.modelStyle='boat-crew';
  }

  function spawnEnemy(data,n,options=null){
    const def=enemyPalette[data.kind],stats=mobStats(data.kind),base=stats.base,g=new THREE.Group();g.position.set(data.x,options?getGround(data.x,data.z):roomHeightAt(data.x,data.z),data.z);g.userData={enemyData:data,limbPivots:[],animPhase:data.attackPhase||0};(options?.parent||floorRoot).add(g);g.name=def.name;
    const shirt=emat(def.shirt),skin=emat(def.skin),dark=emat('#27252b'),leather=emat('#4c3527'),metal=emat('#85807b');
    const limb=(pos,geo,material,center,size,rot,role,side)=>{const pivot=new THREE.Group();pivot.position.set(...pos);g.add(pivot);mesh(pivot,geo,material,center,size,rot);g.userData.limbPivots.push({pivot,role,side});return pivot};
    let barRoot=null;
    if(def.faction==='fisher'){buildCrewFisher(g,data,def)}else if(base==='goblin'){
      g.userData.torso=mesh(g,shared.boxGeo,shirt,[0,1.18,0],[.72,.92,.42]);g.userData.head=mesh(g,shared.smoothGeo,skin,[0,1.91,0],[.36,.41,.34]);
      mesh(g,shared.boxGeo,dark,[0,2.23,0],[.66,.15,.58]);mesh(g,shared.boxGeo,shirt,[0,2.34,0],[.76,.13,.62]);
      for(const s of [-1,1])mesh(g,shared.coneGeo,skin,[s*.42,1.98,0],[.18,.44,.16],[0,0,s*-.65]);
      mesh(g,shared.boxGeo,leather,[0,.56,0],[.52,.18,.4]);
      // Breed markers: slingers carry a rock, brutes wear slab shoulders.
      if(data.kind==='goblin_slinger')mesh(g,shared.smoothGeo,emat('#8b8579'),[.52,1.02,-.22],[.16,.15,.16]);
      if(data.kind==='goblin_brute')for(const s of [-1,1])mesh(g,shared.boxGeo,emat('#7b6a4a'),[s*.46,1.62,0],[.34,.2,.42],[0,0,s*.18]);
      for(const s of [-1,1]){
        limb([s*.23,1.58,0],shared.boxGeo,shirt,[0,-.25,0],[.25,.66,.3],[0,0,s*.06],'arm',s);
        const forearm=limb([s*.51,1.29,0],shared.boxGeo,skin,[0,-.2,0],[.2,.55,.22],[0,0,s*.15],'arm',s);
        if(def.weapon==='gun'&&s===1){mesh(forearm,shared.boxGeo,metal,[.08,-.15,-.18],[.16,.18,.7]);mesh(forearm,shared.boxGeo,dark,[.08,-.17,-.58],[.1,.1,.5]);}
        if(def.weapon==='club'&&s===1){mesh(forearm,shared.cylinderGeo,leather,[.1,-.12,-.12],[.13,.95,.13],[.2,0,-.16]);mesh(forearm,shared.sphereGeo,emat('#76604a'),[.13,.34,-.13],[.2,.25,.2]);}
        if(def.weapon==='fists')mesh(forearm,shared.smoothGeo,skin,[.07,-.31,-.04],[.18,.17,.2]);
        limb([s*.17,.64,0],shared.boxGeo,dark,[0,-.24,0],[.26,.55,.31],null,'leg',s);
      }
      if(data.kind==='fisher_veteran')mesh(g,shared.boxGeo,emat('#c39a4f'),[0,1.53,.22],[.55,.2,.05]);
    }else if(base==='skeleton'){
      if(data.kind==='skeleton_guard'){const shield=mesh(g,shared.boxGeo,emat('#6b6450'),[.34,1.18,.16],[.52,.62,.09]);mesh(shield,shared.boxGeo,metal,[0,0,.06],[.16,.16,.04]);mesh(g,shared.boxGeo,metal,[0,2.06,0],[.38,.18,.34])}
      if(data.kind==='skeleton_captain'){mesh(g,shared.boxGeo,emat('#2d3a44'),[0,1.24,.02],[.52,.62,.32]);mesh(g,shared.boxGeo,emat('#8a6f3a'),[0,2.09,0],[.46,.1,.42]);mesh(g,shared.boxGeo,emat('#8a6f3a'),[0,2.16,0],[.2,.12,.2])}
      g.userData.head=mesh(g,shared.smoothGeo,skin,[0,2.02,0],[.33,.38,.3]);
      for(const s of [-1,1]){mesh(g,shared.smoothGeo,dark,[s*.13,2.07,.26],[.07,.1,.035]);limb([s*.18,.62,0],shared.boxGeo,skin,[0,-.22,0],[.15,.56,.14],null,'leg',s);const arm=limb([s*.2,1.5,0],shared.boxGeo,skin,[s*.08,-.27,0],[.13,.68,.12],[0,0,s*.12],'arm',s);if(s===1)mesh(arm,shared.cylinderGeo,leather,[.24,-.03,-.08],[.12,1.4,.12],[0,0,-.2]);}
      g.userData.torso=mesh(g,shared.boxGeo,skin,[0,1.24,0],[.46,.58,.28]);for(let i=0;i<4;i++)mesh(g,shared.boxGeo,dark,[0,1.02+i*.14,.15],[.52,.045,.05]);
    }else if(base==='slime'){
      const slimeMat=emat(def.skin||'#6ad49b');slimeMat.transparent=true;slimeMat.opacity=.88;slimeMat.roughness=.32;
      g.userData.slimeBody=mesh(g,shared.smoothGeo,slimeMat,[0,.62,0],[.78,.62,.72]);g.userData.slimeBodyBaseY=.62;
      for(const s of [-1,1])mesh(g,shared.smoothGeo,emat('#17352d'),[s*.22,.77,.58],[.075,.09,.045]);
      mesh(g,shared.boxGeo,emat('#21463b'),[0,.47,.64],[.2,.04,.04]);
      // Blob arms hang off real pivots so a slime can rear up and slam the ground.
      g.userData.slimeArms=[];
      for(const s of [-1,1]){
        const pivot=new THREE.Group();pivot.name='slime-arm-'+s;pivot.position.set(s*.40,.86,0);pivot.rotation.z=s*.30;g.add(pivot);
        mesh(pivot,shared.smoothGeo,slimeMat,[0,-.18,.04],[.19,.27,.20]);
        g.userData.slimeArms.push({pivot,side:s});
      }
      if(data.kind==='slime_spitter'){const sac=mesh(g,shared.smoothGeo,emat('#d7e36a'),[0,.94,-.50],[.30,.34,.26]);sac.name='acid-sac';mesh(g,shared.cylinderGeo,emat('#9fd155'),[0,.80,-.38],[.06,.3,.06],[.5,0,0])}
      if(data.kind==='slime_brute')for(const s of [-1,1])for(let i=0;i<2;i++)mesh(g,shared.coneGeo,emat('#21463b'),[s*(.34+i*.13),.88-i*.17,-.14],[.12,.3,.12],[0,0,s*.35]);
    }else if(base==='bat'){
      // The whole body lives in a rig so a dive can pitch it without moving the root.
      const rig=new THREE.Group();rig.name='bat-rig';rig.position.set(0,1.8,0);g.add(rig);g.userData.batRig=rig;
      mesh(rig,shared.smoothGeo,shirt,[0,0,0],[.45,.35,.52]);mesh(rig,shared.smoothGeo,skin,[0,.28,.12],[.27,.24,.28]);
      g.userData.wings=[];for(const s of [-1,1]){const wing=mesh(rig,shared.boxGeo,emat('#32283d'),[s*.64,.06,0],[.98,.12,.64],[0,0,s*.16]);g.userData.wings.push({mesh:wing,side:s});mesh(rig,shared.coneGeo,skin,[s*.15,.52,.1],[.09,.26,.1],[0,0,s*-.25])}
      g.userData.batClaws=[];for(const s of [-1,1]){const claw=mesh(rig,shared.coneGeo,emat('#d9cfc0'),[s*.16,-.20,.32],[.07,.28,.07],[Math.PI/2,0,0]);g.userData.batClaws.push(claw)}
      if(data.kind==='bat_dire'){for(const s of [-1,1])mesh(rig,shared.smoothGeo,emat('#c8433f'),[s*.10,.31,.25],[.075,.055,.03]);mesh(rig,shared.coneGeo,emat('#7a3a49'),[0,.06,-.42],[.13,.34,.13],[Math.PI/2,0,0])}
      if(data.kind==='bat_swift')mesh(rig,shared.coneGeo,emat('#8fa2c4'),[0,.16,-.36],[.12,.4,.12],[Math.PI/2,0,0]);
    }
    if(g.userData.torso)g.userData.torsoBaseY=g.userData.torso.position.y;
    if(stats.scale!==1)g.scale.setScalar(stats.scale);
    g.userData.kind=data.kind;g.userData.baseKind=base;g.userData.animPhase=data.attackPhase||0;
    if(!g.userData.barHeight)g.userData.barHeight=(base==='slime'?1.45:base==='bat'?2.65:base==='goblin'?2.60:2.45)*stats.scale;
    g.userData.eyeHeight=(base==='bat'?2:base==='slime'?.85:1.8)*stats.scale;
    const enemy={root:g,data,def,level:n,surface:!!options,attackTimer:data.cooldown||.3,meleeTimer:.2,sightTimer:0,playerVisible:false,moveSpeed:((base==='bat'?3.1:2.05)*stats.speed)+Math.min(n*.014,.8),radius:(base==='slime'?.72:.52)*stats.scale,home:{x:data.x,z:data.z},patrolAt:0};enemy.bar=makeHealthBar(g,data,def);registerEnemyRendering(enemy);
    if(!options){runtimeEnemies.push(enemy);targetMap.set(g,data);g.traverse(child=>{if(child.isMesh)targetMap.set(child,data)})}return enemy;
  }

  function spawnChest(data){
    const g=new THREE.Group();g.position.set(data.x,roomHeightAt(data.x,data.z),data.z);floorRoot.add(g);const colors=['#86765e','#9c7044','#66818a','#aa843d','#8c58a1'],m=emat(colors[data.quality]);
    box(g,[0,.48,0],[1.55,.92,1.1],m);box(g,[0,.98,0],[1.62,.18,1.18],shared.metal);const lid=new THREE.Group();lid.position.set(0,1.03,.49);g.add(lid);mesh(lid,shared.boxGeo,m,[0,.16,-.49],[1.62,.38,1.18]);mesh(g,shared.boxGeo,shared.flame,[0,.67,.58],[.2,.28,.06]);
    const glow=new THREE.PointLight(colors[data.quality],.75,5,2);glow.position.set(0,1.4,0);g.add(glow);const parent=floorRoot;ensureAsset('dungeonChest').then(result=>{if(!result||g.parent!==parent||g.userData.externalChest)return;const model=cloneAsset('dungeonChest',1.25);if(!model)return;for(const child of g.children)if(child.isMesh||child===lid)child.visible=false;model.name='Kenney CC0 dungeon chest';model.rotation.y=Math.PI;g.add(model);g.userData.externalChest=model});
    runtimeChests.push({root:g,data,lid,glow});obstacles.push({x:data.x,z:data.z,r:1.0});
  }
  function buildStairPrompt(){return active&&floorNumber>1?'ASCEND':'DESCEND'}
  function restoreFloor(n,spawn=true){
    clearFloor();floorNumber=n;let data=floorCache.get(n);if(!data){data=randomFloorData(n);floorCache.set(n,data)}
    const torches=buildRoom(data);floorRoot.userData.torches=torches;root.visible=true;
    floorText.textContent=`FLOOR ${n.toLocaleString()} · ${data.theme.name}`;
    if(spawn){camera.position.set(-18,floorY+roomHeightAt(-18,0)+1.66,0);moveVel.set(0,0,0);jumpVelocity=0;jumpOffset=0}
    if(n>save.bestDungeonFloor){save.bestDungeonFloor=n;persist();refreshHud()}
    enemyText.textContent=`${runtimeEnemies.length} HOSTILES`;setDungeonUI(true);updateInteraction(camera.position);
  }
  function setDungeonUI(on){active=on;root.visible=on;document.body.classList.toggle('in-dungeon',on);if(hud)hud.classList.toggle('active',on);if(!on){prompt?.classList.remove('on');actionButton?.classList.remove('available');ropeButton?.classList.remove('available')}}
  function enter(){
    returnView=getView();health=100;setPlayerHealth(health);floorNumber=1;scene.background=new THREE.Color('#10151a');scene.fog=new THREE.FogExp2('#14151b',.008);setDungeonUI(true);restoreFloor(1,true);sfx('dungeon');notify('THE SINKING STAIRS · FIGHT OR RETREAT · E TO INTERACT');
  }
  function exit(reason='RETURNED TO THE ISLAND'){
    if(!active)return;jumpVelocity=0;jumpOffset=0;setDungeonUI(false);clearFloor();scene.background=envOriginal.background?.clone?.()||envOriginal.background;scene.fog=envOriginal.fog?.clone?.()||envOriginal.fog;
    const pos=returnView?.position||new THREE.Vector3(ENTRANCE_X,getGround(ENTRANCE_X,ENTRANCE_Z+3)+1.66,ENTRANCE_Z+3);setView(pos,returnView?.yaw??0,returnView?.pitch??-.1);returnView=null;persist();refreshHud();if(reason)notify(reason);updateInteraction(camera.position);
  }
  function changeFloor(n){if(n<1)return;sfx('stairs');restoreFloor(n,true)}
  function updateInteraction(pos){
    if(!prompt)return;
    let label='',nearest=null,min=Infinity;
    if(!active){const d=Math.hypot(pos.x-ENTRANCE_X,pos.z-ENTRANCE_Z);if(d<ENTRY_RANGE)label='E · ENTER THE SINKING STAIRS'}
    else{
      const candidates=[];
      if(floorNumber===1)candidates.push({kind:'exit',x:-24,z:0,label:'E · RETURN TO THE ISLAND'});else candidates.push({kind:'up',x:-18,z:-22,label:`E · ASCEND TO FLOOR ${floorNumber-1}`});
      candidates.push({kind:'down',x:16,z:20,label:`E · DESCEND TO FLOOR ${floorNumber+1}`});
      for(const c of runtimeChests)if(!c.data.opened)candidates.push({kind:'chest',x:c.data.x,z:c.data.z,label:`E · OPEN ${['WEATHERED','BRONZE','SILVER','GILDED','ABYSSAL'][c.data.quality]} CHEST`,chest:c});
      for(const a of candidates){const d=Math.hypot(pos.x-a.x,pos.z-a.z);if(d<min){min=d;nearest=a}}
      if(nearest&&min<3.15)label=nearest.label;
    }
    actionLabel=label;prompt.textContent=label;prompt.classList.toggle('on',!!label);
    if(actionButton){actionButton.textContent=nearest?.kind==='chest'?'OPEN':nearest?.kind==='exit'?'EXIT':nearest?.kind==='up'?'UP':nearest?.kind==='down'?'DOWN':'ENTER';actionButton.classList.toggle('available',!!label)}
    if(ropeButton){ropeButton.textContent=`ROPE ${save.escapeRopes||0}`;ropeButton.classList.toggle('available',active&&(save.escapeRopes||0)>0)}
    if(active){const alive=runtimeEnemies.filter(e=>e.data.alive).length;enemyText.textContent=`${alive} HOSTILE${alive===1?'':'S'}`;floorText.textContent=`FLOOR ${floorNumber.toLocaleString()} · ${currentTheme.name}`}
  }
  function interact(){
    if(!active){if(Math.hypot(camera.position.x-ENTRANCE_X,camera.position.z-ENTRANCE_Z)<ENTRY_RANGE)enter();return}
    const candidates=[];if(floorNumber===1)candidates.push({kind:'exit',x:-24,z:0});else candidates.push({kind:'up',x:-18,z:-22});candidates.push({kind:'down',x:16,z:20});for(const c of runtimeChests)if(!c.data.opened)candidates.push({kind:'chest',x:c.data.x,z:c.data.z,chest:c});
    let nearest=null,min=Infinity;for(const a of candidates){const d=Math.hypot(camera.position.x-a.x,camera.position.z-a.z);if(d<min){min=d;nearest=a}}
    if(!nearest||min>3.15)return;
    if(nearest.kind==='exit'){exit('YOU RETREATED FROM THE DUNGEON');return}
    if(nearest.kind==='up'){changeFloor(floorNumber-1);return}
    if(nearest.kind==='down'){changeFloor(floorNumber+1);return}
    if(nearest.kind==='chest')openChest(nearest.chest);
  }
  function openChest(chest){
    const d=chest.data;d.opened=true;chest.lid.rotation.x=-1.12;chest.glow.intensity=0;const q=d.quality,n=d.qty,depth=d.floor||floorNumber;let result='',cashBase=Math.min(1e9,Math.round(220+depth*105+Math.pow(depth,1.22)*7)),cash=0;
    if(d.lootType==='cash'){cash=cashBase*n*(1+q*.42);save.cash+=cash;result=`${cashFmt(cash)} island cash`}
    else if(d.lootType==='rope'){const amount=n+Math.floor(q/2);save.escapeRopes=(save.escapeRopes||0)+amount;result=`${amount} escape rope${amount===1?'':'s'}`}
    else if(d.lootType==='crate'){save.crates=(save.crates||0)+n;result=`${n} drift crate${n===1?'':'s'}`}
    else if(d.lootType==='charm'){save.luckCharm=(save.luckCharm||0)+n;result=`${n} abyssal luck charm${n===1?'':'s'}`}
    else if(d.lootType==='weapon'){
      const available=getWeapons().filter(w=>!save.weapons.includes(w.id));if(available.length){const weapon=available[Math.floor(Math.random()*available.length)];save.weapons.push(weapon.id);result=`${weapon.name} blueprint`}
      else{cash=cashBase*n*2;save.cash+=cash;result=`duplicate blueprints · ${cashFmt(cash)}`}
    }else{health=Math.min(100,health+18*n);setPlayerHealth(health);cash=Math.floor(cashBase*n*.35);save.cash+=cash;result=`healing tonic · ${cashFmt(cash)}`}
    const xp=30+depth*7+n*15+q*28;awardXP(xp);persist();refreshHud();sfx('chest');notify(`${['WEATHERED','BRONZE','SILVER','GILDED','ABYSSAL'][q]} CACHE ×${n} · ${result.toUpperCase()} · +${xp} XP`);updateInteraction(camera.position);
  }
  function useRope(){if(!active)return false;if((save.escapeRopes||0)<=0){notify('NO ESCAPE ROPE · BUY ONE IN THE SHOP');return false}save.escapeRopes--;persist();refreshHud();sfx('rope');exit('ESCAPE ROPE! YOU SURFACED SAFELY');return true}
  function resolveRoom(x,z,fromX=x,fromZ=z){
    x=THREE.MathUtils.clamp(x,-HALF,HALF);z=THREE.MathUtils.clamp(z,-HALF,HALF);
    for(const wall of wallSegments){const pad=.84;if(wall.axis==='x'&&z>wall.min-pad&&z<wall.max+pad){const crossed=(fromX<=wall.coord&&x>wall.coord-pad)||(fromX>=wall.coord&&x<wall.coord+pad);if(crossed)x=fromX<=wall.coord?wall.coord-pad:wall.coord+pad}else if(wall.axis==='z'&&x>wall.min-pad&&x<wall.max+pad){const crossed=(fromZ<=wall.coord&&z>wall.coord-pad)||(fromZ>=wall.coord&&z<wall.coord+pad);if(crossed)z=fromZ<=wall.coord?wall.coord-pad:wall.coord+pad}}
    for(const o of obstacles){const dx=x-o.x,dz=z-o.z,d=Math.hypot(dx,dz),min=o.r+.48;if(d<min){const safe=Math.max(.001,d),push=(min-d)/safe;x+=dx*push;z+=dz*push}}
    x=THREE.MathUtils.clamp(x,-HALF,HALF);z=THREE.MathUtils.clamp(z,-HALF,HALF);return {x,z};
  }
  let dungeonStepDistance=0;
  function move(wish,dt,keys,jumpRequest=false){
    if(isPlayerDead())return;
    const oldX=camera.position.x,oldZ=camera.position.z;
    const speed=(keys.has('ShiftLeft')||keys.has('ShiftRight'))?7.1:5.1;
    if(wish.lengthSq()>0){const target=wish.clone().multiplyScalar(speed),blend=Math.min(1,dt*10);moveVel.lerp(target,blend)}else moveVel.multiplyScalar(Math.exp(-dt*8));
    if(jumpRequest&&jumpOffset<=.015){jumpVelocity=6.4}
    const p=resolveRoom(camera.position.x+moveVel.x*dt,camera.position.z+moveVel.z*dt,camera.position.x,camera.position.z);if(jumpVelocity!==0||jumpOffset>0){jumpVelocity-=18*dt;jumpOffset=Math.max(0,jumpOffset+jumpVelocity*dt);if(jumpOffset===0)jumpVelocity=0}camera.position.set(p.x,floorY+roomHeightAt(p.x,p.z)+1.66+jumpOffset,p.z);
    if(jumpOffset<.02&&Math.hypot(moveVel.x,moveVel.z)>.7){dungeonStepDistance+=Math.hypot(p.x-oldX,p.z-oldZ);if(dungeonStepDistance>.95){dungeonStepDistance=0;sfx('step-stone',{volume:.32,key:'player-step',cooldown:130})}}else dungeonStepDistance=0;
  }
  function enemyMuzzle(e){if(e.root.userData.muzzle)return e.root.userData.muzzle.getWorldPosition(new THREE.Vector3());const p=new THREE.Vector3(.3,1.1,.55);e.root.localToWorld(p);return p}
  function isInsideObject(object,root){for(let p=object;p;p=p.parent)if(p===root)return true;return false}
  // Authoritative structural occlusion does not depend on render visibility,
  // material transparency, stale instanced transforms or which face a ray hits.
  function segmentRect(a,b,minX,maxX,minZ,maxZ){
    let lo=0,hi=1;for(const [start,delta,min,max] of [[a.x,b.x-a.x,minX,maxX],[a.z,b.z-a.z,minZ,maxZ]]){
      if(Math.abs(delta)<1e-9){if(start<min||start>max)return null;continue}
      let p=(min-start)/delta,q=(max-start)/delta;if(p>q)[p,q]=[q,p];lo=Math.max(lo,p);hi=Math.min(hi,q);if(lo>hi)return null;
    }return [lo,hi];
  }
  function wallRect(w,pad=.36){return w.axis==='x'?[w.coord-pad,w.coord+pad,w.min-pad,w.max+pad]:[w.min-pad,w.max+pad,w.coord-pad,w.coord+pad]}
  function structuralSightClear(from,to){
    if(!floorRoot)return false;const a=floorRoot.worldToLocal(from.clone()),b=floorRoot.worldToLocal(to.clone());
    for(const wall of wallSegments){const interval=segmentRect(a,b,...wallRect(wall));if(!interval)continue;
      const y0=a.y+(b.y-a.y)*interval[0],y1=a.y+(b.y-a.y)*interval[1];if(Math.max(y0,y1)>=0&&Math.min(y0,y1)<=6.5)return false;
    }return true;
  }
  function hasDungeonLineOfSight(from,to,attackerRoot=null,targetRoot=null){
    if(!floorRoot||!structuralSightClear(from,to))return false;
    const delta=to.clone().sub(from),distance=delta.length();if(distance<.08)return true;
    enemySightRaycaster.set(from,delta.multiplyScalar(1/distance));enemySightRaycaster.near=.025;enemySightRaycaster.far=Math.max(.025,distance-.045);
    enemySightHits.length=0;enemySightRaycaster.intersectObjects(sightMeshes,false,enemySightHits);
    for(const hit of enemySightHits){const object=hit.object;if(object.userData.noLOSBlock||attackerRoot&&isInsideObject(object,attackerRoot)||targetRoot&&isInsideObject(object,targetRoot))continue;
      const materials=Array.isArray(object.material)?object.material:[object.material];if(materials.every(m=>m?.transparent&&(m.opacity??1)<.35))continue;return false;
    }return true;
  }
  const NAV_MIN=-24,NAV_SIZE=49,NAV_COUNT=NAV_SIZE*NAV_SIZE;
  let navGrid=null;const sightMeshes=[];
  function walkPointClear(x,z,radius=.72){
    if(Math.abs(x)>HALF-radius||Math.abs(z)>HALF-radius)return false;
    // NPCs do not stand in the lower-floor stair shaft.
    if(x>13.1-radius&&x<18.9+radius&&z>9.2-radius&&z<21+radius)return false;
    for(const wall of wallSegments){const [a,b,c,d]=wallRect(wall,.36+radius);if(x>a&&x<b&&z>c&&z<d)return false}
    return !obstacles.some(o=>Math.hypot(x-o.x,z-o.z)<o.r+radius);
  }
  function walkSegmentClear(a,b,radius=.72){
    if(!walkPointClear(b.x,b.z,radius))return false;
    for(const wall of wallSegments)if(segmentRect(a,b,...wallRect(wall,.36+radius)))return false;
    const dx=b.x-a.x,dz=b.z-a.z,len=dx*dx+dz*dz;
    for(const o of obstacles){const t=len?THREE.MathUtils.clamp(((o.x-a.x)*dx+(o.z-a.z)*dz)/len,0,1):0;if(Math.hypot(a.x+dx*t-o.x,a.z+dz*t-o.z)<o.r+radius)return false}
    // Test the shaft interior as well as the destination.
    if(segmentRect(a,b,13.1-radius,18.9+radius,9.2-radius,21+radius))return false;return true;
  }
  function prepareFloorNavigation(){
    navGrid=new Uint8Array(NAV_COUNT);for(let z=0;z<NAV_SIZE;z++)for(let x=0;x<NAV_SIZE;x++)navGrid[z*NAV_SIZE+x]=walkPointClear(NAV_MIN+x,NAV_MIN+z)?1:0;
    sightMeshes.length=0;floorRoot.updateWorldMatrix(true,true);
    // Static floor, walls and solid props only: not health bars, other NPCs or light effects.
    for(const object of floorRoot.children)if(object.isMesh&&!object.userData.noLOSBlock){const m=object.material;if(!m?.transparent||m.opacity>=.35)sightMeshes.push(object)}
  }
  function nearestNavNode(p){
    const cx=Math.round(p.x-NAV_MIN),cz=Math.round(p.z-NAV_MIN);let best=-1,score=Infinity;
    for(let radius=0;radius<=5;radius++){for(let z=Math.max(0,cz-radius);z<=Math.min(NAV_SIZE-1,cz+radius);z++)for(let x=Math.max(0,cx-radius);x<=Math.min(NAV_SIZE-1,cx+radius);x++){
      const id=z*NAV_SIZE+x;if(!navGrid[id])continue;const d=(NAV_MIN+x-p.x)**2+(NAV_MIN+z-p.z)**2;if(d<score){score=d;best=id}
    }if(best>=0)break}return best;
  }
  function routeBetween(from,to){
    if(!navGrid)return [];if(walkSegmentClear(from,to))return [{x:to.x,z:to.z}];
    const start=nearestNavNode(from),goal=nearestNavNode(to);if(start<0||goal<0)return [];
    const cost=new Float32Array(NAV_COUNT).fill(Infinity),parent=new Int32Array(NAV_COUNT).fill(-1),closed=new Uint8Array(NAV_COUNT),heap=[];
    const point=id=>({x:NAV_MIN+id%NAV_SIZE,z:NAV_MIN+Math.floor(id/NAV_SIZE)}),g=point(goal);
    const push=(id,f)=>{let i=heap.length;heap.push({id,f});while(i){const p=(i-1)>>1;if(heap[p].f<=f)break;heap[i]=heap[p];i=p}heap[i]={id,f}};
    const pop=()=>{const first=heap[0],last=heap.pop();if(heap.length){let i=0;while(i*2+1<heap.length){let c=i*2+1;if(c+1<heap.length&&heap[c+1].f<heap[c].f)c++;if(heap[c].f>=last.f)break;heap[i]=heap[c];i=c}heap[i]=last}return first.id};
    cost[start]=0;push(start,0);let visits=0;
    while(heap.length&&visits++<NAV_COUNT*3){const current=pop();if(closed[current])continue;if(current===goal){const path=[];for(let id=goal;id!==start&&id>=0;id=parent[id])path.push(point(id));path.reverse();if(walkSegmentClear(point(goal),to))path.push({x:to.x,z:to.z});return path}closed[current]=1;const p=point(current),x=current%NAV_SIZE,z=Math.floor(current/NAV_SIZE);
      for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const nx=x+dx,nz=z+dz;if(nx<0||nz<0||nx>=NAV_SIZE||nz>=NAV_SIZE)continue;const id=nz*NAV_SIZE+nx;if(!navGrid[id]||closed[id])continue;const q=point(id);if(!walkSegmentClear(p,q))continue;const next=cost[current]+(dx&&dz?Math.SQRT2:1);if(next>=cost[id])continue;cost[id]=next;parent[id]=current;push(id,next+Math.hypot(q.x-g.x,q.z-g.z))}
    }return [];
  }
  function moveEnemyTo(e,goal,dt,pace){
    const p=e.root.position,r=Math.min(.72,e.radius||.6);let next=goal;
    if(!walkSegmentClear(p,goal,r)){
      if(!e.navGoal||Math.hypot(e.navGoal.x-goal.x,e.navGoal.z-goal.z)>2||dungeonAudioTime>=(e.navAt||0)){
        e.navPath=routeBetween(p,goal);e.navGoal={x:goal.x,z:goal.z};e.navAt=dungeonAudioTime+.9+(e.root.id%7)*.045;
      }
      const path=e.navPath||[];while(path.length&&Math.hypot(path[0].x-p.x,path[0].z-p.z)<.24)path.shift();
      if(!path.length)return false;
      // Smooth only when the whole swept segment clears walls and props.
      let far=0;for(let i=1;i<Math.min(8,path.length);i++){if(!walkSegmentClear(p,path[i],r))break;far=i}if(far)path.splice(0,far);next=path[0];
    }else e.navPath=null;
    const dx=next.x-p.x,dz=next.z-p.z,d=Math.hypot(dx,dz);if(d<.035)return false;const step=Math.min(d,pace*dt),np={x:p.x+dx/d*step,z:p.z+dz/d*step};
    if(!walkSegmentClear(p,np,r)){e.navAt=0;return false}p.x=np.x;p.z=np.z;e.root.rotation.y=Math.atan2(dx,dz);return true;
  }
  function enemyEye(e){return e.root.localToWorld(new THREE.Vector3(0,e.data.kind==='slime'?.85:e.data.kind==='bat'?2:1.8,0))}
  function targetFor(e,playerPos){
    const from=enemyEye(e),localPlayer=floorRoot.worldToLocal(playerPos.clone()),local=e.root.position;
    if(dungeonAudioTime>=(e.senseAt||0)){
      e.senseAt=dungeonAudioTime+.18;const candidates=[];
      const pd=Math.hypot(localPlayer.x-local.x,localPlayer.z-local.z);if(pd<(e.data.aggro?25:20))candidates.push({type:'player',world:playerPos.clone(),enemy:null,dist:pd});
      for(const other of runtimeEnemies){if(other===e||!other.data.alive||other.def.faction===e.def.faction)continue;const dist=Math.hypot(other.root.position.x-local.x,other.root.position.z-local.z);if(dist<21)candidates.push({type:'enemy',world:enemyEye(other),enemy:other,dist})}
      candidates.sort((a,b)=>a.dist-b.dist);e.seenTarget=null;
      for(const target of candidates)if(hasDungeonLineOfSight(from,target.world,e.root,target.enemy?.root)){e.seenTarget=target;break}
    }
    const seen=e.seenTarget;
    if(seen&&(!seen.enemy||seen.enemy.data.alive)){
      const world=seen.type==='player'?playerPos.clone():enemyEye(seen.enemy);
      if(structuralSightClear(from,world)){
        const pos=floorRoot.worldToLocal(world.clone());e.lastSeen={x:pos.x,z:pos.z};e.memoryUntil=dungeonAudioTime+12;e.playerVisible=seen.type==='player';
        return {...seen,pos,world,visible:true,dist:Math.hypot(pos.x-local.x,pos.z-local.z)};
      }e.senseAt=0;e.seenTarget=null;
    }
    e.playerVisible=false;
    if(e.lastSeen&&dungeonAudioTime<e.memoryUntil&&Math.hypot(e.lastSeen.x-local.x,e.lastSeen.z-local.z)>.45)return {type:'memory',pos:e.lastSeen,visible:false,enemy:null,dist:Math.hypot(e.lastSeen.x-local.x,e.lastSeen.z-local.z)};
    return null;
  }
  function spawnTracer(from,to,color='#f3a675'){
    const geom=new THREE.BufferGeometry().setFromPoints([from,to]),material=new THREE.LineBasicMaterial({color,transparent:true,opacity:.92});const line=new THREE.Line(geom,material);root.add(line);tracers.push({obj:line,life:.12,max:.12});
  }
  function hurtEnemy(enemy,damage){
    if(!enemy||!enemy.data.alive)return;AudioRuntime.npcVoice(enemy.root,"hurt",enemy.data.kind,dungeonAudioTime);const d=enemy.data;d.aggro=true;d.hp-=damage;
    if(enemy.root.userData.hpFill){const width=Math.max(.02,.82*Math.max(0,d.hp/d.maxHp));enemy.root.userData.hpFill.scale.x=width;enemy.root.userData.hpFill.position.x=-(.82-width)/2}
    if(d.hp<=0){hideHealthBar(enemy);d.hp=0;d.alive=false;const payout=Math.floor((35+floorNumber*12)*(enemy.def.faction==='fisher'?1:1.25));save.cash+=payout;save.dungeonKills=(save.dungeonKills||0)+1;awardXP(40+floorNumber*9);persist();refreshHud();sfx('enemyDown');if(enemy.def.faction==='fisher'&&Math.random()<.08)save.escapeRopes=(save.escapeRopes||0)+1;enemy.root.userData.defeated=true;defeatedEnemies.push({enemy,t:0,startY:enemy.root.position.y,startRotation:enemy.root.rotation.clone(),side:Math.sign(enemy.root.position.x)||1});persist();refreshHud()}
    updateInteraction(camera.position);
  }
  function damageEnemyObject(object,damage){let obj=object;while(obj&&!targetMap.has(obj))obj=obj.parent;const d=obj&&targetMap.get(obj);if(!d)return false;const enemy=runtimeEnemies.find(e=>e.data===d);if(enemy)hurtEnemy(enemy,damage);return !!enemy;}
  function getTargets(){return runtimeEnemies.filter(e=>e.data.alive&&e.root.visible).map(e=>e.root)}
  let dungeonRayRoot=null,dungeonRayTime=-1,dungeonRayMeshes=[],dungeonRayHits=[];
  function raycast(raycaster){if(!active||!floorRoot)return null;if(dungeonRayRoot!==floorRoot||dungeonRayTime!==dungeonAudioTime){dungeonRayRoot=floorRoot;dungeonRayTime=dungeonAudioTime;dungeonRayMeshes=[];floorRoot.updateWorldMatrix(true,true);function visit(n){if(!n.visible||n.userData.noBulletHit)return;if(n.isMesh){if(!n.geometry.boundingSphere)n.geometry.computeBoundingSphere();dungeonRayMeshes.push({mesh:n,sphere:n.geometry.boundingSphere.clone().applyMatrix4(n.matrixWorld)})}for(const c of n.children)visit(c)}visit(floorRoot)}let best=null,far=raycaster.far;for(const e of dungeonRayMeshes){if(!raycaster.ray.intersectsSphere(e.sphere)||raycaster.ray.origin.distanceTo(e.sphere.center)-e.sphere.radius>raycaster.far)continue;dungeonRayHits.length=0;e.mesh.raycast(raycaster,dungeonRayHits);for(const hit of dungeonRayHits)if(hit.distance<=raycaster.far){best=hit;raycaster.far=hit.distance}}raycaster.far=far;return best}

  function animateEnemy(e,dt,moving){const g=e.root,baseY=e.surface?getGround(g.position.x,g.position.z):roomHeightAt(g.position.x,g.position.z),kind=e.data.kind,base=g.userData.baseKind||mobBase(kind),phase=(g.userData.animPhase=(g.userData.animPhase||0)+dt*(moving?8.5:2.1)),amp=moving?.48:.075,attack=Math.max(0,g.userData.attackMotion||0),strike=attack>0?Math.sin(Math.PI*(1-attack/.34)):0;for(const limb of g.userData.limbPivots||[]){const swing=Math.sin(phase+(limb.side<0?Math.PI:0));if(limb.role==='leg'){limb.pivot.rotation.x=swing*amp;limb.pivot.rotation.z=limb.side*.035}else{limb.pivot.rotation.x=-swing*amp*.72-(limb.side>0?strike*.82:0);limb.pivot.rotation.z=limb.side*(moving?.035:.018)+Math.sin(phase*.55+limb.side)*.025}}if(g.userData.crewRig){for(const limb of g.userData.limbPivots){const swing=Math.sin(phase+(limb.side<0?Math.PI:0));if(limb.role==='leg')limb.elbow.rotation.x=moving?Math.max(0,-swing)*.65:.06;else{const gun=e.def.weapon==='gun';limb.elbow.rotation.x=gun?-.8:-(moving?.12:.08)-strike*.45;if(gun){limb.pivot.rotation.x=-.55-(g.userData.aimPitch||0);limb.pivot.rotation.z=limb.side<0?.35:-.08;limb.pivot.rotation.y=limb.side<0?.30:-.12}else{limb.pivot.rotation.x-=strike*(limb.side>0?1.5:.4);limb.pivot.rotation.z+=limb.side*strike*.12}}}if(g.userData.gun){g.userData.gun.rotation.x=-(g.userData.aimPitch||0);g.userData.gun.position.z=.30-strike*.07}if(g.userData.flash)g.userData.flash.visible=(g.userData.attackMotion||0)>.27&&!g.userData.reloading;if(g.userData.burning){for(const limb of g.userData.limbPivots)if(limb.role==='arm'){limb.pivot.rotation.x=-2.1+Math.sin(phase*1.8+limb.side)*.6;limb.pivot.rotation.z=limb.side*.4}}}if(g.userData.torso){g.userData.torso.rotation.z=Math.sin(phase*.5)*(moving?.045:.018)+strike*.13;g.userData.torso.position.y=(g.userData.torsoBaseY||1.18)+Math.abs(Math.sin(phase))*(moving?.035:.012)}if(g.userData.head){g.userData.head.rotation.y=Math.sin(phase*.37)*.09;g.userData.head.rotation.z=Math.sin(phase*.7)*.025}if(base==='bat'){
      // A dive: the rig pitches nose-down, wings sweep back then rake forward, and the
      // claws snap out. Outside the .34 s attack window it is a plain flapping hover.
      const t=attack>0?Math.min(1,1-attack/.34):0,dive=attack>0?Math.sin(Math.PI*Math.min(1,t*1.08)):0,rake=attack>0?Math.max(0,Math.sin(Math.PI*(t-.42)/.58)):0;
      const rig=g.userData.batRig,hover=Math.sin(phase*1.4)*.4;
      g.position.y=baseY+1.1+hover-dive*.10;
      if(rig){
        rig.position.set(0,1.8-dive*.06,dive*.34);
        rig.rotation.x=dive*.72;
        rig.rotation.z=Math.sin(phase*.7)*.06;
      }
      for(const w of g.userData.wings||[]){
        const flap=Math.sin(phase*2.8)*(.62+strike*.22);
        w.mesh.rotation.z=w.side*(dive>0?flap*.45+.42:flap);
        w.mesh.rotation.x=-dive*.35;
        w.mesh.position.z=dive*.16;
      }
      for(const claw of g.userData.batClaws||[]){claw.scale.z=.28+rake*.9;claw.position.z=.32+rake*.16;claw.position.y=-.20-rake*.05}
    }else if(base==='slime'){
      // Squash, rear back, then throw the whole body and both arms forward into a slam.
      const t=attack>0?Math.min(1,1-attack/.34):0,wind=attack>0?Math.sin(Math.PI*Math.min(1,t/.42)):0,slam=attack>0?Math.max(0,Math.sin(Math.PI*(t-.30)/.70)):0;
      const hop=Math.abs(Math.sin(phase*1.7)),body=g.userData.slimeBody;
      g.position.y=baseY+Math.max(.06,hop*.26*(1-wind*.25));
      if(body){
        body.scale.set(.78*(1+wind*.07+slam*.05),.62*(.78+hop*.37+wind*.20-slam*.30),.72*(1+wind*.14+slam*.24));
        body.position.y=(g.userData.slimeBodyBaseY||.62)-(wind*.06)+slam*.05;
        body.position.z=wind*-.08+slam*.16;
        body.rotation.x=wind*-.16+slam*.22;
      }
      for(const arm of g.userData.slimeArms||[]){
        const s=arm.side;
        arm.pivot.rotation.x=-(wind*1.15)+slam*1.45;
        arm.pivot.rotation.z=s*(.30+wind*.28-slam*.10);
        arm.pivot.position.y=.86+wind*.10-slam*.12;
      }
    }else g.position.y=baseY+Math.sin(phase*2)*(moving?.035:.018)}
  function updateDefeatedEnemies(dt){for(let i=defeatedEnemies.length-1;i>=0;i--){const e=defeatedEnemies[i],g=e.enemy.root,kind=e.enemy.data.kind;e.t+=dt;const p=Math.min(1,e.t/1.18),ease=p*p*(3-2*p);if(kind==='slime'&&g.userData.slimeBody){g.position.y=e.startY+Math.max(.015,.1*(1-ease));g.userData.slimeBody.scale.set(.78+ease*.5,Math.max(.025,.48*(1-ease)),.72+ease*.42)}else{g.position.y=e.startY-ease*(kind==='bat'?.9:.34);g.rotation.x=e.startRotation.x+ease*(kind==='bat'?1.9:1.42);g.rotation.z=e.startRotation.z+e.side*ease*(kind==='bat'?.82:.48);for(const limb of g.userData.limbPivots||[]){if(limb.role==='leg')limb.pivot.rotation.x+=dt*2.2*limb.side;else limb.pivot.rotation.z+=dt*1.3*limb.side}}if(g.userData.hpFill)g.userData.hpFill.visible=p<.25;if(g.userData.hpBarBase)g.userData.hpBarBase.visible=p<.25;if(g.userData.nameplate)g.userData.nameplate.visible=p<.25;if(e.t>=1.45){try{onEnemyVanish(g.getWorldPosition(new THREE.Vector3()),kind)}catch{}g.visible=false;defeatedEnemies.splice(i,1)}}}
  function patrolEnemy(e,dt){
    const p=e.root.position,home=e.home;if(!home)return false;
    if(e.patrolGoal&&Math.hypot(p.x-e.patrolGoal.x,p.z-e.patrolGoal.z)<.35){e.patrolGoal=null;e.patrolAt=dungeonAudioTime+1.3+(e.root.id%5)*.4}
    if(!e.patrolGoal&&dungeonAudioTime>=e.patrolAt){
      e.patrolAt=dungeonAudioTime+2;
      for(let i=0;i<12;i++){const a=Math.random()*Math.PI*2,r=2+Math.random()*5.5,goal={x:home.x+Math.sin(a)*r,z:home.z+Math.cos(a)*r};if(!walkPointClear(goal.x,goal.z,e.radius))continue;const path=routeBetween(p,goal);if(!path.length)continue;e.patrolGoal=goal;e.navGoal=null;break}
    }
    return !!e.patrolGoal&&moveEnemyTo(e,e.patrolGoal,dt,e.moveSpeed*.44);
  }
  let dungeonAudioTime=0;
  function updateEnemies(dt,playerPos){
    dungeonAudioTime+=dt;
    for(const e of runtimeEnemies){
      if(!e.data.alive)continue;if(e.root.userData.hitStunUntil>performance.now())continue;const d=e.data,g=e.root;d.cooldown-=dt;e.attackTimer-=dt;e.meleeTimer-=dt;g.userData.attackMotion=Math.max(0,(g.userData.attackMotion||0)-dt);
      if(g.userData.burning){if(!e.burnGoal||dungeonAudioTime>=(e.burnGoalAt||0)){e.burnGoalAt=dungeonAudioTime+.9;e.burnGoal={x:g.position.x+Math.sin(g.id+dungeonAudioTime)*5,z:g.position.z+Math.cos(g.id+dungeonAudioTime)*5}}const moving=moveEnemyTo(e,e.burnGoal,dt,e.moveSpeed*1.2);animateEnemy(e,dt,moving);d.x=g.position.x;d.z=g.position.z;continue}
      const target=targetFor(e,playerPos);AudioRuntime.npcEngagement(g,!!target?.visible,d.kind,dungeonAudioTime);
      if(!target){const moving=patrolEnemy(e,dt);animateEnemy(e,dt,moving);d.x=g.position.x;d.z=g.position.z;AudioRuntime.updateNpcState(g,dungeonAudioTime);continue}
      d.aggro=d.aggro||target.type==='player';const dx=target.pos.x-g.position.x,dz=target.pos.z-g.position.z,dist=Math.max(.001,Math.hypot(dx,dz));g.rotation.y=Math.atan2(dx,dz);g.userData.aimPitch=THREE.MathUtils.clamp(Math.atan2(target.world?.y-enemyEye(e).y,dist),-.55,.55);
      const ranged=e.def.weapon==='gun',hold=ranged?8.5:1.4;
      const muzzleClear=target.visible&&hasDungeonLineOfSight(enemyMuzzle(e),target.world,g,target.enemy?.root);
      const moving=(dist>hold||!muzzleClear)&&moveEnemyTo(e,target.pos,dt,e.moveSpeed*(target.type==='player'?.83:1));
      // Never let a failed route turn an angry enemy into a statue: retry the route, then
      // drop the memory and resume hunting instead of standing where it lost the trail.
      if(moving||dist<=hold&&muzzleClear)e.stall=0;
      else{
        e.stall=(e.stall||0)+dt;
        if(e.stall>.4&&e.stall<1)e.navAt=0;
        if(e.stall>=4.2){e.stall=0;e.lastSeen=null;e.memoryUntil=0;e.navPath=null;e.navGoal=null;e.senseAt=0;d.aggro=false;e.patrolAt=dungeonAudioTime+1.2}
      }
      if(target.visible&&ranged&&dist<25&&e.attackTimer<=0){const from=enemyMuzzle(e),to=target.type==='player'?target.world.clone():target.enemy.root.getWorldPosition(new THREE.Vector3());to.y+=target.type==='player'?-.18:1.15;if(!hasDungeonLineOfSight(from,to,g,target.enemy?.root)||!AudioRuntime.tryNpcShot(g,dungeonAudioTime,{capacity:d.kind==="fisher_veteran"?8:6,reloadSeconds:2.7})){e.attackTimer=.2}else{e.attackTimer=Math.max(.48,1.52-floorNumber*.012)+Math.random()*.28;g.userData.attackMotion=.34;spawnTracer(from,to,'#ff925f');if(target.type==='player'){onPlayerHurt(8,g);if(isInvincible()){health=100;setPlayerHealth(100)}else{health=Math.max(0,health-(4+Math.min(20,floorNumber*.22)+Math.random()*2.8));setPlayerHealth(health)}}else hurtEnemy(target.enemy,10+floorNumber*.28)}}
      else if(target.visible&&!ranged&&dist<1.9&&e.meleeTimer<=0){const from=g.localToWorld(new THREE.Vector3(0,1.1,0)),to=target.type==='player'?target.world.clone():target.enemy.root.getWorldPosition(new THREE.Vector3());to.y+=target.type==='player'?-.18:1.0;if(!hasDungeonLineOfSight(from,to,g,target.enemy?.root)){e.meleeTimer=.2}else{e.meleeTimer=Math.max(.52,1.12-floorNumber*.009);g.userData.attackMotion=.34;const amount=(e.def.weapon==='club'?14:e.def.weapon==='claws'?8:e.def.weapon==='slime'?11:10)+Math.min(45,floorNumber*.45);if(target.type==='player'){onPlayerHurt(amount,g);if(isInvincible()){health=100;setPlayerHealth(100)}else{health=Math.max(0,health-amount);setPlayerHealth(health)}}else hurtEnemy(target.enemy,amount*.9)}}
      animateEnemy(e,dt,moving);AudioRuntime.updateNpcState(g,dungeonAudioTime);d.x=g.position.x;d.z=g.position.z;d.cooldown=Math.max(0,e.attackTimer);
    }
    updateDefeatedEnemies(dt);
    for(let i=tracers.length-1;i>=0;i--){const t=tracers[i];t.life-=dt;t.obj.material.opacity=Math.max(0,t.life/t.max);if(t.life<=0){root.remove(t.obj);t.obj.geometry.dispose();t.obj.material.dispose();tracers.splice(i,1)}}
    const torches=floorRoot?.userData.torches||[];for(const t of torches){const f=.82+.18*Math.sin(portalPulse*7+t.phase);t.light.intensity=t.power*f;if(t.flame)t.flame.scale.y=.18*f}
    if(health<=0){onPlayerDeath();return}
  }
  function update(dt,playerPos){
    if(isPlayerDead())return;
    portalPulse+=dt;entrance.glow.rotation.z+=dt*.45;entrance.light.intensity=4.1+Math.sin(portalPulse*2.2)*.7;entrance.beads.forEach((b,i)=>{b.position.y=1.85+Math.sin(portalPulse*1.5+i*2.1)*.8;b.rotation.y+=dt*(i+1)});
    updateClock-=dt;if(updateClock<=0){updateClock=.12;updateInteraction(playerPos)}
    if(active)updateEnemies(dt,playerPos);for(const e of runtimeEnemies)updateHealthBar(e,active);for(const mixer of enemyMixers)mixer.update(dt);
  }
  function buyRope(which){
    const qty=which==='bundle'?3:1,cost=which==='bundle'?3450:1250;if(save.cash<cost){notify('NOT ENOUGH CASH FOR AN ESCAPE ROPE');return false}save.cash-=cost;save.escapeRopes=(save.escapeRopes||0)+qty;persist();refreshHud();notify(`BOUGHT ${qty} ESCAPE ROPE${qty===1?'':'S'} · ${save.escapeRopes} IN PACK`);return true;
  }
  function getStatus(){return {active,floor:floorNumber,health,enemies:runtimeEnemies.filter(e=>e.data.alive).length,actionLabel,escapeRopes:save.escapeRopes||0}}
  return {respawnAfterDeath:()=>{health=100;setPlayerHealth(100);if(active)exit('')},updateEnemyRendering,createWorldEnemy:(kind,position,level=1,parent=scene)=>{const stats=mobStats(kind),baseHp=stats.base==='bat'?28:kind==='fisher_veteran'?72:stats.base==='slime'?58:50,hp=Math.max(8,Math.round((baseHp+Math.min(level,20)*4)*stats.hp));return spawnEnemy({id:'night-'+Math.random().toString(36).slice(2),kind,x:position.x,z:position.z,hp,maxHp:hp,alive:true,aggro:false,cooldown:.7},level,{parent})},animateWorldEnemy:animateEnemy,worldMuzzle:enemyMuzzle,updateWorldBar:(e,on,sight)=>updateHealthBar(e,on,sight),removeWorldEnemy:e=>{renderRecords.delete(e);removeHealthBar(e);e.root.userData.ownedFlashMaterial?.dispose();e.root.removeFromParent()},get active(){return active},get floor(){return floorNumber},getTargets,raycast,damageEnemyObject,update,move,interact,useRope,buyRope,updateInteraction,getStatus,statusLineOfSight:hasDungeonLineOfSight,statusActors:()=>runtimeEnemies.filter(e=>e.data.alive).map(e=>({actor:e.root,kind:e.def.faction==='fisher'?'human':'monster',human:e.def.faction==='fisher',indoors:true,radius:e.radius||.6,height:1.8,position:()=>e.root.getWorldPosition(new THREE.Vector3()),alive:()=>e.data.alive&&active,damage:n=>hurtEnemy(e,n)})),applyStatusDamage:n=>{onPlayerHurt(n);if(isInvincible())return;health=Math.max(0,health-n);setPlayerHealth(health);if(!health)onPlayerDeath()},health(){return health},cashFmt:n=>'$'+Math.floor(n).toLocaleString()};
}
