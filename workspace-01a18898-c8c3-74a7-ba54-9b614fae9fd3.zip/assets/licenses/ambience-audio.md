# Looping ambience credits and provenance

The four beds in `assets/audio/ambience/` are field recordings, cut to loop and re-encoded locally. They replace nothing that is synthesised at runtime: every ambience layer in the game is one of these files.

All four sources are **CC0 1.0 Universal** (https://creativecommons.org/publicdomain/zero/1.0/). No attribution is legally required; the authors are credited here in appreciation. Source licences checked on 29 October 2026. The game ships only the selected, locally encoded excerpts — the source archives and the preparation script's downloads are not part of the build, and nothing is fetched from the network during play.

| Shipped bed | Creator | Source page and source download | Excerpt used |
| --- | --- | --- | --- |
| `river.ogg` — river and shoreline water | RandomMind | https://opengameart.org/content/sea-and-river-wave-sounds ; https://opengameart.org/sites/default/files/VistulaShort_0.mp3 | 8.0 s onward, 36.06 s loop, 1.2 s seam crossfade |
| `day.ogg` — overworld daylight, birdsong and distant air | isaiah658 | https://opengameart.org/content/ambient-bird-sounds ; https://opengameart.org/sites/default/files/birds-isaiah658_0.ogg | start of file, 28.12 s loop, 0.6 s seam crossfade |
| `night.ogg` — overworld night, insect bed | Wolfgang_ (optional credit: Ted Kerr) | https://opengameart.org/content/crickets-ambient-noise-loopable ; https://opengameart.org/sites/default/files/crickets_1.mp3 | 0.12 s onward, 8.76 s loop, 1.5 s seam crossfade |
| `dungeon.ogg` — dungeon air, low wind and water drips | JaggedStone | https://opengameart.org/content/loopable-dungeon-ambience ; https://opengameart.org/sites/default/files/dungeon_ambient_1.ogg | 39.0 s onward (past the loud swell), 36.8 s loop, 1.4 s seam crossfade |

## Adaptations

- Render every source through `tools/prepare-ambience-audio.py`: the script decodes with `libsndfile`/`soundfile`, resamples to **32 kHz mono**, normalises peaks to about −1.6 dBFS and writes Vorbis with `libsndfile`.
- Loop points are not hand-picked. For each bed the script searches a range of loop lengths and fade lengths around the intended window and keeps the pair whose wrap-around step (last sample to first sample) is closest to the typical sample-to-sample step inside the loop, then applies an equal-power crossfade over that fade. The winning values are the ones listed above and are recorded in `assets/audio/ambience/manifest.json`.
- Measured seam quality after encoding (wrap step ÷ mean interior step, 0 = perfect seam, 1 = indistinguishable from any other sample step): river 0.14, day 0.56, night 0.11, dungeon 1.23. Peak levels 0.75–0.84 with no DC offset.
- Total shipped size 837,414 bytes for 2 min 46 s of looping ambience (32 kHz mono Vorbis).

## How the beds are used

- `river.ogg` is the water bed: it rises near the river channel and along the shoreline, and fades out inland.
- `day.ogg` and `night.ogg` are the two overworld beds; they crossfade over the world clock's dusk (tick 12000–13000) and dawn (23000–24000) so night falls to the insect bed and morning returns to birdsong. Rain and thunder duck the birds and insects, since the weather loop carries those moments.
- `dungeon.ogg` replaces every overworld bed the moment the player steps into the Sinking Stairs.
- The overworld beds and the river are ducked by 74% inside the house interior and inside a boat cabin. Cabins are detected from the hull's own cabin volume, so standing on an open deck or on a cabin roof is still outdoors.
- Entering a menu, a hidden tab, the death cinematic or muting the game releases the beds (`stopLoops` releases them along with every other loop).

## Boat engines

The two engine loops are the CC0 outboard and idler recordings listed in `assets/licenses/recorded-audio.md`; the game mixes them from measured hull motion. A hull with a hand on the wheel is never silent: when the helm turns the boat (`dr`), the engine is marked as running for the next 0.45 s and the engine bed plays even if the crew is still officially waking up or the hull is still flagged as resting.
