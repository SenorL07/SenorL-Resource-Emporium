# Bullet-water impact graphics

- Creator: Kenney Vleugels / Kenney.nl
- Pack: Particle Pack 1.1, CC0 (public domain)
- Official asset page: https://kenney.nl/assets/particle-pack
- Source mirror: https://github.com/Calinou/kenney-particle-pack
- Download: https://raw.githubusercontent.com/Calinou/kenney-particle-pack/master/addons/kenney_particle_pack/dirt_02.png
- Mirror license: https://raw.githubusercontent.com/Calinou/kenney-particle-pack/master/LICENSE.txt
- Included license text: `kenney/particle-pack.txt`
- Local file: `assets/particles/water_splash.png`
- Adaptation: original 512×512 transparent white burst resized to 128×128; named for its in-game use. Tinted pale cyan/white, animated as a spray/foam burst with pooled droplets and expanding surface ripples. No remote runtime dependency.

Existing `trace_02.png` droplets and `circle_04.png` ripples come from the same credited CC0 pack. Splash audio reuses the existing locally bundled CC0 water recordings; see `recorded-audio.md`.
