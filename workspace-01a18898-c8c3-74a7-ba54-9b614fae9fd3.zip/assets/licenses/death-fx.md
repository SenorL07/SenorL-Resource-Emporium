# Death smoke, impact blasts and arsenal audio/graphics

Everything in this update is **CC0 1.0 Universal** (public domain, free for personal and commercial use) or original project work. Nothing is extracted from Doom, a WAD, or any id Software data file, and nothing is fetched at runtime — all files are bundled locally. CC0 legal code: https://creativecommons.org/publicdomain/zero/1.0/legalcode

Source licences checked 29 October 2026. Only the selected excerpts are shipped; source archives were deleted after preparation.

## Death smoke puffs — `assets/particles/puff_01..03.png`

| Local file | Creator / pack | Source |
| --- | --- | --- |
| `puff_01.png`, `puff_02.png`, `puff_03.png` | Kenney Vleugels / Kenney.nl, **Smoke particle assets** (CC0), "White puff" style | https://opengameart.org/content/smoke-particle-assets |

Adaptation: three white-puff silhouettes (`whitePuff00`, `whitePuff03`, `whitePuff05`) cropped to their alpha bounds and resized to 128×128 with Lanczos resampling. They stay neutral white and are tinted per use — near-white for mobs, pale grey for humans, cool grey-green for slime/drowning deaths — so one small texture set covers every death. The original soft, cloud-like alpha edge and internal wispiness are preserved, which is what gives the puffs their blocky-fog Minecraft read once they are scaled, rotated and faded.

Used by `death-effects.js`, which is embedded into the game by `tools/build.js`.

## Fire, green and plasma blasts — `assets/particles/blast_*`, `blastgreen_*`, `plasma_*`

| Local file | Creator / pack | Source |
| --- | --- | --- |
| `blast_01..06.png` | Kenney, same CC0 smoke pack, "Explosion" style | https://opengameart.org/content/smoke-particle-assets |
| `blastgreen_01..04.png` | Derived from the above (hue-rotated) | same source, CC0 |
| `plasma_01..04.png` | Reactorcore, **Plasma electric effect animations** (CC0), "Plasma Ball" sheet | https://opengameart.org/content/plasma-electric-effect-animations |

Adaptation: the six orange explosion silhouettes were cropped and resized to 128×128. Four of them were then hue-rotated by +62/255 in HSV to produce the green BFG variants, which is why the BFG blast and its tracer impacts share the same soft shape as the rocket blast while reading as a different weapon. The Reactorcore plasma frames are near-black magenta pixel art; they were hue-rotated to blue-cyan (so the plasma rifle keeps its classic blue bolt) and nearest-neighbour upscaled to 88 px inside a 128 px sprite, preserving the hard pixel edges of the original sheet. The pixel plasma ball is used both as the flying projectile animation and as the plasma impact flash.

## Arsenal recordings — `assets/audio/weapons/`

| Local file | Creator / pack | Source |
| --- | --- | --- |
| `shotgun-1.ogg` | Tabasco, **Gunshot sounds** (CC0), recorded 12-gauge pump shotgun | https://opengameart.org/content/gunshot-sounds |
| `supershotgun-1.ogg`, `supershotgun-2.ogg` | Derived from the same CC0 recording | same source |
| `explosion-1.ogg` | EZduzziteh, **Explosions 4** (CC0), `explosion4.ogg` | https://opengameart.org/content/explosions-4 |
| `explosion-2.ogg` | rubberduck, **25 CC0 bang SFX** (CC0), `bang_03.ogg` | https://opengameart.org/content/25-cc0-bang-sfx |
| `plasma-hit.ogg` | Derived from `Explosions 4` (CC0) | https://opengameart.org/content/explosions-4 |
| `bfg-blast.ogg` | Derived from `Explosions 4` (CC0) | https://opengameart.org/content/explosions-4 |

Adaptations (all mono, 24 kHz, peak-normalised, short endpoint fades, Vorbis, < 50 KiB total):

- `shotgun-1` is the shotgun report trimmed to its first 0.70 s; the pistol keeps its previous Walther PPQ recording, so handgun and shotgun no longer share a sound.
- `supershotgun-1/2` are built *from* the same CC0 shotgun body (no new recording): the report is doubled 31–48 ms apart at two different pitches, a lower-pitched copy is layered under the front for weight, and a short synthesised sub-bass thud from this project's own oscillator code is added. That gives the super shotgun its heavier double-charge character. This is the only synthesised component shipped in this update and it is our own original signal, not a sample of anyone else's work.
- `explosion-1/2` are two different CC0 explosion/bang recordings so consecutive rocket detonations alternate.
- `bfg-blast` is a CC0 explosion pitched down, lengthened and given the same original sub-bass thud; `plasma-hit` is a short bright CC0 blast used for plasma impacts.

## Reference-only research

Weapon timings, pellet counts, spread angles, BFG spray geometry and the "no autofire on the rocket launcher / BFG" rule were derived from the publicly published Doom source (`p_pspr.c`, `d_code` state timings in `info.c`) and the Doom Wiki. The source was read for *mechanics only*: no id Software art, audio, map, sprite or table data is included, and the game's weapons remain original procedural models with original sound files.

## Runtime behaviour

Puffs and blasts live in two small fixed pools (`death-effects.js`): 30 puffs + 9 blasts on desktop, 16 + 5 in low-power/mobile mode. Idle sprites are `visible = false` and cost no draw calls; every sprite is marked `noBulletHit`/`noLOSBlock` and cannot be shot, block line of sight or become a collider. Rocket smoke uses the same pool at one puff every 90 ms with a 0.32 s life, so a full flight cannot starve a death puff. Audio stays inside the existing lazy-decode/lazy-fetch path with the usual per-sound cooldowns and distance attenuation.
