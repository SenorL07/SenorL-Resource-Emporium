# Recorded audio credits and provenance

All 54 clips in `assets/audio/recorded/` are adaptations of **CC0 1.0 Universal** assets. No attribution is legally required under CC0; authors are credited here in appreciation. License: https://creativecommons.org/publicdomain/zero/1.0/ — legal code: https://creativecommons.org/publicdomain/zero/1.0/legalcode

Source licenses checked on 27 October 2026. The game ships only the selected, locally encoded excerpts, not the source archives. There are no account-dependent or third-party audio requests during gameplay.

| Shipped clips | Creator / collection | Source page and source download |
| --- | --- | --- |
| `human-alert-*`, `human-hurt-*` | HaelDB, Male grunt/yelling sounds; recordings from multiple male actors | https://opengameart.org/content/male-gruntyelling-sounds ; https://opengameart.org/sites/default/files/yelling%20sounds.zip ; CC0 option selected |
| `human-idle-*`, `cloth`, `rattle`, `grass-*`, `hard-*` | OwlishMedia / OwlStorm, Sound Effects Pack; recorded breath, cough, yawn, sniff, blanket movement, pill-bottle rattle and footsteps | https://opengameart.org/content/sound-effects-pack ; https://opengameart.org/sites/default/files/Owlish%20Media%20Sound%20Effects.zip |
| `bat-*`, `skeleton-*` | rubberduck, 80 CC0 creature SFX; bug/cute creature chirps and raspy monster/hurt sounds | https://opengameart.org/content/80-cc0-creature-sfx ; https://opengameart.org/sites/default/files/80-CC0-creature-SFX_0.zip |
| `goblin-*` | artisticdude, Goblins Sound Pack, created for Summoning Wars | https://opengameart.org/content/goblins-sound-pack ; https://opengameart.org/sites/default/files/goblins_0.zip |
| `slime-*`, `splash`, `water-gulp`, `rain` | rubberduck, 40 CC0 water/splash/slime SFX; includes partly real-slime recordings | https://opengameart.org/content/40-cc0-water-splash-slime-sfx ; https://opengameart.org/sites/default/files/water-splash-slime-sfx.zip |
| `pistol`, `rifle`, `marksman`, `shotgun` | Ben Jaszczak, Brian Nelson, Kevin Heras and Matthew Nanney, The Free Firearm Sound Library; recorded Walther PPQ, SKS, Mosin Nagant and Nova | https://opengameart.org/content/the-free-firearm-sound-library ; https://opengameart.org/sites/default/files/Prepared%20SFX%20Library.7z |
| `reload`, `cock` | SpringySpringo, Gun Reload Sounds; recorded airsoft rifle mechanisms | https://opengameart.org/content/gun-reload-sounds ; https://opengameart.org/sites/default/files/assaultriflereload1_0.wav ; https://opengameart.org/sites/default/files/shotguncock_0.wav |
| `engine-run` | kyles, outboard motor boat onboard high speed, field recording | https://freesound.org/people/kyles/sounds/637744/ ; CC0 high-quality preview: https://cdn.freesound.org/previews/637/637744_612689-hq.mp3 |
| `engine-idle` | gthall, engine-idle-2; small Honda motor recorded with Tascam DR-40, used as quiet motor rumble | https://freesound.org/people/gthall/sounds/222805/ ; CC0 high-quality preview: https://cdn.freesound.org/previews/222/222805_1573847-hq.mp3 |
| `thunder` | Kinoton, Thunder Clap And Rumble #1 | https://freesound.org/people/Kinoton/sounds/397952/ ; CC0 high-quality preview: https://cdn.freesound.org/previews/397/397952_2247456-hq.mp3 |

## Adaptations and creature identities

- All selected clips: silence trimming, mono 24 kHz conversion, peak normalization and Vorbis encoding. One-shots have fades; engines/rain use cyclic 220 ms crossfades. Exact original filenames, excerpt offsets and output durations are in `assets/audio/recorded/manifest.json`.
- Bat: short, high-pitched creature chirps/squeals. Slime: wet, partly recorded slime and bubbles. Skeleton: low, hollow rasps with quiet recorded object-rattle layers. Goblin: separate voiced goblin performances. These are designed creature effects, not claimed to be recordings of actual monsters or actual bat field calls.
- Human alerts are nonverbal battle cries; pain is performed grunting; idle is breathing, coughing, yawning or sniffing. These are stock recordings, not generated speech or chiptune oscillators.
- Moving boat audio uses an actual outboard recording. Idle rumble is adapted from a small stationary motor recording; the game crossfades and changes playback speed with measured boat movement.
- Cannon effects use a lower, heavier recorded shotgun report and a separate breech reload cycle; no claim of authentic artillery field recording.

Natural impact/coin/wood and subtle interface cues retained from Kenney remain CC0; see `assets/licenses/kenney/`. Active gameplay no longer uses laser, sci-fi explosion, electronic slime or synthesized rain/thunder placeholders.

## Additional material footsteps

These selected clips are also **CC0 1.0 Universal**; source pages identify the license. Selected original clips are shipped locally, without their large source archives. Existing grass, hard-stone and splash recordings above are reused for grass, stone and shallow-water steps.

| Shipped clips | Creator / collection | Source page and archive | Use / adaptation |
| --- | --- | --- | --- |
| `surfaces/wood01.ogg`, `wood02.ogg`, `wood03.ogg`, `stone01.ogg`, `gravel.ogg`, `mud02.ogg` | TinyWorlds, Different Steps on Wood, Stone, Leaves, Gravel and Mud; edited pdsounds.org recordings | https://opengameart.org/content/different-steps-on-wood-stone-leaves-gravel-and-mud ; https://opengameart.org/sites/default/files/%5Bkdd%5DDifferentSteps_0.zip | Selected wood, stone, gravel and mud footsteps. Unused leaf recordings omitted. |
| `surfaces/Fantozzi-SandL1.ogg`, `Fantozzi-SandR1.ogg`, `Fantozzi-SandL2.ogg`, `Fantozzi-SandR2.ogg` | Fantozzi, Footsteps — Grass/Sand & Stone; submitted by qubodup | https://opengameart.org/content/fantozzis-footsteps-grasssand-stone ; https://opengameart.org/sites/default/files/Fantozzi-footsteps.7z | Original sand recordings, renamed with creator prefix; alternate left/right variants. |
| `surfaces/metal-1.wav`, `metal-2.wav` | Thimras, Metal Footsteps on Concrete | https://opengameart.org/content/metal-footsteps-on-concrete ; https://opengameart.org/sites/default/files/metal_steps_48k24b.7z | Two clips from the author's 48 kHz/24-bit distribution; recordings of metal feet on concrete, repurposed as metallic boat-roof footsteps, not claimed as actual roof recordings. |
| `kenney/impact/footstep_carpet_000.ogg`, `footstep_carpet_001.ogg`, `footstep_concrete_000.ogg`, `footstep_concrete_001.ogg` | Kenney, Impact Sounds | https://kenney.nl/assets/impact-sounds ; https://kenney.nl/media/pages/assets/impact-sounds/87b4ddecda-1677589768/kenney_impact-sounds.zip | Original selected carpet and concrete clips; original CC0 license also preserved in `kenney/impact-License.txt`. |

Playback varies pitch slightly and uses spatial attenuation; decoding remains lazy and concurrency-limited. No additional synthesised fallback or remote runtime audio service is used.
