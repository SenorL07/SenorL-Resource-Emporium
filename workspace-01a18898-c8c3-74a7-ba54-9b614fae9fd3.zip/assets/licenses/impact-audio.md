# Material impact sounds

These 13 clips are **hit/impact recordings**, distinct from the destruction clips in `assets/audio/breakage/`. All sources are **CC0 1.0 Universal** (free for personal and commercial use, no attribution required; credited here as good practice). No runtime third-party requests, synthesized oscillators, chiptune or generative audio. Licenses checked 28 October 2026. Machine-readable list: `assets/audio/impacts/manifest.json`.

| Local file | Author / source | Original |
| --- | --- | --- |
| `glass-1.ogg`, `glass-2.ogg` | rubberduck, [75 CC0 breaking / falling / hit SFX](https://opengameart.org/content/75-cc0-breaking-falling-hit-sfx) | `bfh1_glass_hit_01.ogg`, `bfh1_glass_hit_02.ogg` from [source archive](https://opengameart.org/sites/default/files/sfx_breaking_and_falling.zip) |
| `metal-1.ogg`, `metal-2.ogg` | rubberduck, [100 CC0 metal and wood SFX](https://opengameart.org/content/100-cc0-metal-and-wood-sfx) | `metal_hit_01.ogg`, `metal_hit_02.ogg` from [source archive](https://opengameart.org/sites/default/files/100-CC0-wood-metal-SFX.zip) |
| `metal-3.ogg` | Iwan "qubodup" Gabovitch, [Impact](https://opengameart.org/content/impact) | `qubodupImpactMetal.flac` from [source archive](https://opengameart.org/sites/default/files/qubodupImpact.7z) |
| `wood-1.ogg`, `wood-2.ogg` | rubberduck, 100 CC0 metal and wood SFX (as above) | `wood_hit_01.ogg`, `wood_hit_02.ogg` |
| `wood-3.ogg` | qubodup, Impact (as above) | `qubodupImpactWood.flac` |
| `stone-1.ogg` | qubodup, Impact (as above) | `qubodupImpactStone.flac` |
| `stone-2.ogg` | rubberduck, 75 CC0 breaking / falling / hit SFX (as above) | `bfh1_rock_hit_01.ogg` |
| `earth-1.ogg` | qubodup, Impact (as above) | `qubodupImpactStone.flac`, softened for soil |
| `flesh-1.ogg`, `flesh-2.ogg` | qubodup, Impact (as above) | `qubodupImpactMeat01.flac`, `qubodupImpactMeat02.flac` |

Soft-material (fabric/net/canvas) hits reuse the already-bundled **Kenney Impact Sounds** `impact/impactSoft_medium_001.ogg`, received separately from this pack's distribution. Full notice: `assets/licenses/kenney/impact-License.txt`. Original source: [kenney.nl/assets/impact-sounds](https://kenney.nl/assets/impact-sounds), CC0.

Adaptations: downmix to mono, resample to 32 kHz, trim leading/trailing silence while retaining the attack and a short tail, normalize to 0.83 peak, apply short endpoint fades, encode as Vorbis. `earth-1` additionally receives a 3rd-order 850 Hz low-pass to read as damp soil rather than stone. Variants play at near-original pitch. No unselected clips or source archives are shipped.

CC0 legal code: https://creativecommons.org/publicdomain/zero/1.0/legalcode

Routing lives in `material-impacts.js`: glass windows, wooden doors/crates/planks, metal equipment and hulls, stone/dungeon/rock, damp earth, flesh for player/crew/enemies, fabric for nets and upholstery. Water produces a splash instead of a solid hit, and destruction deliberately uses only the separate `break-*` set.
