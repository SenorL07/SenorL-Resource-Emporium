# Destruction sounds and particles

All new destruction clips are locally bundled **CC0 1.0 Universal** selections, free for personal and commercial use. No runtime third-party requests, synthesized oscillators, chiptune or generative audio. Source licenses checked 28 October 2026.

| Local file in `assets/audio/breakage/` | Author / source | Original |
| --- | --- | --- |
| `glass-1.ogg` | Till Behrend, submitted by TinyWorlds, [Glass Break](https://opengameart.org/content/glass-break) | [glass_breaking.wav](https://opengameart.org/sites/default/files/glass_breaking.wav) |
| `glass-2.ogg` | rubberduck, [75 CC0 breaking / falling / hit SFX](https://opengameart.org/content/75-cc0-breaking-falling-hit-sfx) | `bfh1_glass_breaking_01.ogg` from [source archive](https://opengameart.org/sites/default/files/sfx_breaking_and_falling.zip) |
| `wood-1.ogg`, `wood-2.ogg` | rubberduck, same CC0 collection | `bfh1_wood_breaking_01.ogg`, `bfh1_wood_breaking_02.ogg` |
| `metal-1.ogg`, `metal-2.ogg` | rubberduck, same CC0 collection | `bfh1_metal_falling_03.ogg`, `bfh1_metal_falling_04.ogg`; metallic collapse/clatter rather than an electronic explosion |
| `fabric-1.ogg` | OwlishMedia / OwlStorm, [Sound Effects Pack](https://opengameart.org/content/sound-effects-pack) | Existing `recorded/cloth.ogg`, a blanket/fabric movement recording, reused for a net collapsing; not claimed to be an actual net tearing recording. See `recorded-audio.md` for its source archive. |

Adaptations: downmix to mono, resample to 32 kHz, trim excess silence while retaining a short tail, normalize to 0.86 peak, apply 5 ms endpoint fades and encode as Vorbis. Variants play at near-original pitch. No archives or unselected clips shipped.

CC0 legal code: https://creativecommons.org/publicdomain/zero/1.0/legalcode

The pooled dust puffs and metal sparks reuse the existing local **Kenney Particle Pack 1.1** CC0 sprites (`smoke_01`, `spark_04`). Original source: https://kenney.nl/assets/particle-pack ; full bundled notice in `kenney/particle-pack.txt`. Flying glass shards, wood splinters, fabric scraps and metal fragments are original lightweight 3D geometry, not extracted from another game. They are cosmetic and never add colliders or damage.
