// Death smoke and impact blasts shared by mobs, fishermen, fish and the arsenal.
// Every sprite is a locally bundled CC0 texture (see assets/licenses/death-particles.md);
// nothing here is fetched at runtime and no particle ever becomes a collider.
export function createDeathEffects(T,{scene,textures,lowPower=false}){
 const puffMaps=(textures?.puffs||[]).filter(Boolean),blastMaps=(textures?.blasts||[]).filter(Boolean),greenMaps=(textures?.greenBlasts||[]).filter(Boolean),plasmaMaps=(textures?.plasma||[]).filter(Boolean);
 const puffs=[],blasts=[];
 const puffCount=lowPower?16:30,blastCount=lowPower?5:9;
 for(let i=0;i<puffCount;i++){
  const material=new T.SpriteMaterial({map:puffMaps[i%Math.max(1,puffMaps.length)]||null,color:0xffffff,transparent:true,opacity:0,depthWrite:false,depthTest:true,fog:true});
  const sprite=new T.Sprite(material);
  sprite.name='Death smoke puff';sprite.visible=false;sprite.renderOrder=7;sprite.userData.noBulletHit=true;sprite.userData.noLOSBlock=true;sprite.raycast=()=>{};
  scene.add(sprite);
  puffs.push({sprite,material,life:0,max:1,size0:.2,size1:.4,alpha:1,spin:0,spinRate:0,vx:0,vy:0,vz:0,x:0,y:0,z:0});
 }
 for(let i=0;i<blastCount;i++){
  const material=new T.SpriteMaterial({map:blastMaps[0]||null,color:0xffffff,transparent:true,opacity:0,depthWrite:false,depthTest:true,blending:T.NormalBlending});
  const sprite=new T.Sprite(material);
  sprite.name='Impact blast';sprite.visible=false;sprite.renderOrder=8;sprite.userData.noBulletHit=true;sprite.userData.noLOSBlock=true;sprite.raycast=()=>{};
  scene.add(sprite);
  blasts.push({sprite,material,life:0,max:1,frames:blastMaps,size:.9,grow:2.2,alpha:1,stretch:1});
 }
 let cursor=0,blastCursor=0;
 function takePuff(){
  for(let i=0;i<puffs.length;i++){const entry=puffs[(cursor+i)%puffs.length];if(entry.life<=0){cursor=(cursor+i+1)%puffs.length;return entry}}
  const entry=puffs[cursor];cursor=(cursor+1)%puffs.length;return entry;
 }
 function puff(position,options={}){
  if(!position)return;
  const count=Math.max(1,Math.round(options.count??9)),size=options.size??.30,grow=options.grow??1.6,life=options.life??.95,rise=options.rise??.62,spread=options.spread??.85,alpha=options.alpha??.92,color=options.color??0xf6f5ef,drift=options.drift||null;
  for(let i=0;i<count;i++){
   const entry=takePuff(),material=entry.material;
   if(puffMaps.length>1)material.map=puffMaps[(Math.random()*puffMaps.length)|0];
   material.color.setHex(color);
   const angle=Math.random()*Math.PI*2,radius=(.12+Math.random()*.42)*spread;
   entry.x=position.x+Math.cos(angle)*radius;entry.y=position.y+(Math.random()-.28)*size*1.5;entry.z=position.z+Math.sin(angle)*radius;
   entry.vx=Math.cos(angle)*(.22+Math.random()*.5)*spread+(drift?.x||0);entry.vz=Math.sin(angle)*(.22+Math.random()*.5)*spread+(drift?.z||0);entry.vy=rise*(.35+Math.random()*.85);
   entry.life=entry.max=life*(.78+Math.random()*.44);
   entry.size0=size*(.6+Math.random()*.45);entry.size1=entry.size0*(1+grow*(.8+Math.random()*.5));
   entry.alpha=alpha*(.72+Math.random()*.28);entry.spin=Math.random()*Math.PI*2;entry.spinRate=(Math.random()-.5)*1.1;
   entry.sprite.visible=true;entry.sprite.scale.setScalar(entry.size0);material.opacity=0;entry.sprite.material.rotation=entry.spin;
   entry.sprite.position.set(entry.x,entry.y,entry.z);
  }
 }
 function takeBlast(){
  for(let i=0;i<blasts.length;i++){const entry=blasts[(blastCursor+i)%blasts.length];if(entry.life<=0){blastCursor=(blastCursor+i+1)%blasts.length;return entry}}
  const entry=blasts[blastCursor];blastCursor=(blastCursor+1)%blasts.length;return entry;
 }
 function blast(position,options={}){
  if(!position)return;
  const style=options.style||'fire';
  const frames=style==='green'?greenMaps:style==='plasma'?plasmaMaps:blastMaps;
  const entry=takeBlast(),material=entry.material;
  entry.frames=frames.length?frames:blastMaps;
  entry.life=entry.max=options.duration??(style==='green'?.62:style==='plasma'?.30:.52);
  entry.size=options.size??.9;entry.grow=options.grow??(style==='green'?2.9:style==='plasma'?.5:2.3);entry.alpha=options.alpha??1;entry.stretch=options.stretch??1;
  entry.sprite.position.copy(position);entry.sprite.visible=true;
  material.map=entry.frames[0]||null;
  material.color.setHex(options.color??0xffffff);
  material.opacity=entry.alpha;material.blending=style==='fire'?T.NormalBlending:T.AdditiveBlending;
  entry.sprite.scale.set(entry.size,entry.size*entry.stretch,1);
  entry.sprite.material.rotation=Math.random()*Math.PI*2;
 }
 function update(dt){
  if(!(dt>0))return;
  for(const entry of puffs){
   if(entry.life<=0)continue;
   entry.life-=dt;
   if(entry.life<=0){entry.sprite.visible=false;entry.material.opacity=0;continue}
   const t=1-entry.life/entry.max;
   entry.x+=entry.vx*dt;entry.y+=entry.vy*dt;entry.z+=entry.vz*dt;
   entry.vy-=dt*.55;
   entry.vx*=(1-dt*1.1);entry.vz*=(1-dt*1.1);
   entry.size0+=(entry.size1-entry.size0)*Math.min(1,dt*6);
   entry.sprite.position.set(entry.x,entry.y,entry.z);
   entry.sprite.scale.setScalar(entry.size0);
   entry.spin+=entry.spinRate*dt;entry.material.rotation=entry.spin;
   entry.material.opacity=entry.alpha*(t<.12?t/.12:1)*(1-Math.max(0,(t-.45)/.55)**1.35);
  }
  for(const entry of blasts){
   if(entry.life<=0)continue;
   entry.life-=dt;
   if(entry.life<=0){entry.sprite.visible=false;entry.material.opacity=0;continue}
   const t=1-entry.life/entry.max,frame=Math.min(entry.frames.length-1,Math.floor(t*entry.frames.length));
   if(entry.frames[frame]&&entry.material.map!==entry.frames[frame])entry.material.map=entry.frames[frame];
   const scale=entry.size*(1+entry.grow*t);
   entry.sprite.scale.set(scale,scale*entry.stretch,1);
   entry.material.opacity=entry.alpha*(t<.1?t/.1:1)*(1-Math.max(0,(t-.4)/.6)**1.6);
  }
 }
 function reset(){for(const entry of puffs){entry.life=0;entry.sprite.visible=false}for(const entry of blasts){entry.life=0;entry.sprite.visible=false}}
 return {puff,blast,update,reset,puffs,blasts};
}
