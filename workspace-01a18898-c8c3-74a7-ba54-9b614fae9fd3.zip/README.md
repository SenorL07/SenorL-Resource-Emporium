# Hard Water Island Tycoon

A browser-based Three.js island, fishing and naval-combat game. Open the live preview, or serve this folder locally; do not open `index.html` through a `file:` URL.

## Run

```sh
python3 -m http.server 8000 --bind 0.0.0.0
```

Visit the server in a browser. The checked-in `three-game.js` is the playable bundle; graphics/audio are local under `assets/`.

## Build

```sh
npm ci
npm run build
```

Build synchronization copies canonical gameplay modules into their marked blocks in `main.js`, then esbuild produces `three-game.js`. The build stamps its content hash into the script URL in `index.html` to avoid stale cached builds. Edit those modules rather than their synchronized copies. `boat-equipment.js` owns independent equipment HP, maintenance jobs, home-roster ownership, equipment effects and unarmed fallback. Destruction presentation is in `breakage.js`, material hit routing in `material-impacts.js` and non-combatant panic in `crew-panic.js`; their audio credits are in `assets/licenses/breakage-audio.md` and `assets/licenses/impact-audio.md`. Related systems are in `fleet.js`, `weapons.js`, `sound.js`, `boat-alerts.js`, `crew-transit.js`, `boarding-defense.js`, `naval-combat.js`, `overboard.js`, and `player-combat.js`.

## Player death

Death uses a visual-only dropped weapon, a low tilted camera with a short bounce, and a delayed fade to black with one of 109 original trivia/tip/fishing/maritime quotes. Quotes are shuffled without repeats until the pool is exhausted. Respawn restores full health and keeps the player's loadout/ammo; the scene lasts about eight seconds. The canonical implementation and quote pool are in `player-death.js`.

## HUD and controls

Routine crew actions are communicated through the world, not narrated by toasts. Boat health appears during direct player combat, shows only boat identity and hull HP, then expires after 25 seconds without engagement. Important arrival/departure and transaction/error alerts remain. The title screen contains the controls guide. Touch controls and weapon-slot buttons stay out of all menus; held inputs are cleared when opening one.

## Soundscape

Ambience is four looping CC0 field recordings shipped in `assets/audio/ambience/`: river and shoreline water, an overworld daylight bed of birdsong, a separate insect bed for the night, and the dungeon's wind-and-drips bed. They are plain looping buffers in `sound.js` (not `loopSound` voices, which are capped and swept by boat mixing) that crossfade over roughly two seconds, so dusk fades birdsong into crickets, the river swells as you walk down to the water, and the dungeon bed replaces the surface mix on the stairs. Entering the house interior or a boat cabin ducks the river and overworld beds by 74%; open decks, cabin roofs and the dungeon itself are unaffected. Menus, hidden tabs and muting release the beds along with the other loops. Source pages, excerpt offsets, loop-seam measurements and the offline preparation script are documented in `assets/licenses/ambience-audio.md` and `tools/prepare-ambience-audio.py`.

Every hull that is actually under way is audible: boat engines are mixed from measured hull motion and, additionally, from the helm itself, so a boat a woken crew drives away from a threat can never move in silence even while its rest state still says the crew is asleep. A moored boat with nobody at the wheel stays quiet.

## Current naval rules

- Crew respawn on their home boat even after boarding and drowning elsewhere.
- Boat equipment has separate HP from the hull and is physically serviced by maintenance workers. Rebuild times depend on the object and exclude travel time.
- A destroyed door blocks non-maintenance respawns, one destroyed motor halves propulsion, and both destroyed motors disable powered movement/steering.
- Destroyed guns and fishing gear stop working. Radar destruction reduces new threat detection range.
- Without a surviving ammo crate, home crew finish loaded rounds, then use fists until a crate is rebuilt. Changing tasks does not create ammunition.
- Onboard hostile players trigger handheld defense when a turret cannot aim or obtain a clear shot. Working, effective turrets remain in use.

## Roaming enemies

Roaming fishermen and crypt creatures pick a fight and stay in it. A mob keeps the target it engaged while that target is alive, close enough and in sight, even if something else wanders closer; only when the fight is lost does it move on, searching the spot where it last saw its target before going back to patrol. Taking serious damage from a third party — a monster chewing on a fisherman, or a stray round from another crew — pulls it onto that attacker instead.

Slimes, goblins, bats and skeletons each come in three breeds with their own looks, bulk, speed, damage and weapon: acid spitters lob green globs, rock slingers throw stones, brutes hit harder and take more punishment, and the swift and dire bats fight differently. Slimes rear back and slam with both arms; bats fold into a dive and rake with their claws. Flying mobs cross open water, and any of them can climb aboard and fight on deck — knocked-off boarders still fall and swim.

## Graphics quality and low-RAM machines

The renderer picks one of three profiles before it is created, by reading the unmasked WebGL renderer string from a throwaway 1x1 context: **SOFTWARE GPU** (SwiftShader, llvmpipe, Mesa offscreen, Microsoft Basic Render), **LOW POWER** (the existing `tt` test: four or fewer logical cores, four or fewer GB of reported device memory, or a narrow viewport) and **FULL**. Each profile sets a framebuffer budget (2.1 / 1.15 / 0.52 megapixels) and an adaptive render-scale floor (0.68 / 0.60 / 0.45); software rendering also turns MSAA off.

Frame rate is watched only during gameplay, never in menus, the death cinematic or a throttled background tab. A machine that stays under 40 fps at its lowest render scale drops to the cheap shading path: diffuse PBR materials are converted to Blinn-Phong (same colour, texture, emissive, transparency, side, flat shading and alpha test; metallic and custom-shader materials are left alone), and `body.perf-low` removes `backdrop-filter` blurs from the HUD, menus and touch buttons. Nothing is hidden, disabled or removed from the game — the same meshes, effects, timers and rules run in every profile.

The title card has a **GRAPHICS** selector (`AUTO`, `HIGH`, `PERFORMANCE`, saved in `localStorage` and applied live). AUTO only degrades hardware that is actually slow; `window.hwPerformance()` returns the detected GPU string, profile, shading path and current render scale, and the debug panel shows the same line.

## Death effects and the classic arsenal

Defeated mobs, fishermen, crew and fish finish their death animation (fall-and-roll, collapse, overboard drowning, or the new belly-up fish roll) and then leave a Minecraft-style puff of smoke instead of vanishing. Puffs, blast sprites and the rocket/BFG/plasma effects are pooled in `death-effects.js`, which is embedded by `tools/build.js`; textures live in `assets/particles/` and weapon recordings in `assets/audio/weapons/`.

Weapon behaviour follows the original Doom mechanics: the rocket launcher and BFG do not autofire, the BFG spends 40 cells and sprays 40 tracers across a 90° fan for 15–120 damage each, the shotgun fires 7 pellets and the super shotgun 20 at its wider spread, and shot-to-shot timings match the original 35 Hz weapon state durations. New CC0 credits and adaptations: `assets/licenses/death-fx.md`.

See `CHANGES.md` for details and validation results; `assets/README.md` and `assets/licenses/` document original and freely licensed resources. Temporary tests are not shipped.

### Turret rotation synchronization

The embedded Object3D quaternion-change callback in `main.js` must call `rotation.setFromQuaternion(quaternion, undefined, false)`. The second argument is the Euler order, not the notification flag. Passing `false` as the second argument breaks cloned-object rotation: numeric yaw/pitch can change while rendered quaternions remain fixed. When validating turrets, inspect actual world-space barrel directions and rendered target tracking, not just Euler values.

### Destruction effects and performance

Water never blocks gunfire, projectiles or punches; crossing the surface only adds a splash. Hired Gill hull and crew are friendly and cannot be damaged or provoked, but their breakable equipment can be shot; no hit on hired gear ever raises their alarm and their mechanic still repairs it. Cabin settees, chairs, desks and cabinets are separate damageable equipment, not hull. Non-combatant crew panic under repeated player hits, flee, then recover and resume work. Breakable equipment has no floating HP or rebuild bars; enemy/player health and the boat engagement HUD remain. Glass, wood, metal, stone, earth, flesh and fabric use distinct locally bundled CC0 hit sounds, and destruction uses separate CC0 break sounds, alongside short-lived pooled debris/dust; boarding planks also splinter when destroyed. Repairs and gameplay effects are unchanged.

`breakage.js` uses two reusable instanced batches with lower limits on low-power devices, a per-frame burst budget, distance culling and an idle fast path. It reuses the CC0 Kenney smoke/spark sprites. Equipment uses indexed lookups, allocation-light repair selection and conservative shot broad-phase rejection before exact intersections. These optimizations retain the existing cover, ammo, crew and turret rules.
