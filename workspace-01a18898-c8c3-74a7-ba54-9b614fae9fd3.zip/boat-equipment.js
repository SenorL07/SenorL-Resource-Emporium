// Independent fleet equipment. Runtime state lives outside userData so Three clones
// never serialize boat/actor references, and model templates never share HP.
var EMPTY_EQUIPMENT=Object.freeze([]);
var boatEquipment=new Map(),equipmentRoots=new WeakMap(),equipmentWorkers=new Map(),riverMechanic=null,hiredMechanic=null;
const EQUIPMENT_RULES={door:[90,10,18],engine:[130,16,24],gun:[160,14,30],autogun:[140,12,24],ammo:[75,10,16],net:[45,6,12],radar:[65,9,18],window:[28,4,6],winch:[65,8,14],seat:[90,10,16],prop:[60,8,14]};
function crewHomeBoat(actor){if([Fs,St,riverMechanic,...riverReinforcements].includes(actor))return it;if([ei,hiredMechanic,...Yi,...J0].includes(actor))return ze;if([Wt,gr,Ut,...mr,...Za].includes(actor))return ge;return null}
function boatComponentFor(object){for(let n=object;n;n=n.parent){const s=equipmentRoots.get(n);if(s)return s}return null}
function equipmentRoster(boat){return boat===it?riverCrew():boat===ze?hiredCrew():[Wt,gr,Ut,...mr,...Za]}
function equipmentParts(boat,type){const d=boatEquipment.get(boat);return (type?d?.byType.get(type):d?.parts)||EMPTY_EQUIPMENT}
function equipmentIntact(boat,id){const p=boatEquipment.get(boat)?.byId.get(id);return !p||p.hp>0}
function boatAmmoAvailable(boat){const crates=equipmentParts(boat,'ammo');return !crates.length||crates.some(s=>s.hp>0)}
function crewCanRespawn(actor,boat){return actor.userData.crewRole==='mechanic'||equipmentIntact(boat,'door')}
function equipmentSpeed(boat){const motors=equipmentParts(boat,'engine');return !motors.length?1:motors.reduce((n,p)=>n+(p.hp>0?Math.max(.25,p.hp/p.maxHp):0),0)/motors.length}
function equipmentGunAvailable(boat,mount){const p=boatEquipment.get(boat)?.byId.get(mount.id);return !p||p.hp>0}
function fishingAvailable(boat,id='net-0'){return equipmentIntact(boat,id)&&equipmentIntact(boat,'winch')}
function equipmentRadarAvailable(boat){return equipmentParts(boat,'radar').every(p=>p.hp>0)}
function equipmentRegister(boat){
 const model=boat.userData.fleetModel;if(!model)return;let data=boatEquipment.get(boat);if(data?.model===model)return;
 if(data)for(const p of data.parts){if(p.wreck){p.wreck.removeFromParent();p.wreck.geometry.dispose();p.wreck.material.dispose()}equipmentRoots.delete(p.root)}
 for(const [a,j]of equipmentWorkers)if(j.boat===boat){equipmentWorkers.delete(a);a.userData.equipmentJob=null}
 data={model,parts:[],byType:new Map(),byId:new Map()};boatEquipment.set(boat,data);
 const register=(root,id,type,service=null)=>{if(!root)return;const rule=EQUIPMENT_RULES[type]||EQUIPMENT_RULES.prop;root.visible=true;root.userData.componentId=id;root.userData.componentType=type;
  const box=new bm.Box3().setFromObject(root),center=box.isEmpty()?root.getWorldPosition(new w()):box.getCenter(new w()),anchor=boat.worldToLocal(center),side=anchor.x<0?-1:1;
  const goal=service||new w(side*1.18,.38,he.clamp(anchor.z,-2.2,1.8));
  const p={boat,root,id,type,hp:rule[0],maxHp:rule[0],repairSeconds:rule[1],rebuildSeconds:rule[2],anchor:anchor.clone(),service:crewNavigationPost(bm,goal),lastHit:-100,rebuildProgress:0};data.parts.push(p);data.byId.set(id,p);if(!data.byType.has(type))data.byType.set(type,[]);data.byType.get(type).push(p);
  const scale=boat.matrixWorld.getMaxScaleOnAxis()||1,pivot=root.getWorldPosition(new w());p.broadCenter=boat.worldToLocal(pivot.clone());p.broadRadius=(box.getSize(new w()).length()*.5+center.distanceTo(pivot))/scale+1.5;equipmentRoots.set(root,p);
  root.traverse(n=>{if(n.isMesh&&!/flash|muzzle/i.test(n.name)){n.userData.noBulletHit=false;n.userData.noLOSBlock=true}});
 };
 const defs=[];model.traverse(n=>{if(n.userData.componentType)defs.push(n)});for(const node of defs){const type=node.userData.componentType,id=node.userData.componentId;let service=null;
  if(type==='gun'){const m=model.userData.mountSpecs?.find(m=>m.id===id);if(m)service=new w(...m.seat)}
  if(type==='autogun')service=new w(.10,.38,-1.05);register(node,id,type,service)}
 register(ng(boat),'door','door',new w(.10,.38,-1.05));
 let engines=boat.children.filter(n=>n.name==='outboard');engines.forEach((n,i)=>register(n,'engine-'+i,'engine',new w(Math.sign(n.position.x||1)*1.18,.38,-2.2)));
 const fittings=boat.children.filter(n=>n.name.startsWith('equipment-'));for(const n of fittings)register(n,n.name==='equipment-winch'?'winch':n.name,n.name==='equipment-winch'?'winch':'prop');
 const windows=[];if(!boat.userData.windowsFromModel)boat.traverse(n=>{if(n.userData.boatWindow)windows.push(n)});for(const n of windows)register(n,n.userData.boatWindow,'window',new w(n.position.x===0?0:Math.sign(n.position.x)*1.18,.38,n.position.x===0?.85:-.5));
 if(boat!==it){if(boat===ge)register(an,'net-0','net',new w(1.18,.38,.85));else Z0.forEach((n,i)=>register(n.net,'net-'+i,'net',new w(i%2?1.18:-1.18,.38,he.clamp(n.home.z,-2.2,1.8))))}
 // Every armed vessel needs a real destructible supply, even older hull variants.
 if(!data.parts.some(p=>p.type==='ammo')){let root=boat.getObjectByName('Equipment ammunition locker');if(!root){root=new gt();root.name='Equipment ammunition locker';root.position.set(.65,.56,-2.17);const box=new Me(new Ot(.46,.36,.42),ht('#647457'));box.castShadow=true;root.add(box);const strap=new Me(new Ot(.48,.045,.08),ht('#d5c8a3'));strap.position.y=.18;root.add(strap);boat.add(root)}register(root,'ammo-reserve','ammo')}
 boat.updateWorldMatrix(true,true);
}
function resetBoatEquipment(boat){for(const p of equipmentParts(boat)){p.hp=p.maxHp;p.rebuildProgress=0;p.root.visible=true;p.root.userData.charred=false;p.wreck&&(p.wreck.visible=false)}boat.userData.passageOwner=null}
function equipmentDamage(object,amount,source='player'){const p=boatComponentFor(object);if(!p)return false;if(!p.boat.visible||p.hp<=0)return true;
 p.hp=Math.max(0,p.hp-Math.max(0,amount));p.lastHit=Mt;p.rebuildProgress=0;// Hired Gill equipment breaks on player hits, but never counts as combat hostility.
 if(source==='player'&&p.boat!==ze){notifyPlayerBoatHit(p.boat);p.boat.userData.playerCombatUntil=Mt+25;if(p.boat===ge)jr=true;else if(p.boat===it)Gc=true;}
 if(!p.hp){emitEquipmentBreak(p);p.root.visible=false;burnSystem?.extinguish(p.root,true);if(!p.wreck){const kind=equipmentBreakMaterial(p),mesh=new Me(new Ot(.34,kind==='glass'?.018:kind==='fabric'?.012:.065,.20),ht(kind==='glass'?'#94c5c7':kind==='wood'?'#684326':kind==='fabric'?'#718778':'#363a36'));mesh.name='Broken '+p.type+' remains';mesh.userData.noBulletHit=mesh.userData.noLOSBlock=true;mesh.position.copy(p.anchor);if(p.type==='door'||p.type==='window')mesh.position.y=.43;mesh.rotation.z=.18;mesh.rotation.y=.5;p.boat.add(mesh);p.wreck=mesh}p.wreck.visible=true;
  for(const [a,s]of mountedWeaponSystem?.assignments||[])if(s.boat===p.boat&&s.mount.id===p.id)mountedWeaponSystem.release(a);
  if(p.type==='door'){const door=ng(p.boat);door.userData.angle=door.userData.target=1.34;p.boat.userData.passageOwner=null}
  if(p.type==='net'){if(p.boat===ge)Yd();else for(const action of [...pi])if(action.net===p.root)abortDestroyedNet(action);p.root.visible=false}
  if(p.type==='ammo'&&!boatAmmoAvailable(p.boat))for(const actor of equipmentRoster(p.boat))if(actor.userData.magazine?.rounds<=0){actor.userData.reloading=false;actor.userData.magazine.until=0}

 }
 combatRayCache.time=-1;return true;
}
function makeEquipmentMechanic(boat,name){const actor=HI(false);actor.name=name;actor.userData.crewRole='mechanic';actor.userData.hp=actor.userData.maxHp=100;actor.userData.fleetBaseScale=actor.scale.clone();actor.scale.multiplyScalar(1/(boat.userData.hullFactor||1));for(const n of ['crew-rifle','crew-rifle-barrel'])actor.getObjectByName(n)?.removeFromParent();actor.userData.flash&&(actor.userData.flash.visible=false);boat.add(actor);Bd(actor,1.18,.38,-.85);sinkingCrewRig(actor);addCrewRenderActor(actor);return actor}
function ensureFleetMaintenance(boat){if(boat===it&&!riverMechanic)riverMechanic=makeEquipmentMechanic(it,'River maintenance engineer');if(boat===ze&&U.gillTycoonHired&&!hiredMechanic)hiredMechanic=makeEquipmentMechanic(ze,'Hired Gill maintenance engineer');if(boat===ge&&Qt&&(!Li||handoverCrewNeeded()))gr.visible=true}
// A hull that is up for hire stands its crew down, engineer included, and a hireable hull
// never respawns them. That is fine while it is parked, but the approach and the handover
// both need the hull under its own power, so those two states keep the crew awake.
function handoverCrewNeeded(){return Kt==='entering'||Kt==='hiredDocking'}
// Hiring a hull that was shot to pieces in the fight has to be able to fix itself: the
// engineer is woken (a merely un-hidden one that was knocked out would sit out the whole
// handover) and put back on duty so the boat can be repaired enough to reach the berth.
function wakeHandoverEngineer(boat){
  ensureFleetMaintenance(boat);
  const actor=boat===ge?gr:boat===it?riverMechanic:hiredMechanic;
  if(!actor)return null;
  const u=actor.userData;
  equipmentWorkers.delete(actor);u.equipmentJob=null;u.repairing=false;u.taskRoute=null;
  if(boat===ge){Wc=false;Qm=Math.max(Qm||0,92)}
  if(u.defeated||u.spawning){u.respawnAt=0;u.hitStunUntil=0;u.postRecovery=false;beginCabinRespawn(actor,boat,new w(1.18,.38,-.85),u.maxHp||100)}
  else actor.visible=true;
  return actor;
}
function equipmentMaintenanceActors(boat){return (boat===ge?[gr]:boat===it?[riverMechanic,...riverReinforcements]:[hiredMechanic]).filter(a=>a&&a.userData.crewRole==='mechanic')}
function equipmentInteriorPart(p){const a=p.anchor;return Math.abs(a.x)<1.02&&a.z>-.5&&a.z<.92&&a.y<2.2}
function updateBoatEquipment(dt){for(const boat of [ge,it,ze]){
 const enabled=boat.visible&&(boat===ge?Qt&&Kt!=='sinking':boat===it?On&&Wn!=='sinking':U.gillTycoonHired&&fi!=='disabled');if(!enabled)continue;
 ensureFleetMaintenance(boat);
 const parts=equipmentParts(boat);const sleeping=!!boat.userData.restState&&restRoster(boat).some(a=>a.userData.sleeping||a.userData.restStage==='lying');
 for(const p of parts){
  if(p.type==='radar'&&p.hp>0)p.root.rotation.y+=dt*2.8;
  if(!p.hp){p.root.visible=false;continue}
  // Stowed while the cabin is full of sleeping crew: beds need the floor space,
  // and nothing here is damageable while it is packed away.
  if(sleeping&&(p.type==='prop'||p.type==='seat'||p.type==='winch')&&equipmentInteriorPart(p)){p.root.visible=false;p.stowed=true;continue}
  if(p.stowed){p.root.visible=true;p.stowed=false}
 }
 for(const actor of equipmentMaintenanceActors(boat)){
  const u=actor.userData;let job=equipmentWorkers.get(actor);
  if(u.defeated&&Mt>=(u.respawnAt||Infinity)){if(actor===gr){Wc=false;Qm=92}beginCabinRespawn(actor,boat,new w(1.18,.38,-.85),u.maxHp||100);}
  if(!crewReady(actor)||actor.parent!==boat||u.resting||u.sleeping||u.firefighting||u.panicking||u.hitStunUntil>performance.now()||u.postRecovery){equipmentWorkers.delete(actor);u.equipmentJob=null;u.repairing=false;continue}
  if(job&&(job.part.hp>=job.part.maxHp||!parts.includes(job.part))){equipmentWorkers.delete(actor);u.equipmentJob=null;job=null}
  // Handing the hull over to its new owner: motors first, because nothing else gets the
  // boat to the berth. Every other job keeps its normal order afterwards.
  const handover=boat===ge&&Kt==='hiredDocking';
  const priority=p=>handover&&p.type==='engine'?-20:(p.hp>0?15:0)+({door:0,engine:1,ammo:2,gun:3,net:4,radar:5,window:6,prop:7}[p.type]??8);
  // Select only damaged, unclaimed work. No per-worker filtered arrays or sorts.
  let wanted=null,wantedPriority=Infinity;for(const p of parts){if(p.hp>=p.maxHp)continue;const rank=priority(p);if(rank>=wantedPriority)continue;let claimed=false;for(const [other,work]of equipmentWorkers)if(other!==actor&&work.part===p){claimed=true;break}if(!claimed){wanted=p;wantedPriority=rank}}
  if(wanted&&(!job||priority(wanted)<priority(job.part))){job={boat,part:wanted,path:planBoatCrewRoute(bm,boat,actor.position,wanted.service)};equipmentWorkers.set(actor,job);u.equipmentJob={id:wanted.id,path:job.path};u.taskRoute=null;u.deckTransit=null;boardingDefense?.reset(actor);mountedWeaponSystem?.release(actor)}
  if(!job)continue;const p=job.part;if(actor.position.distanceTo(p.service)>.07){if(!job.path.length)job.path.push(...planBoatCrewRoute(bm,boat,actor.position,p.service));stepBoatCrewRoute(actor,boat,job.path,dt,1.05);continue}
  u.repairing=true;actor.rotation.y=Math.atan2(p.anchor.x-actor.position.x,p.anchor.z-actor.position.z);const rig=sinkingCrewRig(actor);rig.legs.forEach(l=>l.rotation.x=0);rig.arms.forEach((arm,i)=>arm.rotation.x=-1+Math.sin(Mt*9+i)*.15);
  if(p.hp<=0){p.rebuildProgress+=dt;if(p.rebuildProgress>=p.rebuildSeconds){p.hp=p.maxHp;p.rebuildProgress=0;p.root.userData.charred=false;p.root.visible=true;p.wreck&&(p.wreck.visible=false);combatRayCache.time=-1;It('repair',{position:actor.getWorldPosition(new w()),volume:.25});}}
  else p.hp=Math.min(p.maxHp,p.hp+dt*p.maxHp/p.repairSeconds);
  if(Mt>=(u.equipmentSparkAt||0)){u.equipmentSparkAt=Mt+.7;Wo(actor.localToWorld(new w(0,.9,.4)),new w(0,.4,0),'spark');It('repair',{position:actor.getWorldPosition(new w()),volume:.12,key:'equipment-repair-'+actor.id,cooldown:650})}
  if(p.hp>=p.maxHp){u.repairing=false;equipmentWorkers.delete(actor);u.equipmentJob=null}
 }
 // Supply is bound to the home boat, never the boat an invader currently stands on.
 for(const actor of equipmentRoster(boat)){actor.userData.ammoSupplyAvailable=boatAmmoAvailable(boat);if(!actor.userData.magazine&&actor.userData.ammoSupplyAvailable&&actor.userData.crewRole!=='mechanic')actor.userData.magazine={rounds:9,capacity:9,until:0,duration:2.8};if(!actor.userData.ammoSupplyAvailable&&actor.userData.magazine?.rounds<=0)actor.userData.reloading=false;const unarmed=crewNeedsFists(actor);if(unarmed!==actor.userData.equipmentUnarmed){actor.userData.equipmentUnarmed=unarmed;for(const name of ['crew-rifle','crew-rifle-barrel']){const mesh=actor.getObjectByName(name);if(mesh)mesh.visible=!unarmed&&!actor.userData.usesMount}if(actor.userData.gun)actor.userData.gun.visible=!unarmed&&!actor.userData.usesMount}}
}}
function crewNeedsFists(actor){return actor.userData.ammoSupplyAvailable===false&&(!actor.userData.magazine||actor.userData.magazine.rounds<=0)}
function crewFistAttack(actor,target){if(target?.actor===oe&&U.gillTycoonHired&&crewHomeBoat(actor)===ze)return false;if(!target||!crewReady(actor)||actor.userData.hitStunUntil>performance.now())return false;const u=actor.userData,from=actor.localToWorld(new w(0,.9,.2));if(from.distanceTo(target.position)>2.2||!Jc(from,target.position,actor,target.actor))return false;if(Mt<(u.fistNext||0))return false;u.fistNext=Mt+.7;const rig=sinkingCrewRig(actor);rig.arms.forEach((a,i)=>a.rotation.x=i?-1.4:-.9);It('cloth',{position:from,volume:.2});if(target.actor===oe)j0(7,actor);else {target.damage(7,actor);playMaterialImpact(target.actor,target.position);meleeImpact(target.actor,target.position,'npc')}Wo(target.position,new w(0,.4,0),'spray');return true}


function hostilePlayerAboard(boat){if(boat===ze&&U.gillTycoonHired)return false;return playerAboardForAlarm(boat)&&(boatAlertMobilized(boat)||(boat===ge?jr:boat===it?Gc:false)||Mt<(boat.userData.playerCombatUntil||0))}
function playerTurretFallback(boat,actor){
 if(!hostilePlayerAboard(boat))return false;const u=actor.userData,point=oe.position.clone().add(new w(0,-.15,0));
 if(Jc(actor.localToWorld(new w(0,1.05,0)),point,actor,oe))u.noticedPlayerUntil=Mt+3;
 if(Mt>=(u.noticedPlayerUntil||0))return false;if(crewNeedsFists(actor))return true;
 const assignment=mountedWeaponSystem?.assignments.get(actor),mounts=assignment?[assignment.mount]:mountedWeaponSystem?.getMounts(boat).filter(m=>!m.operator)||[];
 const effective=mounts.some(m=>equipmentGunAvailable(boat,m)&&mountedWeaponSystem.aimSolution(boat,m,weaponTargetPlayer())?.inArc&&Jc(m.muzzles[0].getWorldPosition(new w()),point,actor,oe));return !effective;
}

function abortDestroyedNet(action){if(action.finished)return;action.finished=true;J_(action);action.net.position.copy(action.netHome);action.net.visible=false;action.tether.visible=false;pi=pi.filter(p=>p!==action);if(action.fisher.parent===ze&&!action.fisher.userData.defeated)action.fisher.userData.deckTransit=planBoatCrewRoute(bm,ze,action.fisher.position,crewNavigationPost(bm,action.homePos))}

// Resolve real cover before applying a fleet shot to its intended crew/hull target.
var equipmentShotRoots=[],equipmentShotHits=[],equipmentShotCenter=new w(),equipmentShotRay=new kr();
function fleetEquipmentShot(from,to,damage,actor){
 const distance=from.distanceTo(to);if(distance<.1)return null;
 const assignment=mountedWeaponSystem?.assignments.get(actor),mount=assignment?.boat.userData.fleetModel?.getObjectByName(assignment.mount.id+'-base');
 const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z,length2=distance*distance;equipmentShotRoots.length=equipmentShotHits.length=0;
 for(const [boat,data]of boatEquipment){if(!boat.visible)continue;boat.updateWorldMatrix(true,false);const scale=boat.matrixWorld.getMaxScaleOnAxis();
  for(const p of data.parts){if(p.hp<=0||!p.root.visible||p.root===mount)continue;
   // Conservative pivot-centered bounds include door swing and gun articulation.
   // Fishing nets move relative to their hull, so always use their exact meshes.
   if(p.type!=='net'){equipmentShotCenter.copy(p.broadCenter).applyMatrix4(boat.matrixWorld);const c=equipmentShotCenter,t=he.clamp(((c.x-from.x)*dx+(c.y-from.y)*dy+(c.z-from.z)*dz)/length2,0,1),x=from.x+dx*t-c.x,y=from.y+dy*t-c.y,z=from.z+dz*t-c.z,r=p.broadRadius*scale;if(x*x+y*y+z*z>r*r)continue}
   p.root.updateWorldMatrix(true,true);equipmentShotRoots.push(p.root);
  }
 }
 equipmentShotRay.set(from,equipmentShotCenter.copy(to).sub(from).normalize());equipmentShotRay.near=.08;equipmentShotRay.far=distance-.08;
 equipmentShotRay.intersectObjects(equipmentShotRoots,true,equipmentShotHits);
 for(const hit of equipmentShotHits){let visible=true;for(let n=hit.object;n;n=n.parent)if(!n.visible){visible=false;break}if(!visible||hit.object.userData.noBulletHit)continue;const p=boatComponentFor(hit.object);if(!p||!p.hp)continue;playMaterialImpact(hit.object,hit.point);equipmentDamage(p.root,damage,'npc');Wo(hit.point,new w(0,.3,0),'spark');return hit}return null;
}

function usableTurretForTarget(boat,actor,target){if(!target||crewNeedsFists(actor))return false;const assignment=mountedWeaponSystem?.assignments.get(actor),mounts=assignment?[assignment.mount]:mountedWeaponSystem?.getMounts(boat).filter(m=>!m.operator)||[];return mounts.some(m=>equipmentGunAvailable(boat,m)&&mountedWeaponSystem.aimSolution(boat,m,target)?.inArc&&Jc(m.muzzles[0].getWorldPosition(new w()),target.position,actor,target.actor))}
