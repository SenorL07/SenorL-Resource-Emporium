// Repeated player hits make non-combatants drop their work, flee, then recover.
var crewPanicActors=[];
function crewCombatRole(actor){const u=actor?.userData||{};return ['gunner','guard'].includes(u.crewRole)||u.usesMount||u.boarding||actor===St||actor===Ut||mr.includes(actor)||J0.includes(actor)}
function crewPanicAllowed(actor){
 const u=actor?.userData;if(!actor||!u||!actor.visible||u.defeated||u.overboard||u.sinking||u.burning||u.firefighting||u.resting||u.sleeping||u.spawning)return false;
 const boat=actor.parent;if(![ge,it,ze].includes(boat)||!boat.visible)return false;
 if(u.crewRole==='driver'||u.crewRole==='gunner'||u.crewRole==='guard')return false;
 return !crewCombatRole(actor);
}
function crewPanicking(actor){return !!actor?.userData?.panicUntil&&Mt<actor.userData.panicUntil}
function crewPanicSpot(actor,boat){
 const local=boat.worldToLocal(oe.position.clone()),candidates=[];
 for(const x of [-1.18,0,1.18])for(const z of [-2.1,-1.3,.6,1.4,2.0])candidates.push(new w(x,.38,z));
 if(Math.abs(local.x)<.9&&local.z> -.2)candidates.push(new w(0,.38,-2.15));
 let best=null,score=-Infinity;
 for(const point of candidates){const d=point.distanceTo(local);const scoreHere=d-(fleetDeckContains(boat.userData.deckOutline,point.x,point.z,0)?0:40);if(scoreHere>score){score=scoreHere;best=point}}
 return crewNavigationPost(bm,best||new w(0,.38,2));
}
function startCrewPanic(actor){
 const u=actor.userData,boat=actor.parent;
 u.panicking=true;u.panicUntil=Mt+7+Math.random()*4;u.panicHits=0;u.panicGoal=crewPanicSpot(actor,boat);u.panicPath=planBoatCrewRoute(bm,boat,actor.position,u.panicGoal);
 u.repairing=false;u.equipmentJob=null;u.taskRoute=null;u.deckTransit=null;
 equipmentWorkers.delete(actor);mountedWeaponSystem?.release(actor);boardingDefense?.reset(actor);
 if(!crewPanicActors.includes(actor))crewPanicActors.push(actor);
 AudioRuntime.npcVoice(actor,'alert','human',Mt);
}
function crewPanicHit(actor){
 if(!crewPanicAllowed(actor))return false;const u=actor.userData;
 if(Mt-(u.panicLastHit||-100)>7)u.panicHits=0;
 u.panicHits=(u.panicHits||0)+1;u.panicLastHit=Mt;
 if(u.panicHits>=3&&!crewPanicking(actor)){startCrewPanic(actor);return true}
 return false;
}
function calmCrewPanic(actor){
 const u=actor?.userData;if(!u)return;u.panicking=false;u.panicUntil=0;u.panicGoal=null;u.panicPath=null;u.panicHits=0;
 const index=crewPanicActors.indexOf(actor);if(index>=0)crewPanicActors.splice(index,1);
}
function updateCrewPanic(dt){
 for(let i=crewPanicActors.length-1;i>=0;i--){
  const actor=crewPanicActors[i];if(!actor?.parent){calmCrewPanic(actor);continue}
  const u=actor.userData,boat=actor.parent;
  if(!crewPanicAllowed(actor)||Mt>=u.panicUntil){calmCrewPanic(actor);continue}
  if(actor.position.distanceTo(u.panicGoal)>.28){
   if(!u.panicPath?.length)u.panicPath=planBoatCrewRoute(bm,boat,actor.position,u.panicGoal);
   stepBoatCrewRoute(actor,boat,u.panicPath,dt,1.45);
  }else{
   const target=boat.worldToLocal(oe.position.clone()),here=actor.position;
   actor.rotation.y=Math.atan2(target.x-here.x,target.z-here.z)+Math.PI;
  }
  const rig=sinkingCrewRig(actor),moving=actor.position.distanceTo(u.panicGoal)>.28;
  rig.arms.forEach((arm,index)=>arm.rotation.x=-2.45+Math.sin(Mt*13+index*1.7)*.14);
  rig.legs.forEach((leg,index)=>leg.rotation.x=moving?Math.sin(Mt*11+index*Math.PI)*.4:0);
  actor.rotation.z=moving?0:Math.sin(Mt*9)*.045;
 }
}
