// The opened cabin leaf occupies z down to -2.32. Clear it before turning sideways.
export function crewNavigationPost(T,p){const q=p.clone();if(q.y<1.3){q.y=.38;if(Math.abs(q.x)>1.20)q.x=Math.sign(q.x)*1.18;q.z=Math.max(-2.48,Math.min(1.90,q.z))}return q}
export function planBoatCrewRoute(T,boat,from,destination){
 const to=crewNavigationPost(T,destination);if(from.y<1.3&&to.y<1.3){const angle=boat.getObjectByName('cabinDoorPivot')?.userData.angle||0;if(angle<1.23&&Math.abs(from.x)<.6&&from.z< -1.71&&from.z> -2.44){const stage=new T.Vector3(from.x,.38,-2.48);return [stage,...crewGroundRoute(T,boat,stage,to)]}return crewGroundRoute(T,boat,from,to)}
 const inside=p=>p.y<1.3&&Math.abs(p.x)<.86&&p.z> -1.62&&p.z<.28,sourceInside=inside(from),targetInside=inside(to),levels=boat.userData.fleetModel?.userData.roofLevels||[2.10],side=sourceInside&&Math.abs(to.x)>.85?Math.sign(to.x):from.x<0?-1:1,z=-.95,low=levels[0],high=levels.at(-1),v=(x,y)=>new T.Vector3(side*x,y,z),exit=x=>new T.Vector3(x,.38,-2.48),path=[];
 let start=from.clone();
 if(sourceInside&&!targetInside){path.push(new T.Vector3(.10,.38,Math.min(-.6,from.z)),exit(.10),exit(side*1.18));start=exit(side*1.18)}
 const lowerLadder=Math.abs(Math.abs(start.x)-1.32)<.18&&Math.abs(start.z-z)<.18&&start.y>.48&&start.y<low-.04,upperLadder=Math.abs(Math.abs(start.x)-.88)<.18&&Math.abs(start.z-z)<.18&&start.y>low+.04&&start.y<high-.04;
 if(lowerLadder&&Math.abs(start.y-to.y)>.18)path.push(v(1.32,.38));
 else if(upperLadder&&Math.abs(start.y-to.y)>.18)path.push(v(.88,low),v(1.32,low),v(1.32,.38));
 else if(start.y>1.3&&Math.abs(start.y-to.y)>.18){if(start.y>low+.3&&high>low+.3)path.push(v(.45,high),v(.88,high),v(.88,low));path.push(v(.88,low),v(1.32,low),v(1.32,.38))}
 if(to.y>1.3&&Math.abs(start.y-to.y)>.18){path.push(new T.Vector3(side*1.18,.38,z),v(1.32,.38),v(1.32,low),v(.88,low));if(to.y>low+.3&&high>low+.3)path.push(v(.88,high),v(.45,high))}
 const approach=path.at(-1)||start;
 if(targetInside&&!sourceInside){if(approach.y<1.3&&Math.abs(approach.x)<1.125&&approach.z>.58)path.push(new T.Vector3(side*1.18,.38,approach.z));path.push(exit(side*1.18),exit(.10),new T.Vector3(.10,.38,Math.min(-.6,to.z)))}
 else if(!targetInside&&to.y<1.3&&approach.y<1.3){
  if(approach.x*to.x<0&&Math.min(approach.z,to.z)<.58)path.push(exit(Math.sign(approach.x)*1.18),exit(Math.sign(to.x)*1.18));
  else if(Math.abs(approach.x)<.8&&approach.z< -1.62&&approach.z> -2.4)path.push(exit(approach.x),exit((to.x<0?-1:1)*1.18));
  const last=path.at(-1)||approach;
  if(to.z>.58&&Math.abs(to.x)<1.125&&last.z<.58&&Math.abs(last.x)>.85)path.push(new T.Vector3(Math.sign(last.x)*1.18,.38,to.z));
  else if(Math.abs(last.x)<1.125&&last.z>.58&&Math.abs(to.x)>.85&&to.z<.58)path.push(new T.Vector3(Math.sign(to.x)*1.18,.38,last.z));
 }
 path.push(to);const result=[];let previous=from;for(const point of path){if(previous.y<.48&&point.y<.48&&!(Math.abs(point.z+.95)<.02&&Math.abs(previous.z+.95)<.02&&Math.max(Math.abs(previous.x),Math.abs(point.x))>1.21))result.push(...crewGroundRoute(T,boat,previous,point));else if(point.distanceTo(previous)>.015)result.push(point);previous=point}return result;
}

// Visibility graph in feet-space, using the same cabin panels and body clearance as
// collision. The leaf is planned fully open; the passage gate waits for that pose.
function crewGroundRoute(T,boat,from,to){
 const radius=.145,rects=[[-.995,-.905,-1.49,.38],[.905,.995,-1.49,.38],[-.995,.995,.285,.385],[-.995,-.42,-1.575,-1.435],[.36,.995,-1.575,-1.435],...(boat.userData.fleetBlocks||[]).filter(b=>b.y0<1.58&&b.y1>.41).map(b=>b.rect)],c=Math.cos(1.34),s=Math.sin(1.34),door=p=>({x:(p.x+.42)*c-(p.z+1.535)*s,z:(p.x+.42)*s+(p.z+1.535)*c}),leaf=[-radius,.78+radius,-.0375-radius,.0375+radius];
 const boxes=rects.map(r=>[r[0]-radius,r[1]+radius,r[2]-radius,r[3]+radius]),contains=(p,r)=>p.x>r[0]&&p.x<r[1]&&p.z>r[2]&&p.z<r[3];
 function intersects(a,b,r){let lo=0,hi=1;for(const [axis,min,max]of [['x',r[0],r[1]],['z',r[2],r[3]]]){const delta=b[axis]-a[axis];if(Math.abs(delta)<1e-9){if(a[axis]<=min||a[axis]>=max)return false}else{let l=(min-a[axis])/delta,h=(max-a[axis])/delta;if(l>h)[l,h]=[h,l];lo=Math.max(lo,l);hi=Math.min(hi,h);if(lo>=hi)return false}}return hi>1e-6&&lo<1-1e-6}
 const valid=p=>Math.abs(p.x)<=1.205&&p.z>=-2.49&&p.z<=1.915&&!boxes.some(r=>contains(p,r))&&!contains(door(p),leaf);
 function blocked(a,b,r){if(!intersects(a,b,r))return false;if(contains(a,r)){const edges=[a.x-r[0],r[1]-a.x,a.z-r[2],r[3]-a.z],min=Math.min(...edges),i=edges.indexOf(min);if(min<.027&&[b.x<r[0],b.x>r[1],b.z<r[2],b.z>r[3]][i])return false}return true}
 const clear=(a,b)=>!boxes.some(r=>blocked(a,b,r))&&!blocked(door(a),door(b),leaf);
 const start=crewNavigationPost(T,from);start.y=.38;const nodes=[start,to.clone()];
 for(const x of [-1.18,1.18])for(const z of [-2.48,-1.75,-.95,.62,1.45,1.90])nodes.push(new T.Vector3(x,.38,z));
 for(const x of [-.68,.10,.68])for(const z of [-2.48,-2.05,-1.12,-.55,.10,.62,1.45])nodes.push(new T.Vector3(x,.38,z));
 for(const r of boxes)for(const x of [r[0]-.012,r[1]+.012])for(const z of [r[2]-.012,r[3]+.012]){const p=new T.Vector3(x,.38,z);if(valid(p))nodes.push(p)}
 for(const x of [leaf[0]-.012,leaf[1]+.012])for(const z of [leaf[2]-.012,leaf[3]+.012]){const p=new T.Vector3(-.42+x*c+z*s,.38,-1.535-x*s+z*c);if(valid(p))nodes.push(p)}
 if(clear(start,to))return [to.clone()];
 const dist=nodes.map(()=>Infinity),prev=nodes.map(()=>-1),done=new Set();dist[0]=0;
 for(let count=0;count<nodes.length;count++){let best=-1;for(let i=0;i<nodes.length;i++)if(!done.has(i)&&(best<0||dist[i]<dist[best]))best=i;if(best<0||!Number.isFinite(dist[best]))break;if(best===1){const path=[];for(let at=1;at>0;at=prev[at])path.unshift(nodes[at].clone());if(from.distanceTo(start)>.02)path.unshift(start);return path}done.add(best);for(let j=1;j<nodes.length;j++)if(!done.has(j)&&valid(nodes[j])&&clear(nodes[best],nodes[j])){const d=dist[best]+nodes[best].distanceTo(nodes[j]);if(d<dist[j]){dist[j]=d;prev[j]=best}}}
 // Keep an unreachable job pending rather than declaring success or crossing a wall.
 return [start,to.clone()];
}
