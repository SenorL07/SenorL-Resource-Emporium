// Shared, bounded burning status for player, humans, dungeon enemies and props.
export function createBurnSystem(T,{scene,camera,texture,sfx,waterAt,isRaining,isSheltered,canSpread,onPanic,onPlayerState,limit=96}){
 const states=new Map(),wetUntil=new WeakMap();let clock=0,contactClock=0;
 const material=new T.MeshBasicMaterial({map:texture,color:'#ff9f36',transparent:true,opacity:.85,depthWrite:false,side:T.DoubleSide});
 const flames=new T.InstancedMesh(new T.PlaneGeometry(1,1),material,limit*3);flames.name='Pooled burning status flames';flames.frustumCulled=false;flames.userData.noBulletHit=true;flames.userData.noLOSBlock=true;flames.visible=false;scene.add(flames);const dummy=new T.Object3D();
 const valid=e=>e.alive?.()!==false&&e.visible?.()!==false;
 const point=e=>e.position();
 function isWet(e,p){return !e.indoors&&p.y+(e.waterHeight??.5)<=waterAt(p.x,p.z)||(isRaining()&&!e.indoors&&!isSheltered(e,p))}
 function extinguish(actor,wet=false){const st=states.get(actor);if(st){states.delete(actor);actor.userData.burning=null;if(st.entry.human)onPanic(st.entry,false)}if(wet)wetUntil.set(actor,clock+1.2);if(actor===camera)onPlayerState(false);}
 function protect(actor,seconds=5){wetUntil.set(actor,Math.max(wetUntil.get(actor)||0,clock+seconds))}
 function ignite(e,duration=9,source=null){if(!e||!valid(e)||e.fireproof)return false;const p=point(e);if(isWet(e,p)||(wetUntil.get(e.actor)||0)>clock)return false;
  let st=states.get(e.actor);if(st){if(source===st.source)return false;st.left=Math.min(14,Math.max(st.left,duration));return false}if(states.size>=limit)return false;
  st={entry:e,left:duration,tick:0,source,age:0,voice:0};states.set(e.actor,st);e.actor.userData.burning=true;if(e.human)onPanic(e,true);if(e.actor===camera)onPlayerState(true);return true;
 }
 function clear(){for(const actor of [...states.keys()])extinguish(actor);flames.count=0;flames.visible=false;}
 function update(dt,entries,sources=[]){
  clock+=dt;const live=new Map(entries.map(e=>[e.actor,e]));
  // Extinguishing always wins over contact; wet targets cannot immediately reignite.
  for(const [actor,st]of states){const e=live.get(actor);if(!e||!valid(e)){extinguish(actor);continue}st.entry=e;const p=point(e);if(isWet(e,p)){extinguish(actor,true);continue}st.age+=dt;st.left-=dt;st.tick+=dt;if(st.left<=0){extinguish(actor);continue}while(st.tick>=1){st.tick-=1;e.damage?.(e.kind==='prop'?3:e.kind==='hull'?2:4);if(!valid(e)){extinguish(actor);break}}if(e.human&&st.age>=st.voice){st.voice=st.age+1.5+(actor.id%5)*.19;sfx('human-hurt',{position:p,volume:.38,range:45,category:'voice',key:'burn-cry-'+actor.id,valid:()=>states.has(actor)&&valid(e)})}}
  contactClock-=dt;if(contactClock<=0){contactClock=.14;
   const positions=new Map();for(const e of entries)if(valid(e))positions.set(e.actor,point(e));
   for(const e of entries){if(!valid(e))continue;const p=positions.get(e.actor);if(isWet(e,p)){extinguish(e.actor,true);continue}
    for(const s of sources){const dx=p.x-s.position.x,dz=p.z-s.position.z;if(dx*dx+dz*dz<(s.radius+(e.radius||.32))**2&&p.y<s.position.y+s.height&&p.y+(e.height||1.6)>s.position.y-.25&&canSpread(s,e)){ignite(e,9,s.actor);break}}
   }
   // A snapshot prevents one frame from igniting an entire touching crowd at once.
   const carriers=[...states.values()].filter(st=>st.age>.24);
   for(const st of carriers){const a=st.entry,p=positions.get(a.actor);if(!p)continue;for(const b of entries){if(b.actor===a.actor||states.has(b.actor)||!valid(b))continue;const q=positions.get(b.actor);if(!q||Math.abs(q.y-p.y)>Math.min(a.height||1.6,b.height||1.6))continue;const r=(a.radius||.32)+(b.radius||.32)+.10;if((p.x-q.x)**2+(p.z-q.z)**2<r*r&&canSpread(a,b))ignite(b,Math.min(7.5,st.left),a.actor)}}
  }
  let count=0;for(const st of states.values()){const e=st.entry,p=point(e);if(p.distanceToSquared(camera.position)>85*85)continue;const h=e.height||1.6,r=e.radius||.32;for(let i=0;i<3;i++){const phase=clock*(8+i)+e.actor.id+i*2.1;dummy.position.set(p.x+Math.sin(phase*.7)*r*.55,p.y+h*(.28+i*.20)+Math.sin(phase)*.09,p.z+Math.cos(phase*.5)*r*.5);dummy.quaternion.copy(camera.quaternion);dummy.rotation.z+=Math.sin(phase)*.14;dummy.scale.set(r*(1.8+Math.sin(phase)*.2),h*(.58+Math.sin(phase*.9)*.12),1);dummy.updateMatrix();flames.setMatrixAt(count++,dummy.matrix)}}flames.count=count;flames.visible=count>0;if(count)flames.instanceMatrix.needsUpdate=true;
 }
 return {ignite,extinguish,protect,update,clear,states,flames,isWet,clock:()=>clock};
}
