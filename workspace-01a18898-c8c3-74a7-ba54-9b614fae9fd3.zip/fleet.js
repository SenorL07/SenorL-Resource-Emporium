// Procedural original boat silhouettes. Canonical deck/cabin coordinates remain
// unchanged; uniform world scale grows the actual collision and walkable space.
export function fleetProfile(stage=1,friendly=false){
 const names=['Fisher Launch','Outrigger Cutter','Coastal Sloop','Harbour Tug','Gun Cutter','Factory Trawler','Armored Corvette','Missile Frigate','Command Destroyer','Dreadnought Battleship'];
 const size=[1,1.04,1.08,1.12,1.16,1.20,1.25,1.31,1.39,1.50];
 const i=Math.max(0,Math.min(9,stage-1));return {stage:i+1,name:names[i],factor:size[i],friendly};
}
export function buildFleetModel(T,profile,{military=false}={}){
 const root=new T.Group();root.name=military?'River Naval Patrol Craft':profile.name;root.userData.noLOSBlock=true;
 const buckets=new Map(),props=[],muzzles=[],mountSpecs=[],cabinTurretSpecs=[],palette=military?['#364b43','#7d8960','#1b2b29','#b3bb98','#d5ae61','#62786b']:profile.friendly?['#245b62','#84b9a4','#213e48','#e6d7ae','#ddae51','#547888']:['#334a59','#9caaa7','#202d37','#e1d4b0','#c9793d','#668291'];
 const mats=palette.map((c,i)=>{const m=new T.MeshStandardMaterial({color:c,roughness:.73,metalness:.28});m.userData.impactMaterial=!military&&i===3?'wood':'metal';return m});
 // Real glazing: the panes are their own translucent material so a cabin window reads as
 // glass from both sides instead of a painted cream panel.
 const glassMat=new T.MeshStandardMaterial({color:'#9dc3c8',roughness:.18,metalness:.05,transparent:true,opacity:.34,side:T.DoubleSide,depthWrite:false});
 glassMat.userData.impactMaterial='glass';
 if(military&&typeof document!=='undefined'){
  const c=document.createElement('canvas');c.width=c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#425640';ctx.fillRect(0,0,128,128);let seed=733;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};for(let i=0;i<48;i++){ctx.fillStyle=['#202f2c','#81906a','#5b6c4d','#34483e'][i%4];const x=rand()*128,y=rand()*128;ctx.beginPath();ctx.moveTo(x,y);for(let j=0;j<7;j++)ctx.lineTo(x+(rand()-.5)*56,y+(rand()-.5)*40);ctx.fill()}const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.repeat.set(2,2);tex.colorSpace=T.SRGBColorSpace;mats[0].color.set('#ffffff');mats[0].map=tex;
 }
 let partGroup=null,partIndex=0;
 const part=(type,id,build)=>{const g=new T.Group();g.name=type+' equipment';g.userData.componentType=type;g.userData.componentId=id;root.add(g);const before=partGroup;partGroup=g;build(g);partGroup=before;return g};
 const add=(geo,position,rotation,color=0,scale=null)=>{const mesh=new T.Mesh(geo,mats[color]);mesh.position.set(...position);if(rotation)mesh.rotation.set(...rotation);if(scale)mesh.scale.set(...scale);mesh.updateMatrix();if(partGroup){mesh.userData.noLOSBlock=true;mesh.castShadow=true;partGroup.add(mesh);return mesh}const g=geo.index?geo.toNonIndexed():geo.clone();g.applyMatrix4(mesh.matrix);if(!buckets.has(color))buckets.set(color,[]);buckets.get(color).push(g);geo.dispose()};
 const box=(size,p,c=0,r=null)=>add(new T.BoxGeometry(...size),p,r,c);
 const cyl=(r,h,p,c=2,rot=null)=>add(new T.CylinderGeometry(r,r,h,10),p,rot,c);
 const rod=(a,b,r=.035,c=3)=>{const av=new T.Vector3(...a),bv=new T.Vector3(...b),v=bv.clone().sub(av),q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v.clone().normalize()),e=new T.Euler().setFromQuaternion(q);add(new T.CylinderGeometry(r,r,v.length(),7),av.add(bv).multiplyScalar(.5).toArray(),[e.x,e.y,e.z],c)};
 const s=military?7:profile.stage;
 const bow=military?2.92:3.0+(s%3)*.045,stern=military?1.73:1.62+(s%4)*.06,shoulder=military?1.45:1.30+(s%3)*.09;
 const shape=new T.Shape();shape.moveTo(-stern,-2.72);shape.lineTo(stern,-2.72);shape.lineTo(1.70,.7);shape.lineTo(shoulder,2.05);shape.lineTo(s===4||military?.60:.18,bow);shape.lineTo(s===4||military?-.60:-.18,bow);shape.lineTo(-shoulder,2.05);shape.lineTo(-1.70,.7);shape.closePath();
 const deckOutline=[[-stern,-2.72],[stern,-2.72],[1.70,.7],[shoulder,2.05],[s===4||military?.60:.18,bow],[s===4||military?-.60:-.18,bow],[-shoulder,2.05],[-1.70,.7]];
 add(new T.ExtrudeGeometry(shape,{depth:.16,bevelEnabled:false,steps:1}),[0,.295,0],[Math.PI/2,0,0],military?1:3);
 add(new T.ExtrudeGeometry(shape,{depth:.85+(s%3)*.05,bevelEnabled:true,bevelSegments:1,steps:1,bevelSize:.055,bevelThickness:.045}),[0,.13,0],[Math.PI/2,0,0],0);
 // Chines, rub rails and contrasting waterline produce different hull profiles.
 for(const side of [-1,1]){box([.085,.14,5.12],[side*1.73,-.12,-.12],military?2:4);for(let z=-2.2;z<1.8;z+=.74)box([.10,.29,.45],[side*1.75,-.33,z],s%2?1:5,[0,0,side*.15])}
 const crate=(x,y,z,ammo=false)=>part(ammo?'ammo':'prop',(ammo?'ammo-':'cargo-')+partIndex++,g=>{
  box([.48,.34,.43],[x,y,z],ammo?1:4);for(const dz of [-.17,.17])box([.5,.045,.035],[x,y+.18,z+dz],2);box([.10,.08,.015],[x,y,z+.224],3);g.userData.flammable=true;g.userData.fireRadius=.32;props.push(g);
 });
 const turret=(x,y,z,heavy=false,auto=false)=>{
  const id='mount-'+mountSpecs.length,roof=y>1,seatY=roof?(s===10?3.12:military?2.13:2.10):.38,baseYaw=roof?Math.PI:0;
  const base=new T.Group();base.name=id+'-base';base.userData.componentType='gun';base.userData.componentId=id;base.position.set(x,y,z);root.add(base);
  const yaw=new T.Group();yaw.name=id+'-yaw';yaw.rotation.y=baseYaw;base.add(yaw);
  const pitch=new T.Group();pitch.name=id+'-pitch';pitch.position.y=.30;yaw.add(pitch);
  const mesh=(geo,mat,p,parent=yaw,rot=null)=>{const m=new T.Mesh(geo,mats[mat]);m.position.set(...p);if(rot)m.rotation.set(...rot);m.castShadow=true;m.userData.noLOSBlock=true;m.userData.noBulletHit=false;parent.add(m);return m};
  mesh(new T.CylinderGeometry(heavy?.38:.25,heavy?.38:.25,.16,10),2,[0,0,0],base);
  mesh(new T.BoxGeometry(...(heavy?[.72,.37,.61]:[.4,.26,.38])),0,[0,.23,0]);
  const count=heavy?2:1;
  for(let i=0;i<count;i++){
   const dx=count===2?(i?1:-1)*.17:0,len=heavy?1.07:.66;
   mesh(new T.CylinderGeometry(heavy?.065:.045,heavy?.065:.045,len,9),2,[dx,0,heavy?.65:.43],pitch,[Math.PI/2,0,0]);
   mesh(new T.BoxGeometry(.12,.13,.13),2,[dx,0,heavy?1.2:.79],pitch);
   const muzzle=new T.Object3D();muzzle.name=id+'-muzzle-'+i;muzzle.position.set(dx,0,heavy?1.24:.83);pitch.add(muzzle);
  }
  const flash=new T.Mesh(new T.SphereGeometry(.17,7,5),new T.MeshBasicMaterial({color:'#ffdc81',transparent:true,opacity:.85}));flash.name=id+'-flash';flash.position.set(0,0,heavy?1.25:.85);flash.visible=false;flash.userData.noLOSBlock=true;flash.userData.noBulletHit=true;pitch.add(flash);
  const seatZ=roof?Math.min(z+.50,s===10?-.40:.10):z-.64;
  mountSpecs.push({id,x,y,z,heavy,auto,baseYaw,yawLimit:roof?Math.PI:70*Math.PI/180,pitchMin:roof?-.35:-.22,pitchMax:.60,seat:[x,seatY,seatZ],barrels:count,roof});
  // Automated mounts carry a small shielded housing so they read as machinery.
  if(auto){mesh(new T.BoxGeometry(heavy?.62:.46,heavy?.22:.16,heavy?.5:.36),0,[0,heavy?.52:.42,heavy?-.12:-.1],base);mesh(new T.CylinderGeometry(heavy?.05:.035,heavy?.05:.035,heavy?.34:.26,7),2,[0,heavy?.5:.40,heavy?-.20:-.16],yaw,[Math.PI/2,0,0]);}
  muzzles.push(new T.Vector3(x,y+.3,z+(heavy?1.24:.83)));
  if(roof){const low=s===10?2.64:seatY;for(const side of [-1,1]){const ladder=(x,y0,y1)=>{for(const dz of [-.17,.17])rod([side*x,y0,-.95+dz],[side*x,y1,-.95+dz],.025,2);for(let h=y0+.16;h<y1;h+=.23)rod([side*x,h,-1.12],[side*x,h,-.78],.022,3)};ladder(1.12,.38,low);if(seatY>low+.2)ladder(.69,low,seatY)}}
 };
 const mast=(x,z,height=3.7)=>{rod([x,1.98,z],[x,height,z],.045,2);rod([x-.45,height-.2,z],[x+.45,height-.2,z],.027,3);box([.48,.08,.18],[x,height,z],1)};
 const funnel=(x,z,h=.7)=>part('prop','funnel-'+partIndex++,()=>{box([.3,h,.4],[x,2.0+h/2,z],2);box([.36,.1,.45],[x,2+h,z],4);for(let i=0;i<3;i++)box([.32,.035,.3],[x,2.05+i*.13,z+.12],1)});
 // Window rows are authored from the cabin they belong to, so every upgrade keeps its
 // panes flush with the cabin face instead of leaving holes behind the old panes.
 // Panes sit in the face they belong to: axis 'z' puts a row across the given z (front or
 // back wall) and axis 'x' puts it down a side wall at x=face. `center` slides the row
 // along its wall, so the bridge rows of the big hulls line up with the bridge box.
 let windowRows=0;
 const windowRow=(id,cy,axis,face,center,width,count)=>{windowRows++;return part('window',id,g=>{
  const pane=(width-.18)/count-.07,sign=Math.sign(face)||1;
  for(let i=0;i<count;i++){
   const off=(i-(count-1)/2)*(pane+.07),front=axis==='z';
   const frame=new T.Mesh(new T.BoxGeometry(front?pane+.06:.035,.30,front?.035:pane+.06),mats[2]);
   frame.position.set(front?center+off:face,cy,front?face:center+off);frame.castShadow=true;frame.userData.noLOSBlock=true;g.add(frame);
   const paneMesh=new T.Mesh(new T.BoxGeometry(front?pane:.018,.22,front?.018:pane),glassMat);
   paneMesh.position.set(front?center+off:face+sign*.019,cy,front?face+sign*.019:center+off);
   paneMesh.userData.noLOSBlock=true;g.add(paneMesh);
  }
 })};
 // Small automated turret bolted under the cabin ceiling: it owns its health like any
 // other fitting and the maintenance crew rebuilds it after it is shot out.
 const cabinTurret=(roofY,z)=>{
  const id='autogun-cabin-'+(cabinTurretSpecs.length);
  const group=part('autogun',id,g=>{
   const plate=new T.Mesh(new T.BoxGeometry(.40,.05,.40),mats[4]);plate.position.set(0,roofY-.035,z);plate.userData.noLOSBlock=true;g.add(plate);
   const yaw=new T.Group();yaw.name=id+'-yaw';yaw.position.set(0,roofY-.10,z);g.add(yaw);
   const stem=new T.Mesh(new T.CylinderGeometry(.055,.075,.15,8),mats[5]);stem.position.y=-.05;stem.userData.noLOSBlock=true;yaw.add(stem);
   const pitch=new T.Group();pitch.name=id+'-pitch';pitch.position.y=-.15;yaw.add(pitch);
   // Skeletonised housing: a light-coloured shroud over a dark receiver, bright enough to
   // read against the black cabin ceiling at a glance.
   const housing=new T.Mesh(new T.BoxGeometry(.23,.11,.25),mats[3]);housing.castShadow=true;housing.userData.noLOSBlock=true;pitch.add(housing);
   const receiver=new T.Mesh(new T.BoxGeometry(.15,.10,.20),mats[2]);receiver.position.set(0,-.06,.03);receiver.userData.noLOSBlock=true;pitch.add(receiver);
   const barrel=new T.Mesh(new T.CylinderGeometry(.028,.028,.36,7),mats[5]);barrel.rotation.x=Math.PI/2;barrel.position.set(0,-.045,.26);barrel.castShadow=true;barrel.userData.noLOSBlock=true;pitch.add(barrel);
   const shroud=new T.Mesh(new T.BoxGeometry(.075,.075,.16),mats[4]);shroud.position.set(0,-.03,.14);shroud.userData.noLOSBlock=true;pitch.add(shroud);
   const lamp=new T.Mesh(new T.SphereGeometry(.036,8,6),new T.MeshStandardMaterial({color:'#c8503c',emissive:'#8a2418',emissiveIntensity:.9,roughness:.5,metalness:.1}));
   lamp.name=id+'-lamp';lamp.position.set(.085,.05,.06);lamp.userData.noLOSBlock=true;lamp.userData.noBulletHit=true;pitch.add(lamp);
   const sensor=new T.Mesh(new T.CylinderGeometry(.045,.045,.03,9),new T.MeshStandardMaterial({color:'#2a3b39',emissive:'#4d6a5c',emissiveIntensity:.35,roughness:.4,metalness:.35}));
   sensor.rotation.x=Math.PI/2;sensor.position.set(0,.03,.135);sensor.userData.noBulletHit=true;pitch.add(sensor);
   const muzzle=new T.Object3D();muzzle.name=id+'-muzzle-0';muzzle.position.set(0,-.045,.44);pitch.add(muzzle);
   const flash=new T.Mesh(new T.SphereGeometry(.10,7,5),new T.MeshBasicMaterial({color:'#ffd88a',transparent:true,opacity:.9}));
   flash.name=id+'-flash';flash.position.copy(muzzle.position);flash.visible=false;flash.userData.noLOSBlock=flash.userData.noBulletHit=true;pitch.add(flash);
  });
  cabinTurretSpecs.push({id,x:0,y:roofY-.10,z,roofY});
  return group;
 };
 if(military){
  // No fishing equipment: weapon mounts, ammo lockers, boarding equipment and
  // angular disruptive camouflage are baked into seven inexpensive draw buckets.
  for(const side of [-1,1])for(let i=0;i<11;i++)box([.028,.23+(i%3)*.08,.4+(i%2)*.15],[side*1.8,-.06,-2.4+i*.45],i%3===0?2:1,[0,0,side*.17]);
  turret(0,.48,2.15,true,true);turret(0,2.16,-.64,false,true);for(const x of [-.65,.65]){crate(x,.54,-2.19,true);crate(x,.89,-2.19,true)}
  box([1.98,.18,1.95],[0,2.04,-.58],0);for(const side of [-1,1]){box([.12,.42,1.2],[side*1.04,1.1,-.6],0);rod([side*1.73,.4,-2.5],[side*1.73,.95,-2.5],.04,2);for(let i=0;i<3;i++)cyl(.15,.07,[side*1.78,.18,-1.6+i*.6],2,[0,0,Math.PI/2]);box([.29,.32,.8],[side*1.46,.45,1.0],1)}
  mast(.72,-.95,3.15);rod([-.7,2.05,-1.25],[-.7,3.4,-1.3],.018,2);box([.5,.35,.22],[0,2.4,-.6],2);box([.29,.23,.025],[0,2.4,-.47],3);
  cabinTurret(1.95,-.62);for(const side of [-1,1])windowRow('window-bridge-'+side,2.42,'x',side*.99,-.6,2.2,3);
  // Twin stern outboards and a boarding ladder distinguish the stern silhouette.
  for(let i=0;i<4;i++)rod([-.36,-.55+i*.22,-2.77],[.36,-.55+i*.22,-2.77],.025,3);
 }else switch(s){
  case 1:box([2.04,.13,1.96],[0,2.0,-.58],4);crate(-.70,.5,-2.16);rod([-.86,2.08,-1.2],[.86,2.08,-1.2],.035,4);break;
  case 2:for(const side of [-1,1]){box([.22,.31,4.7],[side*1.78,-.15,-.15],1);rod([side*.85,.5,-2],[side*1.8,.15,-2],.055,4);rod([side*.85,.5,1.4],[side*1.8,.15,1.4],.055,4)}box([2.12,.15,2.02],[0,2.02,-.58],1);break;
  case 3:{mast(-.78,1.32,4.3);const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute([-.78,4.2,1.32,-.78,2.35,1.32,1.0,2.35,1.32],3));g.computeVertexNormals();add(g,[0,0,0],null,3);rod([-.78,2.35,1.32],[1,2.35,1.32],.035,4);crate(.64,.5,-2.15);break}
  case 4:for(const x of [-.52,.52])funnel(x,-.7,.85);for(const side of [-1,1]){rod([side*1.30,.4,-2.15],[side*1.3,2.6,-2.15],.085,4);for(let i=0;i<4;i++)cyl(.19,.1,[side*1.79,.05,-1.8+i*.9],2,[0,0,Math.PI/2])}rod([-1.3,2.6,-2.15],[1.3,2.6,-2.15],.085,4);break;
  case 5:turret(0,.47,2.12);box([2.18,.28,2.12],[0,2.02,-.58],0);for(const x of [-.65,.65])crate(x,.51,-2.2,true);mast(.7,-1.1,3.3);break;
  case 6:for(const x of [-1.0,1.0])rod([x,.38,-2.28],[x,3.0,-2.28],.075,4);rod([-1,3,-2.28],[1,3,-2.28],.075,4);rod([0,3,-2.28],[0,3.45,.55],.05,4);for(const x of [-.6,.6])crate(x,.5,-2.08);funnel(.62,-.65);break;
  case 7:box([2.18,.23,2.17],[0,2.02,-.58],0);for(const x of [-.59,.59])funnel(x,-.8,.55);turret(0,.47,2.12);mast(0,-.7,3.5);for(const side of [-1,1])box([.11,.5,2.0],[side*1.62,.28,-.4],0,[0,0,side*.2]);break;
  case 8:{box([1.65,.56,1.15],[0,2.27,-.63],0);turret(0,.48,2.12);mast(0,-.75,4.05);
   windowRow('window-bridge-front',2.30,'z',0.03,0,1.52,3);for(const side of [-1,1])windowRow('window-bridge-'+side,2.30,'x',side*.83,-.63,1.2,2);cabinTurret(1.95,-.66);break}
  case 9:{box([1.7,.70,1.43],[0,2.33,-.65],0);funnel(.75,-1.05,1.1);mast(-.55,-.8,4.5);turret(0,.47,2.15,true);for(const side of [-1,1])crate(side*.65,.53,-2.2,true);
   windowRow('window-bridge-front',2.46,'z',0.115,0,1.56,3);for(const side of [-1,1])windowRow('window-bridge-'+side,2.46,'x',side*.85,-.65,1.3,2);cabinTurret(1.95,-.68);break}
  case 10:{box([2.18,.62,1.54],[0,2.33,-.63],0);box([1.32,.48,1.08],[0,2.88,-.68],1);turret(-.80,.53,2.00,true);turret(.80,.53,2.00,true);turret(0,3.22,-.67,true);for(const x of [-.60,.60])funnel(x,-1.17,1.1);mast(0,-.85,4.7);for(const side of [-1,1]){for(let i=0;i<5;i++)box([.10,.46,.6],[side*1.77,.09,-2.2+i*.88],0,[0,0,side*.12]);crate(side*.68,.53,-2.2,true)}
   windowRow('window-bridge-front',2.40,'z',0.155,0,1.9,4);windowRow('window-bridge-upper',2.90,'z',-0.15,0,1.14,3);
   for(const side of [-1,1]){windowRow('window-bridge-'+side,2.40,'x',side*1.09,-.63,1.4,2);windowRow('window-bridge-upper-'+side,2.90,'x',side*.66,-.68,.95,1)}
   cabinTurret(1.95,-.52);cabinTurret(1.95,-1.10);break}
 }
 // The walk-in cabin is hull, not a prop: one shell of walls, a ceiling and a stern
 // bulkhead with a real door aperture, drawn into the merged hull buckets. Because it
 // shares the hull mesh it can never be shot away from the boat it belongs to, and the
 // window openings stay open for the destructible panes that fill them.
 // The glazing band is exactly as tall and as wide as the pane frames that fill it, so
 // there is never a slot above, below or beside a window row.
 // yBase sits below the deck planking so the shell is joined to the hull with no seam.
 const CABIN={half:.94,zFront:.33,zBack:-1.49,yFloor:.26,yCeiling:1.88,bandY0:1.11,bandY1:1.41,doorX0:-.42,doorX1:.36,doorY0:.43,doorY1:1.61,frontPaneX:.635,sidePaneZ0:-.895,sidePaneZ1:-.145};
 // Its own untracked mesh group: solid to bullets and sight, but never a breakable
 // fitting, so a wall can never be shot off the hull it is part of.
 const cabinShell=part('cabin','cabin-shell',()=>{
  const midY=(y0,y1)=>(y0+y1)/2;
  const wall=(w,h,d,x,y,z,c=3)=>{if(w>.005&&h>.005&&d>.005)box([w,h,d],[x,y,z],c)};
  const zMid=midY(CABIN.zFront,CABIN.zBack),zSpan=Math.abs(CABIN.zFront-CABIN.zBack);
  for(const side of [-1,1]){
   // Lower panel, upper panel and the two end posts leave a glazed band in the middle.
   wall(.11,midY(CABIN.yFloor,CABIN.bandY0)-CABIN.yFloor,zSpan,side*CABIN.half,midY(CABIN.yFloor,CABIN.bandY0),zMid);
   wall(.11,CABIN.yCeiling-CABIN.bandY1,zSpan,side*CABIN.half,midY(CABIN.bandY1,CABIN.yCeiling),zMid);
   wall(.11,CABIN.bandY1-CABIN.bandY0,Math.abs(CABIN.sidePaneZ0-CABIN.zFront),side*CABIN.half,midY(CABIN.bandY0,CABIN.bandY1),midY(CABIN.zFront,CABIN.sidePaneZ0));
   wall(.11,CABIN.bandY1-CABIN.bandY0,Math.abs(CABIN.zBack-CABIN.sidePaneZ1),side*CABIN.half,midY(CABIN.bandY0,CABIN.bandY1),midY(CABIN.sidePaneZ1,CABIN.zBack));
  }
  // Front wall: solid below and above the glazing, pillars outside the pane row.
  wall(CABIN.half*2+.11,CABIN.bandY0-CABIN.yFloor,.11,0,midY(CABIN.yFloor,CABIN.bandY0),CABIN.zFront);
  wall(CABIN.half*2+.11,CABIN.yCeiling-CABIN.bandY1,.11,0,midY(CABIN.bandY1,CABIN.yCeiling),CABIN.zFront);
  for(const side of [-1,1])wall(CABIN.half-CABIN.frontPaneX,CABIN.bandY1-CABIN.bandY0,.11,side*midY(CABIN.frontPaneX,CABIN.half),midY(CABIN.bandY0,CABIN.bandY1),CABIN.zFront);
  // Stern bulkhead keeps the hinged door's aperture: 0.78 wide and 1.18 tall.
  for(const side of [-1,1]){const x0=side<0?-CABIN.half:CABIN.doorX1,x1=side<0?CABIN.doorX0:CABIN.half;wall(Math.abs(x1-x0),CABIN.yCeiling-CABIN.yFloor,.11,midY(x0,x1),midY(CABIN.yFloor,CABIN.yCeiling),CABIN.zBack)}
  wall(CABIN.doorX1-CABIN.doorX0,CABIN.yCeiling-CABIN.doorY1,.11,midY(CABIN.doorX0,CABIN.doorX1),midY(CABIN.doorY1,CABIN.yCeiling),CABIN.zBack);
  // Ceiling slab: it also gives the cabin gun something to hang from.
  wall(CABIN.half*2+.24,.08,zSpan+.30,0,CABIN.yCeiling+.04,zMid,0);
 });
 delete cabinShell.userData.componentType;delete cabinShell.userData.componentId;
 // Cabin glazing, flush in those openings and destructible like every other fitting.
 // Panes sit on the outer face of the wall (half its 0.11 thickness proud of the centre
 // line), so the glazing reads from outside and never hides inside the slab.
 windowRow('window-cabin-front',1.26,'z',CABIN.zFront+.055,0,1.48,3);
 for(const side of [-1,1])windowRow('window-cabin-'+(side<0?'port':'starboard'),1.26,'x',side*(CABIN.half+.055),(CABIN.sidePaneZ0+CABIN.sidePaneZ1)/2,Math.abs(CABIN.sidePaneZ1-CABIN.sidePaneZ0),2);
 if(military&&typeof document!=='undefined'){
  const c=document.createElement('canvas');c.width=256;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='#dbe2cb';ctx.font='bold 44px monospace';ctx.textAlign='center';ctx.fillText('PATROL 07',128,48);const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;const label=new T.Mesh(new T.PlaneGeometry(1.02,.25),new T.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,side:T.DoubleSide}));label.name='Naval hull identification';label.position.set(1.82,.13,-.85);label.rotation.y=Math.PI/2;label.userData.noBulletHit=true;label.userData.noLOSBlock=true;root.add(label);
 }
 // One merged mesh per palette material, instead of dozens of new draw calls.
 for(const [color,gs]of buckets){let len=0;for(const g of gs)len+=g.attributes.position.count*3;const pos=new Float32Array(len),norm=new Float32Array(len),uv=new Float32Array(len/3*2);let at=0;for(const g of gs){pos.set(g.attributes.position.array,at);norm.set(g.attributes.normal.array,at);if(g.attributes.uv)uv.set(g.attributes.uv.array,at/3*2);at+=g.attributes.position.array.length;g.dispose()}const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(pos,3));geo.setAttribute('normal',new T.BufferAttribute(norm,3));geo.setAttribute('uv',new T.BufferAttribute(uv,2));geo.computeBoundingSphere();const mesh=new T.Mesh(geo,mats[color]);mesh.name='Fleet merged detail '+color;mesh.castShadow=true;mesh.receiveShadow=true;mesh.userData.noLOSBlock=true;mesh.userData.noBulletHit=color!==0;root.add(mesh)}
 root.userData.solidBlocks=military?[]:s===10?[{y0:2.64,y1:3.12,rect:[-.66,.66,-1.22,-.14]},{y0:2.02,y1:2.64,rect:[-1.09,1.09,-1.40,.14]}]:s===9?[{y0:1.98,y1:2.68,rect:[-.85,.85,-1.365,.065]}]:s===8?[{y0:1.99,y1:2.55,rect:[-.825,.825,-1.205,-.055]}]:[];root.userData.roofLevels=s===10?[2.64,3.12]:[military?2.13:2.10];root.userData.deckOutline=deckOutline;root.userData.deckHeight=.295;root.userData.mountSpecs=mountSpecs;root.userData.fireProps=props;root.userData.muzzles=muzzles;root.userData.cabinTurrets=cabinTurretSpecs;root.userData.windowsProvided=windowRows>0;root.userData.modelSignature=[s,bow,stern,shoulder,profile.factor,military].join(':');return root;
}

export function fleetDeckContains(outline,x,z,padding=0){
 if(!outline?.length)return Math.abs(x)<=1.49+padding&&z>=-2.505-padding&&z<=2.445+padding;
 let inside=false,nearest=Infinity;for(let i=0,j=outline.length-1;i<outline.length;j=i++){
  const [ax,az]=outline[j],[bx,bz]=outline[i];if((az>z)!==(bz>z)&&x<(bx-ax)*(z-az)/(bz-az)+ax)inside=!inside;
  const dx=bx-ax,dz=bz-az,t=Math.max(0,Math.min(1,((x-ax)*dx+(z-az)*dz)/(dx*dx+dz*dz)));nearest=Math.min(nearest,Math.hypot(x-ax-t*dx,z-az-t*dz));
 }return inside||nearest<=Math.max(1e-7,padding);
}
