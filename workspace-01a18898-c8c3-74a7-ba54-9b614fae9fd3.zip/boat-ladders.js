// Independently implemented GoldSrc ladder-plane movement, in metre-based units.
export function ladderWishVelocity(T,{forward,right,normal,forwardInput=0,rightInput=0,crouch=false,speed=5}){
 const wish=forward.clone().multiplyScalar(Math.sign(forwardInput)*speed).addScaledVector(right,Math.sign(rightInput)*speed);
 if(crouch)wish.multiplyScalar(1/3);
 const into=wish.dot(normal);wish.addScaledVector(normal,-into);wish.y-=into;return wish;
}
export function createBoatLadderSystem(T,{boats,collide=p=>p}){
 const state={contact:null,cooldown:0,jumpHeld:false},up=new T.Vector3(0,1,0);
 function reset(){state.contact=null;state.cooldown=0;state.jumpHeld=false}
 function ladders(boat){const levels=boat.userData.fleetModel?.userData.roofLevels;if(!levels?.length)return [];const result=[];for(const side of [-1,1]){result.push({boat,side,x:side*1.12,bottom:boat.userData.deckHeight??.38,top:levels[0],z:-.95});if(levels.at(-1)>levels[0]+.2)result.push({boat,side,x:side*.69,bottom:levels[0],top:levels.at(-1),z:-.95})}return result}
 function touching(l,p,extra=0){const scale=Math.max(.5,l.boat.scale.x);return Math.abs(p.z-l.z)<(.25+extra)/scale+.17&&p.x*l.side>Math.abs(l.x)-.07&&p.x*l.side<Math.abs(l.x)+(.30+extra)/scale+.04&&p.y<=l.top+.04&&p.y>=l.bottom-.12}
 function wish(c,yaw,pitch,forwardInput,rightInput,crouch){const inv=c.boat.getWorldQuaternion(new T.Quaternion()).invert();return ladderWishVelocity(T,{normal:new T.Vector3(c.side,0,0),forward:new T.Vector3(-Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),-Math.cos(yaw)*Math.cos(pitch)).applyQuaternion(inv),right:new T.Vector3(Math.cos(yaw),0,-Math.sin(yaw)).applyQuaternion(inv),forwardInput,rightInput,crouch})}
 function update(dt,{position,eye=1.66,yaw=0,pitch=0,forwardInput=0,rightInput=0,crouch=false,jump=false}){
  dt=Math.max(0,Math.min(dt,.05));state.cooldown=Math.max(0,state.cooldown-dt);const jumpPressed=jump&&!state.jumpHeld;state.jumpHeld=jump;let c=state.contact,carriedYaw=0;
  const active=boats().filter(b=>b.visible);
  if(c&&!active.includes(c.boat)){state.contact=null;state.cooldown=.25;return {active:false,detached:true,velocity:new T.Vector3()}}
  if(c){c.boat.updateWorldMatrix(true,false);carriedYaw=Math.atan2(Math.sin(c.boat.rotation.y-c.yaw),Math.cos(c.boat.rotation.y-c.yaw));yaw+=carriedYaw;position.copy(c.boat.localToWorld(c.local.clone())).addScaledVector(up,eye);c.yaw=c.boat.rotation.y}
  // A nearby rung is not a ladder touch. Idle deck standing, sideways walking,
  // and a held deck-jump must never enter fly mode or trigger a horizontal kick.
  if(!c&&!state.cooldown&&!jump&&(forwardInput||rightInput))for(const boat of active){
   boat.updateWorldMatrix(true,false);const local=boat.worldToLocal(position.clone().addScaledVector(up,-eye));
   const l=ladders(boat).find(l=>{if(!touching(l,local))return false;const v=wish(l,yaw,pitch,forwardInput,rightInput,crouch);return Math.abs(v.y)>.2&&(local.y<l.top-.035||v.y<0)});
   if(l){c={...l,local,yaw:boat.rotation.y};const clearance=.18/Math.max(.5,boat.scale.x)+.025;c.local.x=c.side*Math.max(Math.abs(c.local.x),Math.abs(c.x)+clearance);state.contact=c;break}
  }
  if(!c)return {active:false};
  function finishExit(){const exit=c.exit;exit.elapsed=Math.min(exit.duration,exit.elapsed+dt);c.local.lerpVectors(exit.from,exit.to,exit.elapsed/exit.duration);position.copy(c.boat.localToWorld(c.local.clone())).addScaledVector(up,eye);if(exit.elapsed>=exit.duration){state.contact=null;state.cooldown=.3;return {active:true,landed:true,boat:c.boat,foot:c.local.clone(),velocity:new T.Vector3(),yaw:carriedYaw}}return {active:true,velocity:new T.Vector3(),yaw:carriedYaw}}
  if(c.exit)return finishExit();
  if(jumpPressed){state.contact=null;state.cooldown=.35;return {active:false,jumped:true,boat:c.boat,foot:c.local.clone(),velocity:new T.Vector3(c.side,0,0).applyAxisAngle(up,c.boat.rotation.y).multiplyScalar(6.75),yaw:carriedYaw}}
  const velocity=wish(c,yaw,pitch,forwardInput,rightInput,crouch),previous=position.clone();
  // The ladder owns foot coordinates until a deliberate exit; collider epsilon
  // pushes cannot alternate fly/walk states and repeatedly inherit boat momentum.
  const next=position.clone(),scale=c.boat.getWorldScale(new T.Vector3()),foot=c.local.clone().add(new T.Vector3(velocity.x/scale.x,velocity.y/scale.y,velocity.z/scale.z).multiplyScalar(dt));foot.x=c.local.x;
  function land(y,inward){foot.y=y;if(inward)foot.x=c.side*(Math.abs(c.x)-.22);position.copy(c.boat.localToWorld(foot.clone())).addScaledVector(up,eye);state.contact=null;state.cooldown=.3;return {active:true,landed:true,boat:c.boat,foot:foot.clone(),velocity:new T.Vector3(),yaw:carriedYaw}}
  if(velocity.y>0&&foot.y>=c.top-1e-5){foot.y=c.top;const to=foot.clone();to.x=c.side*(Math.abs(c.x)-.22);c.exit={from:foot.clone(),to,elapsed:0,duration:.24};return finishExit();}
  if(velocity.y<0&&foot.y<=c.bottom+1e-5)return land(c.bottom,false);
  next.copy(c.boat.localToWorld(foot.clone())).addScaledVector(up,eye);const safe=collide(next,previous,eye),safeFoot=c.boat.worldToLocal(safe.clone().addScaledVector(up,-eye));
  // Keep normal clearance against our own wall; tangential collisions still stop strafing.
  safeFoot.x=c.local.x;safeFoot.y=foot.y;c.local.copy(safeFoot);position.copy(c.boat.localToWorld(c.local.clone())).addScaledVector(up,eye);
  if(!touching(c,c.local,.13)){state.contact=null;state.cooldown=.3;return {active:false,detached:true,boat:c.boat,foot:c.local.clone(),velocity:new T.Vector3(velocity.x,Math.min(0,velocity.y),velocity.z),yaw:carriedYaw}}
  return {active:true,velocity:velocity.clone().applyQuaternion(c.boat.getWorldQuaternion(new T.Quaternion())),yaw:carriedYaw};
 }
 return {state,update,reset,ladders};
}
