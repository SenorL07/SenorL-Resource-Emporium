// Material hits are separate recordings from destruction. No emitters/decoders per hit.
function impactMaterial(object,point){
 if(object===Fc||object?.userData.waterSurface)return 'water';
 if(object===oe)return 'flesh';
 const part=boatComponentFor(object);if(part)return equipmentBreakMaterial(part);
 if(navalCombat?.isBridge(object))return 'wood';
 // Actors win over their enclosing boat's material tags.
 for(let n=object;n;n=n.parent){if(n.userData.crewRole)return 'flesh';if(n.userData.enemyData)return n.userData.enemyData.kind==='skeleton'?'stone':'flesh'}
 for(let n=object;n;n=n.parent){const tag=n.userData.impactMaterial;if(tag)return tag}
 const material=Array.isArray(object?.material)?object.material[0]:object?.material;
 if(material?.userData.impactMaterial)return material.userData.impactMaterial;
 if(object===Vd){const h=combatGroundHeight(point.x,point.z);return h>8?'stone':'earth'}
 for(let n=object;n;n=n.parent){const name=n.name||'';
  if(/glass|window|mirror|aquarium/i.test(name))return 'glass';
  if(/net|cloth|fabric|canvas|rug|cushion|sofa|bed/i.test(name))return 'fabric';
  if(/metal|engine|motor|gun|radar|winch|ladder|barrel|roof/i.test(name))return 'metal';
  if(/wood|plank|door|dock|palm|tree|trunk|crate|chest|cabinet|chair|table|bookshelf/i.test(name))return 'wood';
  if(/rock|stone|concrete|brick|dungeon/i.test(name))return 'stone';
 }
 if(material?.transparent&&(material.opacity??1)<.65)return 'glass';
 if((material?.metalness??0)>.25||i0(object,ge)||i0(object,it)||i0(object,ze))return 'metal';
 return Tn.active?'stone':'wood';
}
function playMaterialImpact(object,point,strength=1){
 if(!object||!point)return;const kind=impactMaterial(object,point);if(kind==='water')return;
 It('impact-'+kind,{position:point,volume:he.clamp((kind==='fabric'?.22:.38)*strength,.12,.65),range:48,key:'material-hit-'+kind,cooldown:55,maxAge:600,category:'impact'});
}
