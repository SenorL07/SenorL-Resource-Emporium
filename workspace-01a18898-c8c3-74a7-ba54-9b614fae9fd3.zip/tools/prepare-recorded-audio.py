import numpy as np, subprocess as sp, pathlib,json
out=pathlib.Path('/home/user/assets/audio/recorded'); base=pathlib.Path('/tmp/audio-source');manifest={}
def encode(name,src,mode='effect',offset=0,duration=None):
 src=base/src;a=np.frombuffer(sp.check_output(['ffmpeg','-v','error','-i',str(src),'-ac','1','-ar','24000','-f','f32le','-']),dtype=np.float32).copy();sr=24000
 if mode=='gun':
  start=max(0,np.flatnonzero(np.abs(a)>np.max(np.abs(a))*.28)[0]-480);a=a[start:start+int(1.65*sr)];offset=start/sr
 elif mode=='loop':
  a=a[int(offset*sr):int((offset+(duration or 5))*sr)];n=min(int(.22*sr),len(a)//5);f=np.linspace(0,1,n);a=np.concatenate([a[n:-n],a[-n:]*(1-f)+a[:n]*f])
 else:
  ids=np.flatnonzero(np.abs(a)>max(.002,np.max(np.abs(a))*.015));a=a[max(0,ids[0]-240):min(len(a),ids[-1]+1200)] if len(ids) else a
  a=a[:int((duration or 3.2)*sr)];n=min(180,len(a)//8);a[:n]*=np.linspace(0,1,n);a[-n:]*=np.linspace(1,0,n)
 peak=np.max(np.abs(a));a*=.86/max(peak,.001)
 if mode!='loop':a[-min(1200,len(a)):]*=np.linspace(1,0,min(1200,len(a)))
 sp.run(['ffmpeg','-v','error','-y','-f','f32le','-ar',str(sr),'-ac','1','-i','-','-c:a','libvorbis','-q:a','3',str(out/(name+'.ogg'))],input=a.astype(np.float32).tobytes(),check=True)
 manifest[name]={'sourceFile':str(src.relative_to(base)),'duration':round(len(a)/sr,3),'sourceOffset':round(float(offset),3),'processing':'mono 24kHz, peak-normalized; '+('cyclic 220ms crossfade' if mode=='loop' else 'trim, fade, Vorbis encoding')}
for i,f in enumerate(['1yell2.wav','2yell3.wav','3yell2.wav']):encode('human-alert-'+str(i+1),'humans/yelling sounds/'+f,duration=2.4)
for i,f in enumerate(['3grunt1.wav','3grunt3.wav','3grunt5.wav','2yell8.wav']):encode('human-hurt-'+str(i+1),'humans/yelling sounds/'+f,duration=1.8)
for i,f in enumerate(['breath.ogg','cough_01.ogg','cough_02.ogg']):encode('human-idle-'+str(i+1),'creatures/'+f,duration=2)
for kind,states in {'bat':{'alert':['bug_01','bug_02'],'hurt':['cute_05','cute_07'],'idle':['cute_01','cute_02']},'skeleton':{'alert':['monster_02','monster_03'],'hurt':['hurt_02','hurt_04'],'idle':['monster_01','grunt_02']}}.items():
 for state,files in states.items():
  for i,f in enumerate(files):encode(f'{kind}-{state}-{i+1}','creatures/'+f+'.ogg',duration=2)
for state,files in {'alert':[1,3],'hurt':[6,9,12],'idle':[2,5]}.items():
 for i,f in enumerate(files):encode(f'goblin-{state}-{i+1}',f'goblins/goblins/goblin-{f}.wav',duration=2)
for state,files in {'alert':['slime_04','slime_08'],'hurt':['slime_02','slime_06'],'idle':['bubble_01','bubble_03']}.items():
 for i,f in enumerate(files):encode(f'slime-{state}-{i+1}','water/'+f+'.ogg',duration=2)
for name,f in {'pistol':'Walther PPQ/X_39P.wav','rifle':'SKS/U_14P.wav','marksman':'Mosin Nagant/M_21P.wav','shotgun':'Nova/O_21P.wav'}.items():encode(name,'firearms/Prepared SFX Library/'+f,'gun')
encode('reload','reload.wav');encode('cock','cock.wav');encode('splash','water/splash_05.ogg');encode('water-gulp','water/bubble_02.ogg');encode('rain','water/loop_rain.ogg','loop',0,5);encode('engine-idle','idle.mp3','loop',.2,2.4);encode('engine-run','outboard.mp3','loop',20,6)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(manifest),'files',sum(f.stat().st_size for f in out.glob('*.ogg')),'bytes')
for i,f in enumerate(['breath-male.wav','cough1.wav','yawn1.wav']):encode('human-idle-'+str(i+1),'owlish/Human/'+f,duration=2.6)
encode('human-idle-4','owlish/Human/sniff.wav')
encode('rattle','owlish/Misc Foley/pill-bottle.wav',duration=.9)
encode('cloth','owlish/Cloth, Rustle/320137__owlstorm__blanket-movement-1.wav',duration=.85)
for name,f in {'grass-1':'gassy-footstep1.wav','grass-2':'grassy-footstep2.wav','hard-1':'hard-footstep1.wav','hard-2':'hard-footstep2.wav'}.items():encode(name,'owlish/Footsteps/'+f,duration=.7)
encode('thunder','thunder.mp3',duration=8)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(manifest),'final files')
