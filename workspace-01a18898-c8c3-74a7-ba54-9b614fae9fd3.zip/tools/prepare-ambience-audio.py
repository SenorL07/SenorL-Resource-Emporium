"""Builds the looping ambience beds from CC0 source recordings.

Sources (all CC0 1.0, downloaded from OpenGameArt, see assets/licenses/ambience-audio.md):
  vistula.mp3   RandomMind, "Sea and river wave sounds"  (https://opengameart.org/content/sea-and-river-wave-sounds)
  birds.ogg     isaiah658,  "Ambient Bird Sounds"        (https://opengameart.org/content/ambient-bird-sounds)
  crickets.mp3  Wolfgang_,  "Crickets Ambient Noise - loopable" (https://opengameart.org/content/crickets-ambient-noise-loopable)
  dungeon.ogg   JaggedStone,"Loopable Dungeon Ambience"  (https://opengameart.org/content/loopable-dungeon-ambience)

Each bed is mono, 32 kHz, peak-normalized, and seam-crossfaded with an equal-power
window so the loop point is inaudible. No runtime downloads: the game streams these
local files exactly like the other recorded effects.
"""
import json
import os
import pathlib
import subprocess
import tempfile
import urllib.request

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

out = pathlib.Path('/home/user/assets/audio/ambience')
out.mkdir(parents=True, exist_ok=True)
# Masters are fetched on demand so the recipe is reproducible from a clean checkout;
# set AMBIENCE_SOURCES to reuse a local copy instead.
sources = pathlib.Path(os.environ.get('AMBIENCE_SOURCES') or pathlib.Path(tempfile.gettempdir()) / 'ambience-src')
downloads = {
    'vistula.mp3': 'https://opengameart.org/sites/default/files/VistulaShort_0.mp3',
    'birds.ogg': 'https://opengameart.org/sites/default/files/birds-isaiah658_0.ogg',
    'crickets.mp3': 'https://opengameart.org/sites/default/files/crickets_1.mp3',
    'dungeon.ogg': 'https://opengameart.org/sites/default/files/dungeon_ambient_1.ogg',
}
SR = 32000
manifest = {}


def fetch(name):
    target = sources / name
    if not target.exists():
        sources.mkdir(parents=True, exist_ok=True)
        print('downloading', downloads[name])
        urllib.request.urlretrieve(downloads[name], target)
    return target


def read(name):
    audio, rate = sf.read(str(fetch(name)), always_2d=True, dtype='float32')
    mono = audio.mean(1)
    if rate != SR:
        mono = resample_poly(mono, SR // np.gcd(rate, SR), rate // np.gcd(rate, SR)).astype(np.float32)
    return mono


def best_window(audio, seconds, block=1.0):
    """Pick the stretch whose loudness is most even, so the loop does not breathe."""
    span = int(seconds * SR)
    if len(audio) <= span:
        return 0
    step = int(block * SR)
    edges = np.lib.stride_tricks.sliding_window_view(audio, span)[::step]
    levels = np.sqrt(np.mean(edges ** 2, axis=1))
    return int(np.argmin(np.abs(levels - np.median(levels))) * step)


def seam(audio, seconds, fade):
    audio = audio[:int(seconds * SR)]
    n = int(fade * SR)
    t = np.linspace(0, 1, n, dtype=np.float32)
    # Equal-power crossfade: the tail blends into the head, so the join is smooth.
    tail = audio[-n:] * np.cos(t * np.pi / 2)
    head = audio[:n] * np.sin(t * np.pi / 2)
    return np.concatenate([audio[n:-n], tail + head])


def seamless(audio, longest, shortest=None, fade=1.2):
    """Search the loop length for the cleanest wrap-around join, then crossfade it.

    Crossfading alone leaves a step of whatever the tail and head happen to be; for
    impulsive beds (cricket chirps) that reads as a tick once per loop. Stepping the
    length lets the seam land where the waveform already agrees with itself.
    """
    shortest = shortest or longest * 0.86
    best = None
    for hold in sorted({fade, .6, .9, 1.2, 1.5}):
        for length in np.arange(shortest, longest, 0.02):
            loop = seam(audio, float(length), hold)
            step = float(np.abs(np.diff(loop)).mean())
            jump = abs(float(loop[0] - loop[-1])) + abs(float(loop[1] - loop[-2]))
            score = jump / (step + 1e-4)
            if best is None or score < best[0]:
                best = (score, loop, float(length), hold)
    print('  seam score %.2f at %.2fs (%.1fs crossfade)' % (best[0], best[2], best[3]))
    return best[1], best[2]


def encode(name, audio, note=None):
    peak = float(np.max(np.abs(audio)))
    audio = audio * (0.82 / max(peak, 1e-4))
    path = out / (name + '.ogg')
    sf.write(str(path), audio.astype(np.float32), SR, format='OGG', subtype='VORBIS', compression_level=0.62)
    manifest[name] = {
        'duration': round(len(audio) / SR, 2),
        'bytes': path.stat().st_size,
    }
    if note:
        manifest[name].update(note)
    print(name, manifest[name])


# River: a steady stretch of the Vistula recording near 40 s, 1.2 s seam.
river = read('vistula.mp3')
start = best_window(river, 44)
loop, length = seamless(river[start:], 41.5, 36)
encode('river', loop, {'sourceOffset': round(start / SR, 1), 'loopLength': round(length, 2)})

# Daytime overworld: birdsong, kept clear of the recording's near-silent gap.
birds = read('birds.ogg')
loop, length = seamless(birds, 30.4, 26)
encode('day', loop, {'sourceOffset': 0.0, 'loopLength': round(length, 2)})

# Night: crickets on their own loopable take.
crickets = read('crickets.mp3')[int(0.12 * SR):]
loop, length = seamless(crickets, 11.1, 8.6, .8)
encode('night', loop, {'sourceOffset': 0.12, 'loopLength': round(length, 2)})

# Dungeon: low wind and drips, chosen away from the recording's loud swell.
dungeon = read('dungeon.ogg')
start = best_window(dungeon, 44)
loop, length = seamless(dungeon[start:], 41.5, 36, 1.4)
encode('dungeon', loop, {'sourceOffset': round(start / SR, 1), 'loopLength': round(length, 2)})

(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('total', sum(v['bytes'] for v in manifest.values()), 'bytes')
