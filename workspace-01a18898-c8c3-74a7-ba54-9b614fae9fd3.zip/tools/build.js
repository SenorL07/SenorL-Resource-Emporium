// Single build entry point: node tools/build.js
//
// main.js is a recovered, self-contained game that is also served directly by the
// browser regression harness, so the canonical modules are embedded into their
// marked blocks in main.js before esbuild bundles the playable `three-game.js`.
// The script finishes by stamping the bundle hash into index.html so a changed
// build never reuses a cached script URL.
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';

// ---- Dungeon system -------------------------------------------------------
// Reuse the game's existing Three namespace (bm); do not bundle a second engine.
function syncDungeon(){
  const main=fs.readFileSync('main.js','utf8');
  let code=fs.readFileSync('dungeon.js','utf8').replace(/^import .*;\n/gm,'').replace('export function createDungeonSystem','function rb');
  code=code.replace('}){\n','}){\n  const THREE=bm;\n');
  let start=main.indexOf('    // BEGIN DUNGEON SYSTEM'),end=main.indexOf('    // END DUNGEON SYSTEM');
  if(start<0){start=main.indexOf('    function rb({ scene:');end=main.indexOf('    // BEGIN RECORDED AUDIO',start)}else end=main.indexOf('\n',end)+1;
  if(start<0||end<=start||end-start>100000)throw Error('Dungeon embed anchors missing/unsafe');
  fs.writeFileSync('main.js',main.slice(0,start)+'    // BEGIN DUNGEON SYSTEM — generated from dungeon.js\n'+code+'\n    // END DUNGEON SYSTEM\n'+main.slice(end));
}

// ---- Canonical gameplay modules ------------------------------------------
const GAMEPLAY_MODULES=[['player-death.js','PLAYER DEATH'],['player-combat.js','PLAYER COMBAT'],['material-impacts.js','MATERIAL IMPACTS'],['boat-ladders.js','BOAT LADDERS'],['boarding-defense.js','BOARDING DEFENSE'],['crew-transit.js','CREW TRANSIT'],['boat-alerts.js','BOAT ALERTS'],['crew-panic.js','CREW PANIC'],['boat-equipment.js','BOAT EQUIPMENT'],['breakage.js','BREAKAGE EFFECTS'],['naval-combat.js','NAVAL COMBAT'],['fleet.js','FLEET MODELS'],['fire.js','BURN SYSTEM'],['death-effects.js','DEATH EFFECTS'],['weapons.js','BOAT WEAPONS'],['overboard.js','OVERBOARD CREW'],['night-encounters.js','NIGHT ENCOUNTERS']];
function syncGameplay(){
  let main=fs.readFileSync('main.js','utf8');
  for(const [file,name]of GAMEPLAY_MODULES){
    const start=`// BEGIN CANONICAL ${name}`,end=`// END CANONICAL ${name}`;
    const body=fs.readFileSync(file,'utf8').replace(/^export /gm,'');
    const a=main.indexOf(start),b=main.indexOf(end,a);
    if(a<0||b<0)throw Error('Missing '+name+' markers');
    main=main.slice(0,a)+start+'\n'+body+'\n'+main.slice(b);
  }
  fs.writeFileSync('main.js',main);
}

// ---- Audio runtime -------------------------------------------------------
async function syncAudio(){
  const result=await build({entryPoints:['sound.js'],bundle:true,format:'iife',globalName:'AudioRuntime',write:false,target:'es2020'});
  const main=fs.readFileSync('main.js','utf8');
  let start=main.indexOf('    // BEGIN RECORDED AUDIO'),end=main.indexOf('    // END RECORDED AUDIO');
  if(start<0){start=main.indexOf('    var lb = { shot:');end=main.indexOf('    var Wm = false',start)}else end=main.indexOf('\n',end)+1;
  if(start<0||end<start)throw Error('Audio embed anchors missing');
  const code='    // BEGIN RECORDED AUDIO — generated from sound.js by tools/build.js\n'+result.outputFiles[0].text+'\n    var It = AudioRuntime.sfx;\n    // END RECORDED AUDIO\n';
  fs.writeFileSync('main.js',main.slice(0,start)+code+main.slice(end));
}

async function main(){
  syncDungeon();
  syncGameplay();
  await syncAudio();
  await build({entryPoints:['main.js'],bundle:true,minify:true,format:'iife',outfile:'three-game.js'});
  // A changed playable bundle must not reuse a cached script URL in the preview.
  const hash=createHash('sha256').update(fs.readFileSync('three-game.js')).digest('hex').slice(0,12);
  const html=fs.readFileSync('index.html','utf8');
  const updated=html.replace(/src="\.\/three-game\.js(?:\?[^"\s]*)?"/,'src="./three-game.js?v='+hash+'"');
  if(updated===html&&!html.includes('three-game.js?v='+hash))throw Error('Missing game script tag');
  fs.writeFileSync('index.html',updated);
  console.log('built three-game.js ('+fs.statSync('three-game.js').size+' bytes) v='+hash);
}
await main();
